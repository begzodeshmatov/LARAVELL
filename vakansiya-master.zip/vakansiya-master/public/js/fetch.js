document.querySelectorAll('#fieldSelection').forEach(fieldSelect => {
    fieldSelect.addEventListener('change', async (e) => {
        // Find the closest form to the current fieldSelect element
        const form = e.target.closest('form');
        const jobSelect = form.querySelector('#jobSelection');

        try {
            const response = await fetch(`${url}/api/fields/job/${e.target.value}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();

            // Clear the current options in jobSelect
            jobSelect.innerHTML = '';

            // Add the default option
            const defaultOption = document.createElement('option');
            defaultOption.textContent = "Tanlash...";
            defaultOption.disabled = true;
            defaultOption.selected = true;
            jobSelect.appendChild(defaultOption);

            // Populate the jobSelect with new options
            result.data.forEach(job => {
                const option = document.createElement('option');
                option.value = job.id;
                option.textContent = job.name;
                jobSelect.appendChild(option);
            });

        } catch (error) {
            console.error('Fetch error:', error);
        }
    });
});
