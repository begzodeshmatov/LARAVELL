<?php

use App\District;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DistrictsSeeder extends Seeder
{
    public function run()
    {
        District::create(['name' => 'Jizzax', 'region_id' => 1]);
        District::create(['name' => 'Forish', 'region_id' => 1]);
        District::create(['name' => 'G\'allaorol', 'region_id' => 1]);
        District::create(['name' => 'Baxmal', 'region_id' => 1]);
        District::create(['name' => 'Arnasoy', 'region_id' => 1]);
        District::create(['name' => 'Do\'stlik', 'region_id' => 1]);
        District::create(['name' => 'Paxtakor', 'region_id' => 1]);
        District::create(['name' => 'Sharof Rashidov', 'region_id' => 1]);
        District::create(['name' => 'Yangiobod', 'region_id' => 1]);
        District::create(['name' => 'Mirzacho\'l', 'region_id' => 1]);
        District::create(['name' => 'Zafarobod', 'region_id' => 1]);
        District::create(['name' => 'Zarbdor', 'region_id' => 1]);
        District::create(['name' => 'Zomin', 'region_id' => 1]);
    }
}
