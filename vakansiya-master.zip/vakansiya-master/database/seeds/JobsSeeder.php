<?php

use App\Job;
use Illuminate\Database\Seeder;

class JobsSeeder extends Seeder
{
    public function run()
    {
        $field = Job::create([
            "name" => "DAVLAT BOSHQARUVI VA MUDOFAA; MAJBURIY IJTIMOIY TA'MINOT", // 1
            "field_id" => 5,
        ]);
        $field = Job::create([
            "name" => "ISHLAB CHIQARADIGAN SANOAT", // 2
            "field_id" => 8,
        ]);
        $field = Job::create([
            "name" => "Madaniyat", // 3
            "field_id" => 3,
        ]);
        $field = Job::create([
            "name" => "YASHASH VA OVQATLANISH BO'YICHA XIZMATLAR", // 4
            "field_id" => 5,
        ]);
        $field = Job::create([
            "name" => "TASHISH VA SAQLASH", // 5
            "field_id" => 5,
        ]);
        $field = Job::create([
            "name" => "QISHLOQ, O'RMON VA BALIQ XO'JALIGI", // 6
            "field_id" => 9,
        ]);
        $field = Job::create([
            "name" => "QURULISH", // 7
            "field_id" => 7,
        ]);
        $field = Job::create([
            "name" => "BOSHQA TURDAGI XIZMATLAR KO'RSATISH", // 8
            "field_id" => 5,
        ]);
        $field = Job::create([
            "name" => "PROFESSIONAL, ILMIY VA TEXNIK FAOLIYAT", // 9
            "field_id" => 1,
        ]);
        $field = Job::create([
            "name" => "TA'LIM", // 10
            "field_id" => 1,
        ]);
        $field = Job::create([
            "name" => "ULGURJI VA CHAKANA SAVDO; MOTORLI TRANSPORT VOSITALARI VA MOTOTSIKLLARNI TA'MIRLASH", // 11
            "field_id" => 5,
        ]);
        $field = Job::create([
            "name" => "SOG`LIQNI SAQLASH VA IJTIMOIY XIZMATLAR KO'RSATISH", // 12
            "field_id" => 2,
        ]);
        $field = Job::create([
            "name" => "BOSHQARISH BO'YICHA FAOLIYAT VA YORDAMCHI XIZMATLAR KO'RSATISH", // 13
            "field_id" => 5,
        ]);
        $field = Job::create([
            "name" => "MOLIYAVIY VA SUG`URTA FAOLIYATI", // 14
            "field_id" => 4
        ]);
        $field = Job::create([
            "name" => "AXBOROT VA ALOQA", // 15
            "field_id" => 6,
        ]);
        $field = Job::create([
            "name" => "KO'CHMAS MULK BILAN OPERATSIYALAR", // 16
            "field_id" => 7,
        ]);
        $field = Job::create([
            "name" => "SAN'AT, KO'NGIL OCHISH VA DAM OLISH", // 17
            "field_id" => 3,
        ]);
        $field = Job::create([
            "name" => "TOG`-KON SANOATI VA OCHIQ KONLARNI ISHLASH", // 18
            "field_id" => 8,
        ]);
        $field = Job::create([
            "name" => "SUV BILAN TA'MINLASH; KANALIZATSIYA TIZIMI, CHIQINDILARNI YIG`ISH VA UTILIZATSIYA QILISH", // 19
            "field_id" => 8,
        ]);
        $field = Job::create([
            "name" => "ELEKTR, GAZ, BUG` BILAN TA'MINLASH VA HAVONI KONDITSIYALASH", // 20
            "field_id" => 8,
        ]);
        $field = Job::create([
            "name" => "EKSTERRITORIAL TASHKILOTLAR FAOLIYATI", // 21
            "field_id" => 10,
        ]);
        $field = Job::create([
            "name" => "NOMALUM", // 22
            "field_id" => 10,
        ]);
    }
}
