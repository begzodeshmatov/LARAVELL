<?php

use Illuminate\Database\Seeder;
use App\Region;
class RegionSeeder extends Seeder
{
    protected $region = [
        [
            'name' => 'Jizzax',
        ],
        [
            'name' => 'Toshkent',
        ],
        [
            'name' => 'Sirdaryo',
        ],
        [
            'name' => 'Samaraqand',
        ],
    ];

    public function run()
    {
        foreach($this->region as $r) {
            Region::create($r);
        }

    }
}
