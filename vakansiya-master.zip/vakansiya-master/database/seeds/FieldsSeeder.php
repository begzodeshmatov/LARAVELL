<?php

use App\Field;
use Illuminate\Database\Seeder;

class FieldsSeeder extends Seeder
{
    public function run()
    {
        $field = Field::create([
            "name" => "Ta'lim", // 1
        ]);
        $field = Field::create([
            "name" => "Sog'liqni saqlash", // 2
        ]);
        $field = Field::create([
            "name" => "Madaniyat", // 3
        ]);
        $field = Field::create([
            "name" => "Moliya va sug'urta", // 4
        ]);
        $field = Field::create([
            "name" => "Xizmat ko'rsatish", // 5
        ]);
        $field = Field::create([
            "name" => "Aloqa va axborot texnalogiyalari", // 6
        ]);
        $field = Field::create([
            "name" => "Qurilish", // 7
        ]);
        $field = Field::create([
            "name" => "Sanoat va ishlab chiqarish", // 8
        ]);
        $field = Field::create([
            "name" => "Qishloq xo'jaligi", // 9
        ]);
        $field = Field::create([
            "name" => "Nomalum", // 10
        ]);
    }
}
