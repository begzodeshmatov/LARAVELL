<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVacanciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vacancies', function (Blueprint $table) {
            $table->id();
            $table->string('name')->default('0');
            $table->string('b_name')->default('0');
            $table->string('lavozim')->default('0');
            $table->string('ish_orni')->default('0');
            $table->string('tel_raqam')->default('0');
            $table->string('manzil')->default('0');
            $table->string('maosh')->default('Narx belgilanmagan');
            $table->string('talab')->default('0');
            $table->foreignId('region_id')->default(1)->constrained()->cascadeOnDelete();
            $table->foreignId('district_id')->constrained()->cascadeOnDelete();
            $table->foreignId('job_id')->nullable()->constrained()->cascadeOnDelete();
            // $table->foreignId('field_id')->constrained()->cascadeOnDelete();
            $table->integer('type')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vacancies');
    }
}
