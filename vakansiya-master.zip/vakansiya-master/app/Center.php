<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Center extends Model
{
    protected $fillable = [
        "center_name", "name", "address", "body", "power", "time", "phon_number", "image"
    ];
    public function kasbs()
    {
        return $this->hasMany(Kasb::class);
    }
}
