<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Field extends Model
{
    protected $fillable = [
        'name',
    ];
    public function jobs() {
        return $this->hasMany(Job::class);
    }
    public function vacancies() {
        return $this->hasMany(Vacancy::class);
    }
}
