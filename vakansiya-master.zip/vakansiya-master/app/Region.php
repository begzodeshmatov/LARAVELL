<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Region extends Model
{
    protected $fillable = [
        "name"
    ];

    public function districts() {
        return $this->hasMany(District::class);
    }
    public function vacancies() {
        return $this->hasMany(Vacancy::class);
    }
}
