<?php

namespace App\Exports;

use App\Vacancy;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithChunkReading;

class VacancyExport implements FromCollection, WithHeadings, WithMapping, WithStyles, WithEvents, WithChunkReading
{
    public function collection()
    {
        return Vacancy::with(['region', 'district'])->get();
    }

    public function headings(): array
    {
        return [
            'ID',
            'Tashkilot nomi',
            'Bo\'lim nomi',
            'Lavozim',
            'Bo\'sh ish o\'rni',
            'Telefon raqam',
            'Manzil',
            'Maosh',
            'Talab',
            'Viloyat',
            'Tuman',
            'Soxa',
            'Turi'
        ];
    }

    public function map($vacancy): array
    {
        return [
            $vacancy->id,
            $vacancy->name,
            $vacancy->b_name,
            $vacancy->lavozim,
            $vacancy->ish_orni,
            (string)$vacancy->tel_raqam,
            $vacancy->manzil,
            $vacancy->maosh,
            $vacancy->talab,
            $vacancy->region->name,
            $vacancy->district->name,
            $vacancy->job->name,
            $vacancy->type == 0 ? 'Budjet' : 'Xususiy'
        ];
    }
    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => [
                    'bold' => true,
                    'size' => 14,
                    'color' => ['argb' => '000000'],
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'argb' => 'C1C5CD',
                    ]
                ]
            ],
        ];
    }
    public function registerEvents(): array
    {
        return [
            \Maatwebsite\Excel\Events\AfterSheet::class => function(\Maatwebsite\Excel\Events\AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();

                $columnWidths = [
                    'A' => 8,
                    'B' => 90,
                    'C' => 30,
                    'D' => 30,
                    'E' => 10,
                    'F' => 18,
                    'G' => 70,
                    'H' => 20,
                    'I' => 18,
                    'J' => 10,
                    'K' => 18,
                    'L' => 90,
                    'M' => 10,
                ];

                foreach ($columnWidths as $column => $width) {
                    $sheet->getColumnDimension($column)->setWidth($width);
                }

                $sheet->getStyle('F')->getNumberFormat()->setFormatCode('000000000');

                $highestRow = $sheet->getHighestRow();
                $sheet->getStyle('A1:M' . $highestRow)->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['argb' => 'FF000000'],
                        ],
                    ],
                ]);
            }
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
