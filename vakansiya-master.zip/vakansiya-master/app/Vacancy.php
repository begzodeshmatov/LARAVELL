<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vacancy extends Model
{
    protected $fillable = [
        'name', 'b_name', 'lavozim','ish_orni','tel_raqam','manzil','maosh','talab', 'region_id', 'district_id', 'job_id', 'type',// 'field_id',
    ];

    public function region() {
        return $this->belongsTo(Region::class);
    }
    public function district() {
        return $this->belongsTo(District::class);
    }
    public function job() {
        return $this->belongsTo(Job::class);
    }
    // public function field() {
    //     return $this->belongsTo(Field::class);
    // }
}
