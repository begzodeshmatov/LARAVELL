<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class District extends Model
{
    protected $fillable = [
        "name"
    ];

    public function region() {
        return $this->belongsTo(Region::class);
    }
    public function vacancies() {
        return $this->hasMany(Vacancy::class);
    }
}
