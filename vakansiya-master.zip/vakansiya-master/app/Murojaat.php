<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Murojaat extends Model
{
    protected $fillable = [
        'ismi', 'tel_raqam', 'murojat_matni',
    ];
}
