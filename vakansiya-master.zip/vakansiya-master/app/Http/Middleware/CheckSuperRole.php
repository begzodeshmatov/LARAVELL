<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Gate;

class CheckSuperRole
{
    public function handle($request, Closure $next)
    {
        if (Gate::denies('super')) {
            abort(403, 'Sizda ushbu amallarni bajarish uchun ruxsat yo\'q.');
        }
        return $next($request);
    }
}
