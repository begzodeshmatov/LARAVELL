<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CenterUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "center_name" => ["required", "string"],
            "name" => ["required", "string"],
            "address" => ["required", "string"],
            "body" => ["required", "string"],
            "power" => ["required", "string"],
            "time" => ["required", "string"],
            "phon_number" => ["required", "string"],
        ];
    }
    public function messages()
    {
        return [
            'center_name.required' => 'Markaz nomi kiritilishi shart.',
            'name.required' => 'Ism kiritilishi shart.',
            'address.required' => 'Manzil kiritilishi shart.',
            'body.required' => 'Tavsif kiritilishi shart.',
            'power.required' => 'Quvvati kiritilishi shart.',
            'time.required' => 'Vaqt kiritilishi shart.',
            'phon_number.required' => 'Telefon raqami kiritilishi shart.',

            'string' => ':attribute faqat matn bo‘lishi kerak.',
        ];
    }
}
