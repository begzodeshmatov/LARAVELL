<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "name" => ["required", "string"],
            "email" => ["required", "email",],
        ];
    }
    public function messages()
    {
        return [
            'name.required' => 'Ism maydoni to\'ldirilishi shart.',
            'name.string' => 'Ism matn bo\'lishi kerak.',

            'email.required' => 'Email maydoni to\'ldirilishi shart.',
            'email.email' => 'Email to\'g\'ri formatda bo\'lishi kerak.',
        ];
    }
}
