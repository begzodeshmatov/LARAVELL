<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AppealsRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }
    public function rules()
    {
        return [
            "name" => ["required", "string", "max:255"],
            "phone_number" => ["required", "numeric"],
            "text" => ["required", "string", "min:5"]
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'The name field is required.',
            'name.string' => 'The name must be a string.',
            'name.max' => 'The name may not be greater than 255 characters.',

            'phone_number.required' => 'The phone number field is required.',
            'phone_number.numeric' => 'The phone number must be a numeric value.',

            'text.required' => 'The text field is required.',
            'text.string' => 'The text must be a string.',
            'text.min' => 'The text must be at least 5 characters.',
        ];
    }
}
