<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CenterResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "name" => $this->name,
            "center_name" => $this->center_name,
            "address" => $this->address,
            "phone_number" => $this->phon_number,
            "image" => url('storage/'.str_replace('public/', '', $this->image)),
        ];
    }
}
