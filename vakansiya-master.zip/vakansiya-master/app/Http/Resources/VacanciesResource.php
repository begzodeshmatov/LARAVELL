<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class VacanciesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "name" => $this->name,
            "department_name" => $this->b_name,
            "position" => $this->lavozim,
            "workplace" => $this->ish_orni,
            "phone_number" => $this->tel_raqam,
            "address" => $this->manzil,
            "salary" => $this->maosh,
            "demand" => $this->talab,
            "type" => $this->type,
            "region" => $this->region->name,
            "district" => $this->district->name, // new DistrictsResource($this->district),
            "job" => $this->job->name ? $this->job->name : null,
            "field" => $this->job->field->name ? $this->job->field->name : null,
            "created_at" => Carbon::parse($this->created_at)->format('d-m-Y H:i:s')
        ];
    }
}
