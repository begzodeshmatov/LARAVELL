<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CenterMoreResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "name" => $this->name,
            "center_name" => $this->center_name,
            "address" => $this->address,
            'body' => $this->body,
            'power' => $this->power,
            'time' => $this->time,
            "phone_number" => $this->phon_number,
            "image" => url('storage/'.str_replace('public/', '', $this->image)),
            "jobs" => KasbResource::collection($this->kasbs),
        ];
    }
}
