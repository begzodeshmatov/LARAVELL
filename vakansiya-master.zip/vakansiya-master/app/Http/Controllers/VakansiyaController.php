<?php

namespace App\Http\Controllers;

use Maatwebsite\Excel\Facades\Excel;
use App\Imports\VakansiyaImport;
use Illuminate\Http\Request;
use App\District;
use App\Exports\VacancyExport;
use App\Vacancy;
use App\Field;
use App\Region;

class VakansiyaController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'checkSuper']);
    }
    public function index()
    {

    }


    public function ishorni()
    {
        $regions = Region::all();
        $districts = District::all();
        $vacancies = Vacancy::paginate(25);
        $fields = Field::all();
        return view('vakansiya', [
            'vacancies' => $vacancies,
            "regions" => $regions,
            "districts" => $districts,
            "fields" => $fields,
        ]);
    }

    public function vakansiyaSave(Request $request)
    {
        $get = new Vacancy();

        $get->name = $request->name;
        $get->b_name = $request->b_name;
        $get->lavozim = $request->lavozim;
        $get->ish_orni = $request->ish_orni;
        $get->tel_raqam = $request->tel_raqam;
        $get->manzil = $request->manzil;
        $get->maosh = $request->maosh;
        $get->talab = $request->talab;
        $get->region_id = '1';
        $get->district_id = $request->district_id;
        $get->job_id = $request->job_id;
        // $get->field_id = $request->field_id;
        $get->type = $request->type;

        $get->save();
        return redirect('/vakansiyalar');
    }

    public function vakansiyaEditSave($id, Request $request)
    {
        // dd($request->all());

        $data = [
            'name' => $request->name,
            'b_name' => $request->b_name,
            'lavozim' => $request->lavozim,
            'ish_orni' => $request->ish_orni,
            'tel_raqam' => $request->tel_raqam,
            'manzil' => $request->manzil,
            'maosh' => $request->maosh,
            'talab' => $request->talab,
            // 'viloyat_id'=>$request->viloyat_id,
            'district_id' => $request->district_id,
            'job_id' => $request->job_id,
            // 'field_id' => $request->field_id,
            'type' => $request->type,
        ];
        Vacancy::where('id', $id)->update($data);
        return back();
    }

    public function vakansiyaDelete($id)
    {
        Vacancy::where('id', $id)->delete();
        return back();
    }

    public function import(Request $request)
    {
        Vacancy::truncate();
        Excel::import(
            new VakansiyaImport,
            $request->file('file')->store('files')
        );
        return redirect()->back();
    }

    public function export()
    {
        return Excel::download(new VacancyExport, 'all_vacancies_' . time() . '.xlsx');
    }
}
