<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function success($data, string $message = "Successfully") {
        return response()->json([
            "status" => true,
            "data" => $data,
            "message" => $message
        ], 200);
    }
    public function pagination($data, string $message = "Successfully", int $status = 200) {
        $pagination = [
            'current_page' => $data->currentPage(),
            'total_pages' => $data->lastPage(),
            'next_page' => $data->currentPage() < $data->lastPage() ? $data->currentPage() + 1 : null,
            'total' => $data->total()
        ];
        return response()->json([
            "status" => true,
            "data" => $data->items(),
            'current_page' => $pagination['current_page'],
            'next_page' => $pagination['next_page'],
            'total_pages' => $pagination['total_pages'],
            "message" => $message
        ], $status);
    }
    public function created($data, string $message = "Created") {
        return response()->json([
            "status" => true,
            "data" => $data,
            "message" => $message
        ], 201);
    }
    public function notFound(string $message = "Not Found") {
        return response()->json([
            "status" => false,
            "data" => [],
            "message" => $message
        ], 404);
    }
    static function notFoundStatic(string $message = "Not Found") {
        return response()->json([
            "status" => false,
            "data" => [],
            "message" => $message
        ], 404);
    }
}
