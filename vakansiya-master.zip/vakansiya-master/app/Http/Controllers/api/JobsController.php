<?php

namespace App\Http\Controllers\api;

use App\Http\Resources\JobsWithResource;
use App\Http\Controllers\Controller;
use App\Http\Resources\FieldsResource;
use App\Job;

class JobsController extends Controller
{
    public function index()
    {
        $data = JobsWithResource::collection(Job::all());
        return $this->success($data, "All jobs");
    }

    public function show(Job $job)
    {
        $data = new JobsWithResource($job);
        return $this->success($data, "one job by id");
    }
    public function field(Job $job)
    {
        $data = new FieldsResource($job->field);
        return $this->success($data, "Job's field");
    }
}
