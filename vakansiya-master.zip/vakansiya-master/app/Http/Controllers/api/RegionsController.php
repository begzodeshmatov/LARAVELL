<?php

namespace App\Http\Controllers\api;

use App\Http\Resources\RegionsResource;
use App\Http\Controllers\Controller;
use App\Http\Resources\RegionsWithResource;
use App\Region;

class RegionsController extends Controller
{
    public function index()
    {
        $regions = Region::all();
        $data = RegionsResource::collection($regions);
        return $this->success($data, "All regions");
    }

    public function show(Region $region)
    {
        $data = new RegionsWithResource($region);
        return $this->success($data, "One region with its districts by id");
    }

}
