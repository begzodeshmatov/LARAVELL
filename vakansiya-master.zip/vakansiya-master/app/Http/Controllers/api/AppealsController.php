<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Http\Requests\AppealsRequest;
use App\Http\Resources\AppealsResource;
use App\Murojaat;
use Illuminate\Http\Request;

class AppealsController extends Controller
{
    public function index()
    {
        //
    }

    public function store(AppealsRequest $request)
    {
        $appeal = Murojaat::create([
            "ismi" => $request->name,
            "tel_raqam" => $request->phone_number,
            "murojat_matni" => $request->text
        ]);

        $data = new AppealsResource($appeal);
        return $this->success($data, "Appeal has been sent");
    }
    public function show(Murojaat $murojaat)
    {
        //
    }

    public function update(Request $request, Murojaat $murojaat)
    {
        //
    }

    public function destroy(Murojaat $murojaat)
    {
        //
    }
}
