<?php

namespace App\Http\Controllers\api;

use App\Http\Resources\FieldsWithResource;
use App\Http\Resources\FieldsResource;
use App\Http\Controllers\Controller;
use App\Http\Resources\JobsResource;
use App\Field;

class FieldsController extends Controller
{
    public function index()
    {
        $data = FieldsResource::collection(Field::all());
        return $this->success($data, "All fields");
    }
    public function show(Field $field)
    {
        $data = new FieldsWithResource($field);
        return $this->success($data, "One field by id");
    }
    public function jobs(Field $field)
    {
        $data = JobsResource::collection($field->jobs);
        return $this->success($data, "Field's jobs");
    }
}
