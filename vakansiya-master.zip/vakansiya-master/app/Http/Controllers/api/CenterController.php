<?php

namespace App\Http\Controllers\api;

use App\Center;
use App\Http\Controllers\Controller;
use App\Http\Resources\CenterMoreResource;
use App\Http\Resources\CenterResource;

class CenterController extends Controller
{
    public function index()
    {
        $centers = Center::paginate(15);
        $data = CenterResource::collection($centers);
        return $this->pagination($data, "All centers");
    }
    public function show(Center $center)
    {
        $data = new CenterMoreResource($center);
        return $this->success($data, "One center");
    }
}
