<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\District;
use App\Http\Resources\DistrictsWithResource;

class DistrictController extends Controller
{
    public function index()
    {
        $districts = District::all();
        $data = DistrictsWithResource::collection($districts);
        return $this->success($data, "All districts with its region");
    }

    public function show(District $district)
    {
        $data = new DistrictsWithResource($district);
        return $this->success($data, "One district with its region by id");
    }
}
