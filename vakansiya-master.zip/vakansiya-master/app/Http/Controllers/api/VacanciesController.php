<?php

namespace App\Http\Controllers\api;

use App\Http\Resources\VacanciesResource;
use App\Http\Controllers\Controller;
use App\District;
use App\Job;
use App\Vacancy;
use App\Region;

class VacanciesController extends Controller
{
    public function index()
    {
        $vacancies = Vacancy::paginate(15);
        $data = VacanciesResource::collection($vacancies);
        return $this->pagination($data, "All vacancies");
    }

    public function show(Vacancy $vacancy)
    {
        $data = new VacanciesResource($vacancy);
        return $this->success($data, "Get one vacancy by id");
    }

    public function byRegion(Region $region)
    {
        $vacancies = Vacancy::where("region_id", $region->id)->paginate(15);
        $data = VacanciesResource::collection($vacancies);
        return $this->pagination($data, "All $region->name's vacancies");
    }
    public function byDistrict(District $district)
    {
        $vacancies = Vacancy::where("district_id", $district->id)->paginate(15);
        $data = VacanciesResource::collection($vacancies);
        return $this->pagination($data, "All $district->name's vacancies");
    }

    public function main(District $district, Job $job, $type)
    {
        $vacancies = $district->vacancies()->where("job_id", $job->id)->where("type", $type)->paginate(15);
        $data = VacanciesResource::collection($vacancies);
        return $this->pagination($data, "All $district->name's vacancies");
    }

    public function count()
    {
        $vacancies = Vacancy::count();
        return $this->success($vacancies, "All count vacancies");
    }


}
