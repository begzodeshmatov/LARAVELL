<?php

namespace App\Http\Controllers;

use App\Center;
use App\Http\Requests\CenterRequest;
use App\Http\Requests\CenterUpdateRequest;
use App\Kasb;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CenterController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'checkSuper']);
    }
    public function index()
    {
        $centers = Center::all();
        return view("centers", [
            "centers" => $centers,
        ]);
    }

    public function show(Center $center)
    {
        return view("center", [
            "center" => $center,
        ]);
    }

    public function store(CenterRequest $request)
    {
        $name = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $image = $request->file("image")->storeAs("public/photos", $name);
        Center::create([
            "center_name" => $request->center_name,
            "name" => $request->name,
            "address" => $request->address,
            "body" => $request->body,
            "power" => $request->power,
            "time" => $request->time,
            "phon_number" => $request->phon_number,
            "image" => $image,
        ]);
        return redirect()->back()->with("success", "Markaz yaratildi");
    }

    public function update(CenterUpdateRequest $request, Center $center)
    {
        $image = $center->image;

        if ($request->file("image")) {
            $name = time() . '.' . $request->file("image")->getClientOriginalExtension();
            $image = $request->file("image")->storeAs("public/photos", $name);
        }
        $center->update([
            "center_name" => $request->center_name,
            "name" => $request->name,
            "address" => $request->address,
            "body" => $request->body,
            "power" => $request->power,
            "time" => $request->time,
            "image" => $image,
        ]);
        return redirect()->back()->with("success", "Markaz muvoffaqiyatli tahrirlandi");
    }

    public function destroy(Center $center) {
        Storage::delete($center->image);
        $center->delete();
        return redirect()->back()->with("success", "Markaz muvoffaqiyatli o'chirildi");
    }

    public function kasbStore(Request $request, Center $center)
    {
        $center->kasbs()->create([
            "name" => $request->name,
        ]);
        return redirect()->back()->with("success", "Markazga kasb qo'shildi");
    }
    public function kasbUpdate(Request $request, Kasb $kasb)
    {
        $kasb->update([
            "name" => $request->name,
        ]);
        return redirect()->back()->with("success", "Kasb tahrirlandi");
    }
    public function kasbDestroy(Kasb $kasb)
    {
        $kasb->delete();
        return redirect()->back()->with("success", "Kasb o'chirildi");
    }
}
