<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Murojaat;

class MurojaatController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function murojaats() {

        // dd($request);
        // return Murojaat::all();

        $murojat = Murojaat::all();

        return view('murojat', [
            'murojaats'=>$murojat
        ]);
    }

    public function murojatEditSave($id, Request $request) {

        // dd($request->all());

        $data = [
            'ismi'=>$request->ismi,
            'tel_raqam'=>$request->tel_raqam,
            'murojat_matni'=>$request->murojat_matni,
        ];
        Murojaat::where('id',$id)->update($data);
        return back();
    }

    public function murojatDelete($id) {
        Murojaat::where('id',$id)->delete();
        return back();
    }

   public function murojatSave(Request $request) {

        // dd($request);
        $get = new Murojaat();
        $get->ismi = $request->ismi;
        $get->tel_raqam = $request->tel_raqam;
        $get->murojat_matni = $request->murojat_matni;

        $get->save();
        return redirect('/murojaats');
   }
}
