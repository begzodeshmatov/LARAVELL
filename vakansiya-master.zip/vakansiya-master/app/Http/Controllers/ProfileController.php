<?php

namespace App\Http\Controllers;

use App\Http\Requests\PasswordUpdateRequest;
use App\Http\Requests\ProfileUpdateRequest;
use Illuminate\Support\Facades\Hash;
use App\User;

class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function show()
    {
        return view("profile", [
            "user" => auth()->user(),
        ]);
    }

    public function update(ProfileUpdateRequest $request)
    {
        $unique = User::where("email", $request->email)->first();
        if ($unique) {
            if ($unique->email == auth()->user()->email) {
                auth()->user()->update([
                    "name" => $request->name,
                    "email" => $request->email,
                ]);
                return redirect()->back()->with("success", "Akkaunt ma'lumotlaringiz muvaffaqiyatli o'zgartirildi");
            }
        }
        return redirect()->back()->with("error", $request->email . " bu email mavjud");
    }
    public function password(PasswordUpdateRequest $request)
    {
        if (Hash::check($request->old_password, auth()->user()->password)) {
            auth()->user()->update([
                "password" => Hash::make($request->password),
            ]);
            return redirect()->back()->with("success", "Parolingiz mivaffaqiyatli o'zgartirildi");
        }
        return redirect()->back()->with("error", "Ekis parolingiz noto'g'ri");
    }

    public function destroy()
    {
        auth()->user()->delete();
        return redirect()->route('login');
    }
}
