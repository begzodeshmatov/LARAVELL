<?php

namespace App\Http\Controllers;

use App\Field;
use App\Job;
use Illuminate\Http\Request;

class JobsController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'checkSuper']);
    }
    public function index()
    {
        $jobs = Job::all();
        $fields = Field::all();
        return view('jobs', [
            "jobs" => $jobs,
            "fields" => $fields,
        ]);
    }

    public function store(Request $request)
    {
        $field = Field::where("id", $request->field_id)->first();
        $field->jobs()->create([
            "name" => $request->name,
        ]);
        return redirect('jobs');
    }

    public function show(Job $job)
    {
        //
    }

    public function update(Request $request, Job $job)
    {
        $job->update([
            "name" => $request->name
        ]);
        return redirect('jobs');
    }

    public function destroy(Job $job)
    {
        $job->delete();
        return redirect('jobs');
    }
}
