<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Http\Requests\UserRestoreRequest;
use App\Http\Requests\UserUpdateRequest;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(User::class, "user");
    }
    public function index()
    {
        $users = User::where("role", "!=", "super")->paginate(15);
        return view("users", [
            "users" => $users,
        ]);
    }

    public function store(UserRequest $request)
    {
        User::create([
            "name" => $request->name,
            "email" => $request->email,
            "role" => "admin",
            "password" => Hash::make($request->password),
        ]);
        return redirect()->back()->with("success", "Foydalanuvchi qo'shildi");
    }

    public function update(UserUpdateRequest $request, User $user)
    {
        $unique = User::where("email", $request->email)->first();
        if ($unique) {
            if ($unique->email == $user->email) {
                $user->update([
                    "name" => $request->name,
                    "email" => $request->email,
                ]);
                return redirect()->back()->with("success", "Foydalanuvchi tahrirlandi");
            } else {
                return redirect()->back()->with("error", $request->email . " bu email mavjud");
            }
        } else {
            $user->update([
                "name" => $request->name,
                "email" => $request->email,
            ]);
            return redirect()->back()->with("success", "Foydalanuvchi tahrirlandi");
        }

    }

    public function destroy(User $user)
    {
        $user->delete();
        return redirect()->back()->with("success", "Foydalanuvchi o'chirib tashlandi");
    }

    public function restore(UserRestoreRequest $request, User $user)
    {
        $user->update([
            "password" => Hash::make($request->password),
        ]);
        return redirect()->back()->with("success", "Foydalanuvchi paroli tiklandi");
    }
}
