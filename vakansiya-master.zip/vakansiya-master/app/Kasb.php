<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kasb extends Model
{
    protected $fillable = [
        "center_id", "name"
    ];
    public function center()
    {
        return $this->belongsTo(Center::class);
    }
}
