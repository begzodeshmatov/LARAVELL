<?php

namespace App\Imports;

use App\Vacancy;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class VakansiyaImport implements ToModel, WithStartRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        // $districtId = isset($row[8]) ? (int)$row[8] : 1;
        // $jobId = isset($row[9]) ? (int)$row[9] : 1;
        // $fieldId = isset($row[10]) ? (int)$row[10] : 1;

        // return new Vacancy([
        //     'name'    => $row[0] ?? 'Kiritilmagan',
        //     'b_name'  => $row[1] ?? 'Kiritilmagan',
        //     'ish_orni' => $row[2] ?? 'Kiritilmagan',
        //     'lavozim' => $row[3] ?? 'Kiritilmagan',
        //     'tel_raqam' => $row[4] ?? 'Kiritilmagan',
        //     'manzil' => $row[5] ?? 'Kiritilmagan0',
        //     'maosh' => $row[6] ?? 'Kiritilmagan',
        //     'talab' => $row[7] ?? 'Kiritilmagan',
        //     'district_id' => $districtId,
        //     'job_id' => $jobId,
        //     'field_id' => $fieldId,
        //     'type' => $row[11] ?? '0',
        // ]);




        $districtId = isset($row[17]) ? (int)$row[17] : 1;
        $jobId = isset($row[15]) ? (int)$row[15] : 1;  // not yet selected
        // $fieldId = isset($row[15]) ? (int)$row[15] : 1;
        return new Vacancy([
            'name'    => $row[2] ?? "0",
            'b_name'  => $row[5] ?? "0",
            'lavozim' => $row[6] ?? "0",
            'ish_orni' => $row[7] ?? "0",
            'tel_raqam' => $row[9] ?? "Kiritilmagan",
            'manzil' => $row[11] ?? "0",
            'maosh' => $row[13] ?? "Narx belgilanmagan",
            'talab' => $row[14] ?? "0",
            'district_id' => $districtId,
            'job_id' => $jobId,
            // 'field_id' => $fieldId,
            'type' => $row[12] ?? 0,
        ]);
    }
    public function startRow(): int
    {
        return 2;
    }
}
