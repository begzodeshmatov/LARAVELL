@extends('layouts.app')

@section('content')
    <div class="pagetitle">
        <h1>Loyihalar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/home">Asosiy</a></li>
                <li class="breadcrumb-item active">Loyihalar</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">
                    <h2 class="text-center mb-4 text-dark font-weight-bold bg-light text-uppercase">Jizzax viloyatida amalga
                        oshiriladigan <span class="text-primary">hududiy investitsiya loyihalar</span> </h2>

                    <!-- Sales Card -->
                    <div class="col-2">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title">Loyihalar soni</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="ri-slideshow-line"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;" class="text-danger">145 <span class="text-dark"
                                                style="font-size:20px">ta</span> </h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Sales Card -->

                    <!-- Revenue Card -->
                    <div class="col-2">
                        <div class="card info-card revenue-card">
                            <div class="card-body">
                                <h5 class="card-title">Umumiy qiymati</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-currency-dollar"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;" class="text-danger">3,264 <span class="text-dark"
                                                style="font-size:20px;"> trln so'm</span> </h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Revenue Card -->

                    <!-- Customers Card -->
                    <div class="col-2">
                        <div class="card info-card customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Bank krediti</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class='bx bx-coin'></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">3,264 <span class="text-dark"
                                                style="font-size:20px;"> trln so'm</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->

                    <div class="col-2">
                        <div class="card info-card customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Xorijiy investitsiya</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class='bx bx-coin-stack'></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">3,264 <span class="text-dark"
                                                style="font-size:20px;"> mln dollar</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->

                    <div class="col-2">
                        <div class="card info-card customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Yaratilgan ish o'rni</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">3,264 <span class="text-dark"
                                                style="font-size:20px;"> nafar</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->
                    <div class="col-2">
                        <div class="card info-card customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Istiqbolsiz loyihalar</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">29 <span class="text-dark"
                                                style="font-size:20px;"> ta</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->

                    <div class="col-3">
                        <div class="card info-card customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Muddati buzib bajarilgan</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">1 <span class="text-dark"
                                                style="font-size:20px;"> ta</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->
                    <div class="col-3 ">
                        <div class="card info-card qizil customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Muddati o'tgan loyiha</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger dd">3 <span class="text-dark"
                                                style="font-size:20px;"> ta</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->

                    <div class="col-3">
                        <div class="card info-card sariq customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Muddati yaqinlashgan loyiha</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">29 <span class="text-dark"
                                                style="font-size:20px;"> ta</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->
                    <style>
                        .qizil {
                            /* background:red; */
                            animation: chiq 5s linear infinite;
                        }

                        .sariq {
                            animation: sariq 5s linear infinite;
                            animation-delay: 5s;
                        }

                        .yashil {
                            animation: yashil 5s linear infinite;
                            animation-delay: 5s;
                        }

                        @keyframes yashil {
                            100% {
                                background: green;
                            }
                        }

                        @keyframes chiq {
                            100% {
                                background: red;
                            }
                        }

                        @keyframes sariq {
                            100% {
                                background: yellow;
                            }
                        }
                    </style>
                    <div class="col-3">
                        <div class="card info-card yashil customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Ishga tushirilgan loyiha</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-people"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6 style="font-size: 1.5rem;"class="text-danger">65 <span class="text-dark"
                                                style="font-size:20px;"> ta</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Customers Card -->

                </div>
            </div>
            <!-- End Left side columns -->
            <div class="row">
                <div class="col-4">
                    <div class="col-12 mt-0">
                        <div class="card info-card  bg-primary"
                            style="clip-path: polygon(0 0, 100% 0, 89% 100%, 12% 100%);">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2"> <span
                                        class="text-warning fs-5">Sanoat</span> sohasidagi loyihalar</h5>
                            </div>
                        </div>
                    </div>

                    <div class="card p-3">
                        <div class="row">
                            <div class="col-2 px-2  d-flex align-items-center justify-content-center">
                                <div class="row">
                                    <div class="col-12 px-6">
                                        <div class="card p-1 h-75">
                                            <h5 class="my-auto">Jami</h5>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-10">
                                <div class="row">
                                    <div class="col-3 mt-0 d-flex  justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center text-center justify-content-center">
                                            <i class="ri-slideshow-line" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-currency-dollar" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin' style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin-stack' style="color:green;"></i>
                                        </div>
                                    </div>


                                    <div class="col-3  px-1">
                                        <div class="card h-100 info-card d-flex">
                                            <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                                Loyihalar</h5>
                                            <h6 style="font-size: 18px;"
                                                class="text-center text-danger align-items-center">145 <span
                                                    class="text-dark" style="font-size:12px;">ta</span></h6>
                                        </div>
                                    </div><!-- center Sales Card -->
                                    <div class="col-3  px-1 ">
                                        <div class="card h-100 info-card flex-grow-1">
                                            <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                                Umumiy qiymati</h5>
                                            <h6 style="font-size: 18px;"
                                                class="text-center text-danger align-items-start">145 <span
                                                    class="text-dark" style="font-size:12px;">trln so'm</span></h6>
                                        </div>
                                    </div>
                                    <div class="col-3  px-1">
                                        <div class="card h-100 info-card d-flex">
                                            <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                                Bank krediti</h5>
                                            <h6 style="font-size: 18px;"
                                                class="text-center text-danger align-items-center">145 <span
                                                    class="text-dark" style="font-size:12px;">trln so'm</span></h6>
                                        </div>
                                    </div>
                                    <div class="col-3  px-1">
                                        <div class="card h-100 info-card d-flex">
                                            <h5 style="font-size:11px;"
                                                class="card-title text-center text-center align-items-center">Ish o'rinlari
                                            </h5>
                                            <h6 style="font-size: 18px;"
                                                class="text-center text-danger align-items-center">145 <span
                                                    class="text-dark" style="font-size:12px;">nafar</span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <!-- end -->
                        </div>
                    </div>

                    <div class="col-12 col-sm-10 col-md-8 col-lg-11 mx-auto">
                        <div class="card info-card  bg-primary"
                            style="clip-path: polygon(0 0, 100% 0, 89% 100%, 12% 100%);">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2"> <span class="text-warning fs-5">Xizmat
                                        ko'rsatish</span> sohasidagi loyihalar</h5>
                            </div>
                        </div>
                    </div>
                    <div class="card p-2">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-12 mb-0">
                                        <div class="card info-card mb-0 bg-success pb-0">
                                            <h3 class="card-title text-center mb-0 pt-1 pb-1 text-light fs-5">Jami</h3>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex  justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center text-center justify-content-center">
                                            <i class="ri-slideshow-line" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-currency-dollar" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin' style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin-stack' style="color:green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:12px;" class="card-title text-center">Loyihalar</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">ta</span></h6>
                                </div>
                            </div><!-- End Sales Card -->
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:11px;" class="card-title text-center">Umumiy qiymati</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">trln so'm</span></h6>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:11px;" class="card-title text-center">Bank krediti</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">trln so'm</span></h6>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:11px;" class="card-title text-center">Ish o'rinlari</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">nafar</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-10 col-md-8 col-lg-11 mx-auto">
                        <div class="card info-card  bg-primary"
                            style="clip-path: polygon(0 0, 100% 0, 89% 100%, 12% 100%);">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2"> <span
                                        class="text-warning fs-5">Qishloq xo'jaligi</span> sohasidagi loyihalar</h5>
                            </div>
                        </div>
                    </div>

                    <div class="card p-2">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-12 mb-0">
                                        <div class="card info-card mb-0 bg-success pb-0">
                                            <h3 class="card-title text-center mb-0 pt-1 pb-1 text-light fs-5">Jami</h3>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex  justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center text-center justify-content-center">
                                            <i class="ri-slideshow-line" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-currency-dollar" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin' style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin-stack' style="color:green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:12px;" class="card-title text-center">Loyihalar</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">ta</span></h6>
                                </div>
                            </div><!-- End Sales Card -->
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:11px;" class="card-title text-center">Umumiy qiymati</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">trln so'm</span></h6>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:11px;" class="card-title text-center">Bank krediti</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">trln so'm</span></h6>
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="card info-card">
                                    <h5 style="font-size:11px;" class="card-title text-center">Ish o'rinlari</h5>
                                    <h6 style="font-size: 18px;" class="text-center text-danger">145 <span
                                            class="text-dark" style="font-size:12px;">nafar</span></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-4">
                    <div class="col-12">
                        <div class="card info-card  bg-primary">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2">Asosiy sanoat tarmoq yo'nalishlari</h5>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card" style="background: transparent;">
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Loyihalar
                                </h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Umumiy
                                    qiymati</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Ish o'rinlari
                                </h5>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Qurilish
                                    materiallari sanoati</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Oziq ovqat
                                    sanoati</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Tekstil va
                                    to'qimachilik sanoati</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Avtomobil
                                    sanoati</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Yog'-moy
                                    sanoati</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Kimyo sanoati
                                </h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h5 class="card-title text-primary text-center mb-0" style="font-size:11px;">Boshqa sanoat
                                    tarmoqlari</h5>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">ta</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">mlrd so'm</span></h6>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="card info-card border border-primary">
                                <h6 style="font-size: 1.2rem;" class="text-danger text-center mb-4 mt-4">145 <br><span
                                        class="text-dark" style="font-size:12px;">nafar</span> </h6>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end -->
                <div class="col-4">
                    <div class="col-12">
                        <div class="card info-card  bg-primary">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2">Jizzax viloyati</h5>
                            </div>
                        </div>
                        <div class="col-12">
                            <img src="/rasmlar/600__5d638856dc0b8.jpg" class="img-fluid w-100" alt="Responsive image">
                        </div>
                        <div class="col-12 mt-4">
                            <!-- <img src="/rasmlar/Jizzax_viloyati.png" usemap="#image-map" class="img-fluid w-100 mt-5"> -->
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d115812.87188711062!2d67.6985067546978!3d40.118831089368456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38b29442f6b6d4d9%3A0x9278c40ee88910e2!2z0JTQttC40LfQsNC6LCDQlNC20LjQt9Cw0LrRgdC60LDRjyDQvtCx0LvQsNGB0YLRjCwg0KPQt9Cx0LXQutC40YHRgtCw0L0!5e1!3m2!1sru!2s!4v1723184562526!5m2!1sru!2s"
                                width="491" height="450" style="border:5;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade">
                            </iframe>
                        </div>
                    </div>
                </div>


            </div>




    </section>
@endsection
