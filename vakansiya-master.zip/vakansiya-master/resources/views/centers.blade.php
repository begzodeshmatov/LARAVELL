@extends('layouts.app')

@section('content')
    <div class="pagetitle">
        <h1>Markazlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/home">Asosiy</a></li>
                <li class="breadcrumb-item active">Markazlqar</li>
                <button type="button" class="btn btn-primary position-absolute translate-middle-x end-0"
                    data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-plus"></i></button>
            </ol>

        </nav>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Markaz kiritish</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="{{ route('center.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div class="mb-3">
                                <label class="form-label">Markaz nomi nomi</label>
                                <input type="text" class="form-control" name="center_name" id=""
                                    placeholder="Markaz nomini " required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">F.I.O</label>
                                <input type="text" class="form-control" name="name" id=""
                                    placeholder="Ism familiya" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Manzil</label>
                                <input type="text" class="form-control" name="address" id=""
                                    placeholder="Manzil" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Tavsifi</label>
                                <input type="text" class="form-control" name="body" id=""
                                    placeholder="Tavsifi" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Quvvati</label>
                                <input type="text" class="form-control" name="power" id=""
                                    placeholder="Quvvati" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Vaqti</label>
                                <input type="text" class="form-control" name="time" id="" placeholder="Vaqti"
                                    required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Telefon raqam</label>
                                <input type="text" class="form-control" name="phon_number" id=""
                                    placeholder="Telefon raqam" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Image</label>
                                <input type="file" class="form-control" name="image" id="" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Saqlash</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="section mt-5">
        <div class="row align-items-top">
            @foreach ($centers as $center)
                <div class="col-lg-4">
                    <!-- Card with an image on top -->
                    <div class="card">
                        <img style="width:100%; height:100%;"
                            src="{{ asset('storage/' . str_replace('public/', '', $center->image)) }}" class="card-img-top"
                            alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><a
                                    href="{{ route('center.show', ['center' => $center->id]) }}">{{ $center->center_name }}</a>
                            </h5>
                            <p class="card-text">
                                {{ $center->name }}
                                <br>
                                {{ $center->address }}
                                <br>
                                {{ $center->phon_number }}
                            </p>
                            <a data-bs-toggle="modal" class="btn btn-primary"
                                data-bs-target="#editCenter{{ $center->id }}" href="#"><i
                                    class='bx bx-pencil'></i></a>
                            <a data-bs-toggle="modal" class="btn btn-danger"
                                data-bs-target="#deleteCenter{{ $center->id }}" href="#"><i
                                    class='bx bx-trash'></i></a>
                            <div class="modal fade" id="deleteCenter{{ $center->id }}" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Haqiqatdan ham {{ $center->name }} ni o'chirmoqchimisiz</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Yo'q</button>
                                            <form action="{{ route('center.destroy', ['center' => $center->id]) }}">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-primary">Ha</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal fade" id="editCenter{{ $center->id }}" tabindex="-1"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Center tahrirlash</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="{{ route('center.update', ['center' => $center->id]) }}"
                                            method="POST" enctype="multipart/form-data">
                                            @csrf
                                            @method('PUT')
                                            <div class="mb-3">
                                                <label class="form-label">Markaz nomi nomi</label>
                                                <input type="text" class="form-control" name="center_name"
                                                    value="{{ $center->center_name }}" placeholder="Markaz nomini "
                                                    required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">F.I.O</label>
                                                <input type="text" class="form-control" name="name"
                                                    value="{{ $center->name }}" placeholder="Ism familiya" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Manzil</label>
                                                <input type="text" class="form-control" name="address"
                                                    value="{{ $center->address }}" placeholder="Manzil" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Tavsifi</label>
                                                <input type="text" class="form-control" name="body"
                                                    value="{{ $center->body }}" placeholder="Tavsifi" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Quvvati</label>
                                                <input type="text" class="form-control" name="power"
                                                    value="{{ $center->power }}" placeholder="Quvvati" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Vaqti</label>
                                                <input type="text" class="form-control" name="time"
                                                    value="{{ $center->time }}" placeholder="Vaqti" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Telefon raqam</label>
                                                <input type="text" class="form-control" name="phon_number"
                                                    value="{{ $center->phon_number }}" placeholder="Telefon raqam"
                                                    required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Image</label>
                                                <input type="file" class="form-control" name="image">
                                            </div>
                                            <button type="submit" class="btn btn-primary">Tahrirlash</button>
                                        </form>
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Markazdagi kasblar</h1>
                                        </div>
                                        <form action="{{ route('center.kasb.store', ['center' => $center->id]) }}"
                                            method="POST">
                                            @csrf
                                            <div class="mb-3">
                                                <label class="form-label">Kasb nomi</label>
                                                <input type="text" class="form-control" name="name"
                                                    placeholder="Kasb nomi" required>
                                            </div>
                                            <button type="submit" class="btn btn-outline-primary">Qo'shish</button>
                                        </form>
                                        <hr>
                                        @foreach ($center->kasbs as $job)
                                            <div class="my-2 row">
                                                <div class="col-8">
                                                    <form action="{{ route('center.kasb.update', ['kasb' => $job->id]) }}" id="jobUpdate{{ $job->id }}"
                                                        method="POST">
                                                        @csrf
                                                        @method('PUT')
                                                        <input type="text" class="form-control" name="name"
                                                            value="{{ $job->name }}" placeholder="Kasb nomi" required>
                                                    </form>
                                                </div>
                                                <div class="col-2">
                                                    <button type="submit" onclick="document.getElementById('jobUpdate{{ $job->id }}').submit()" class="btn btn-outline-success"><i class="bi bi-check"></i></button>
                                                </div>
                                                <div class="col-2">
                                                    <form action="{{ route('center.kasb.destroy', ['kasb' => $job->id]) }}" method="POST">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-outline-danger"><i class="bx bx-trash"></i></button>
                                                    </form>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </section>
@endsection
