@extends('layouts.app')

@section('content')
    <div class="pagetitle">
        <h1>Vakansiyalar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Asosiy</a></li>
                <li class="breadcrumb-item active">Bo'sh ish o'rinlari</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between mb-4">
                            <h5 class="card-title">Bo'sh ish o'rinlari</h5>
                            <div class="d-flex justify-content-end align-items-center">
                                <a href="{{ route('export') }}" class="btn btn-outline-info my-2 mx-2">Export</a>
                                <button class="btn btn-outline-success my-2 mx-2" data-bs-toggle="modal"
                                    data-bs-target="#importVakansiya" href="#">Import</button>
                                <button class="btn btn--add btn btn-primary my-2 mx-2" type="button" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal"><i class="bi bi-plus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="importVakansiya" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Import</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="/import" method="POST" enctype="multipart/form-data">
                                            @csrf
                                            <label class="form-label">File yuklang</label>
                                            <input type="file" class="form-control" name="file">
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Yo'q</button>
                                                <button class="btn btn-primary">Xa</button>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Bo'sh ish o'rni qo'shish
                                        </h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="/vakansiyaSave" class="row" method="POST"
                                            enctype="multipart/form-data">
                                            @csrf
                                            <div class="mb-3">
                                                <label class="form-label">Tashkilot nomi</label>
                                                <input type="text" class="form-control" name="name"
                                                    placeholder="Tashkilot nomi..." required>
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="form-label">Bo'lim nomi</label>
                                                <input type="text" class="form-control" name="b_name"
                                                    placeholder="Bo'lim nomi" required>
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="form-label">Lavozim</label>
                                                <input type="text" class="form-control" name="lavozim"
                                                    placeholder="Lavozim" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Bo'sh ish o'rni</label>
                                                <input type="text" class="form-control" name="ish_orni"
                                                    placeholder="Bo'sh ish o'rni" required>
                                            </div>

                                            <div class="mb-3 col-6">
                                                <label class="form-label">Maosh</label>
                                                <input type="text" class="form-control" name="maosh"
                                                    placeholder="Maosh" required>
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="form-label">Lavozimga qo'yilgan talab</label>
                                                <input type="text" class="form-control" name="talab"
                                                    placeholder="Lavozimga qo'yilgan talab" required>
                                            </div>
                                            <!-- <div class="mb-3">
                                                                                            <label class="form-label">Xudud</label>
                                                                                            <input type="text" class="form-control" name="region_id" placeholder="Viloyat_id" required>
                                                                                        </div> -->
                                            <div class="mb-3 col-6">
                                                <label class="form-label">Tuman</label>
                                                <select class="form-select" name="district_id" id="validationDefault04">
                                                    <option selected disabled value="">Tanlash...</option>
                                                    @foreach ($districts as $district)
                                                        <option value="{{ $district->id }}">{{ $district->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="form-label">Tashkilot turi</label>
                                                <select class="form-select" name="type" id="validationDefault04">
                                                    <option selected disabled value="">Tanlash...</option>
                                                    <option value="0">Budjet</option>
                                                    <option value="1">Xususiy</option>
                                                </select>
                                            </div>
                                            <div class="col-6 mb-3">
                                                <label class="form-label">Soxani tanlang</label>
                                                <select class="form-select" name="field_id" id="fieldSelection">
                                                    <option selected disabled value="0">Tanlash...</option>
                                                    @foreach ($fields as $field)
                                                        <option value="{{ $field->id }}">{{ $field->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-6 mb-3">
                                                <label class="form-label">Kasbni tanlang</label>
                                                <select class="form-select" name="job_id" id="jobSelection">
                                                    <option selected disabled value="">Tanlash...</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Telefon raqam</label>
                                                <input type="text" class="form-control" name="tel_raqam"
                                                    placeholder="Telefon raqam" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Manzil</label>
                                                <textarea class="form-control" name="manzil" placeholder="Manzil" required></textarea>
                                            </div>

                                            <div class="col-12">
                                                <button class="btn btn-primary">Qo'shish</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">№</th>
                                        <th scope="col">Tashkilot nomi</th>
                                        <th scope="col">Bo'lim nomi</th>
                                        <th scope="col">Lavozimi</th>
                                        <th scope="col">Bo'sh ish o'rni</th>
                                        <th scope="col">Telefon raqam</th>
                                        <th scope="col">Manzil</th>
                                        <th scope="col">Maosh</th>
                                        <th scope="col">Talablar</th>
                                        <th scope="col">Xudud</th>
                                        <th scope="col">Tuman</th>
                                        <th scope="col">Kasblar</th>
                                        <th scope="col">Soxalar</th>
                                        <th scope="col">Tashkilot turi</th>
                                        <th scope="col">Amallar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($vacancies as $vacancy)
                                        <tr>
                                            <th scope="row">{{ $vacancy->id }}</th>
                                            <td>{{ $vacancy->name }}</td>
                                            <td>{{ $vacancy->b_name }}</td>
                                            <td>{{ $vacancy->lavozim }}</td>
                                            <td>{{ $vacancy->ish_orni }}</td>
                                            <td>{{ $vacancy->tel_raqam }}</td>
                                            <td>{{ $vacancy->manzil }}</td>
                                            <td>{{ $vacancy->maosh }}</td>
                                            <td>{{ $vacancy->talab }}</td>
                                            <td>{{ $vacancy->region->name }}</td>
                                            <td>{{ $vacancy->district->name }}</td>
                                            <td>{{ $vacancy->job->name }}</td>
                                            <td>{{ $vacancy->job->field->name }}</td>
                                            <td>
                                                @if ($vacancy->type == 0)
                                                    Byudjet
                                                @else
                                                    Xususiy
                                                @endif
                                            </td>
                                            <td>
                                                <a data-bs-toggle="modal" class="btn btn-primary"
                                                    data-bs-target="#editVacancy{{ $vacancy->id }}" href="#"><i
                                                        class='bx bx-pencil'></i></a>
                                                <a data-bs-toggle="modal" class="btn btn-danger"
                                                    data-bs-target="#deleteVakansiya{{ $vacancy->id }}"
                                                    href="#"><i class='bx bx-trash'></i></a>
                                            </td>
                                        </tr>
                                    @endforeach

                                </tbody>
                            </table>
                        </div>
                        @foreach ($vacancies as $vacancy)
                            <div class="modal fade" id="deleteVakansiya{{ $vacancy->id }}" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Haqiqatdan ham {{ $vacancy->name }} ni o'chirmoqchimisiz</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-bs-dismiss="modal">Yo'q</button>
                                            <a href="/deletevakansiya/{{ $vacancy->id }}" class="btn btn-primary">Xa</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="editVacancy{{ $vacancy->id }}" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Bo'sh ish
                                                o'rnini tahrirlash
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="/vakansiyaEditSave/{{ $vacancy->id }}" class="row"
                                                method="POST" enctype="multipart/form-data">
                                                @csrf
                                                <div class="mb-3">
                                                    <label class="form-label">Tashkilot nomi</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $vacancy->name }}" name="name"
                                                        placeholder="Tashkilot nomi..." required>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Bo'lim nomi</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $vacancy->b_name }}" name="b_name"
                                                        placeholder="Bo'lim nomi" required>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Lavozim</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $vacancy->lavozim }}" name="lavozim"
                                                        placeholder="Lavozim" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Bo'sh ish o'rni</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $vacancy->ish_orni }}" name="ish_orni"
                                                        placeholder="Bo'sh ish o'rni" required>
                                                </div>

                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Maosh</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $vacancy->maosh }}" name="maosh" placeholder="Maosh"
                                                        required>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Lavozimga qo'yilgan
                                                        talab</label>
                                                    <input type="text" class="form-control"
                                                        value="{{ $vacancy->talab }}" name="talab"
                                                        placeholder="Lavozimga qo'yilgan talab" required>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Tuman</label>
                                                    <select class="form-select" name="district_id"
                                                        id="validationDefault04">
                                                        <option selected disabled value="">Tanlash...
                                                        </option>
                                                        @foreach ($districts as $district)
                                                            <option value="{{ $district->id }}"
                                                                {{ $vacancy->district->id == $district->id ? 'selected' : '' }}>
                                                                {{ $district->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Tashkilot turi</label>
                                                    <select class="form-select" name="type" id="validationDefault04">
                                                        <option selected disabled value="">Tanlash...
                                                        </option>
                                                        <option value="0"
                                                            {{ $vacancy->type == 0 ? 'selected' : '' }}>Budjet
                                                        </option>
                                                        <option value="1"
                                                            {{ $vacancy->type == 1 ? 'selected' : '' }}>Xususiy
                                                        </option>
                                                    </select>
                                                </div>
                                                <div class="col-6 mb-3">
                                                    <label class="form-label">Soxani tanlang</label>
                                                    <select class="form-select" name="field_id" id="fieldSelection">
                                                        <option selected disabled value="0">Tanlash...
                                                        </option>
                                                        @foreach ($fields as $field)
                                                            <option value="{{ $field->id }}"
                                                                {{ $vacancy->job->field->id == $field->id ? 'selected' : '' }}>
                                                                {{ $field->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="col-6 mb-3">
                                                    @php
                                                        $jobs = $vacancy->job->field->jobs;
                                                    @endphp
                                                    <label class="form-label">Kasbni tanlang</label>
                                                    <select class="form-select" name="job_id" id="jobSelection">
                                                        <option selected disabled value="">Tanlash...
                                                        </option>
                                                        @foreach ($jobs as $job)
                                                            <option value="{{ $job->id }}"
                                                                {{ $vacancy->job->id == $job->id ? 'selected' : '' }}>
                                                                {{ $job->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Telefon raqam</label>
                                                    <input type="text" class="form-control" name="tel_raqam"
                                                        placeholder="Telefon raqam" value="{{ $vacancy->tel_raqam }}"
                                                        required>
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label">Manzil</label>
                                                    <textarea class="form-control" name="manzil" placeholder="Manzil" required>{{ $vacancy->manzil }}</textarea>
                                                </div>

                                                <div class="col-12">
                                                    <button class="btn btn-primary">Saqlash</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    {{ $vacancies->links() }}
                </div>
            </div>
        </div>
    </section>
    <script>
        var url = "{{ url('/') }}";
    </script>

    <script src="{{ asset('js/fetch.js') }}"></script>
@endsection
