@extends('layouts.app')

@section('content')
    <div class="pagetitle">
        <h1>Loyihani tahrirlash</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('vacancies') }}">Asosiy</a></li>
                <li class="breadcrumb-item active">Akkaunt ma'lumotlarini o'zgartirish</li>
            </ol>
        </nav>
    </div>
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle me-1"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-octagon me-1"></i>
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <section class="section">
        <div class="row">
            <div class="col-xxl-8 col-12">
                <div class="card ">
                    <div class="card-body col">
                        <h5 class="card-title">Akkaunt ma'lumotlarini o'zgartirish</h5>
                        <form action="{{ route('profile.update', ['user' => $user->id]) }}" method="POST" class="row"
                            enctype="multipart/form-data">
                            @csrf
                            @method('PUT')
                            <div class="mb-3 col-md-6 col-12">
                                <label class="form-label">Ismi</label>
                                <input type="text" class="form-control" name="name" placeholder="Ismi"
                                    value="{{ $user->name }}" required>
                            </div>
                            <div class="mb-3 col-md-6 col-12">
                                <label class="form-label">Email manzili</label>
                                <input type="email" class="form-control" name="email" placeholder="Email manzili"
                                    value="{{ $user->email }}" required>
                            </div>
                            <div class="model-footer">
                                <button class="btn btn-primary">Saqlash</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-xxl-8 col-12">
                <div class="card ">
                    <div class="card-body col">
                        <h5 class="card-title">Parolni o'zgartirish</h5>
                        <form action="{{ route('profile.password', ['user' => $user->id]) }}" method="POST"
                            enctype="multipart/form-data">
                            @csrf
                            @method('PUT')
                            <div class="mb-3 col-md-6 col-12">
                                <label class="form-label">Eski parolingiz</label>
                                <input type="password" class="form-control" name="old_password" placeholder="Parol"
                                    required>
                            </div>
                            <div class="mb-3 col-md-6 col-12">
                                <label class="form-label">Yangi parolingiz</label>
                                <input type="password" class="form-control" name="password" placeholder="Yangi parolingiz"
                                    required>
                            </div>
                            <div class="mb-3 col-md-6 col-12">
                                <label class="form-label">Parolni takroran kiriting</label>
                                <input type="password" class="form-control" name="password_confirmation"
                                    placeholder="Parolni takroran kiriting" required>
                            </div>
                            <div class="model-footer">
                                <button class="btn btn-primary">Saqlash</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    </section>
@endsection
