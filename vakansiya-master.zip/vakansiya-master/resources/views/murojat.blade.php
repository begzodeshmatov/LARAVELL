@extends('layouts.app')

@section('content')
    <div class="pagetitle">
        <h1>Murojaatlar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Asosiy</a></li>
                <li class="breadcrumb-item active">Murojaatlar</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Kelgan murojaatlar</h5>
                        <button style="margin-left:1095px; margin-top:-100px;" class="btn btn--add btn btn-primary"
                            type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                class="bi bi-plus"></i></button>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Murojaat Qo'shish</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="/murojatSave" method="POST" enctype="multipart/form-data">
                                            @csrf
                                            <div class="mb-3">
                                                <label class="form-label">Ismi</label>
                                                <input type="text" class="form-control" name="ismi" placeholder="Ism"
                                                    required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Telefon raqami</label>
                                                <input type="tel" class="form-control" name="tel_raqam"
                                                    placeholder="Telefon raqam" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Murojaat matni</label>
                                                <input type="text" class="form-control" name="murojat_matni"
                                                    placeholder="Murojaat matni" required>
                                            </div>
                                            <button class="btn btn-primary">Qo'shish</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Default Table -->
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">№</th>
                                    <th scope="col">Ismi</th>
                                    <th scope="col">Telefon raqam</th>
                                    <th scope="col">Murojaat matni</th>
                                    <th scope="col">Amallar</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($murojaats as $murojat)
                                    <tr>
                                        <th scope="row">{{ $murojat->id }}</th>
                                        <td>{{ $murojat->ismi }}</td>
                                        <td>{{ $murojat->tel_raqam }}</td>
                                        <td>{{ $murojat->murojat_matni }}</td>
                                        <td>
                                            <a data-bs-toggle="modal" class="btn btn-primary"
                                                data-bs-target="#exampleModal{{ $murojat->id }}" href="#"><i
                                                    class='bx bx-pencil'></i></a>
                                            <a data-bs-toggle="modal" class="btn btn-danger"
                                                data-bs-target="#deleteMurojat{{ $murojat->id }}" href="#"><i
                                                    class='bx bx-trash'></i></a>

                                            <!-- Modal -->

                                            <div class="modal fade" id="exampleModal{{ $murojat->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Murojaat
                                                                Edit</h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="/murojatEditSave/{{ $murojat->id }}"
                                                                method="POST">
                                                                @csrf
                                                                <div class="mb-3">
                                                                    <label class="form-label">Ismi</label>
                                                                    <input type="text" class="form-control"
                                                                        name="ismi" value="{{ $murojat->ismi }}">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label class="form-label">Telefon raqami</label>
                                                                    <input type="text" class="form-control"
                                                                        name="tel_raqam" value="{{ $murojat->tel_raqam }}">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label class="form-label">Murojaat matni</label>
                                                                    <input type="text" class="form-control"
                                                                        name="murojat_matni"
                                                                        value="{{ $murojat->murojat_matni }}">
                                                                </div>
                                                                <button class="btn btn-primary">Tahrirlash</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Modal -->
                                            <div class="modal fade" id="deleteMurojat{{ $murojat->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                O'chirish</h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Haqiqatdan ham {{ $murojat->ismi }} ni o'chirmoqchimisiz
                                                            </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Yo'q</button>
                                                            <a href="/deletemurojat/{{ $murojat->id }}"
                                                                class="btn btn-primary">Xa</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                @endforeach


                            </tbody>

                        </table>
                        <!-- End Default Table Example -->
                    </div>
                </div>

            </div>


        </div>
    </section>
@endsection
