@extends('layouts.app')

@section('content')
    <div class="pagetitle">
        <h1>Kasblar</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Asosiy</a></li>
                <li class="breadcrumb-item active">Kasblar</li>
            </ol>
        </nav>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Kasblar va ularning soxasi</h5>
                        <button style="margin-left:1095px; margin-top:-100px;" class="btn btn--add btn btn-primary"
                            type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                class="bi bi-plus"></i></button>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Kasb qo'shish
                                        </h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="/jobs" class="row" method="POST" enctype="multipart/form-data">
                                            @csrf
                                            <div class="mb-3 col-6">
                                                <label class="form-label">Soxalar</label>
                                                <select class="form-select" name="field_id" id="validationDefault04">
                                                    <option selected disabled value="">Tanlash...</option>
                                                    @foreach ($fields as $filed)
                                                        <option value="{{ $filed->id }}">{{ $filed->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Kasb nomi</label>
                                                <input type="text" class="form-control" name="name"
                                                    placeholder="Kasb nomini kiriting" required>
                                            </div>
                                            <div class="col-12">
                                                <button class="btn btn-primary">Qo'shish</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">№</th>
                                    <th scope="col">Kasb nomi</th>
                                    <th scope="col">Soxasi</th>
                                    <th scope="col">Amallar</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($jobs as $job)
                                    <tr>
                                        <th scope="row">{{ $job->id }}</th>
                                        <td>{{ $job->name }}</td>
                                        <td>{{ $job->field->name }}</td>
                                        <td>
                                            <a data-bs-toggle="modal" class="btn btn-primary"
                                                data-bs-target="#editJob{{ $job->id }}" href="#"><i
                                                    class='bx bx-pencil'></i></a>
                                            <a data-bs-toggle="modal" class="btn btn-danger"
                                                data-bs-target="#deleteJob{{ $job->id }}" href="#"><i
                                                    class='bx bx-trash'></i></a>
                                            <!-- Modal -->
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="editJob{{ $job->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Kasbni
                                                        taxrirlash</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="/jobs/{{ $job->id }}" method="POST">
                                                        @method('PUT')
                                                        @csrf
                                                        <div class="mb-3">
                                                            <label class="form-label">Name</label>
                                                            <input type="text" class="form-control" name="name"
                                                                value="{{ $job->name }}" placeholder="Ism">
                                                        </div>
                                                        <button class="btn btn-primary">Tahrirlash</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                    <div class="modal fade" id="deleteJob{{ $job->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Haqiqatdan ham {{ $job->name }} ni o'chirmoqchimisiz</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Yo'q</button>
                                                    <form action="/jobs/{{ $job->id }}" method="POST">
                                                        @method('DELETE')
                                                        @csrf
                                                        <button type="submit" class="btn btn-primary">Ha</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        </div>
    </section>
@endsection
