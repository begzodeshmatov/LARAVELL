<?php

use App\Http\Controllers\api\VacanciesController;
use App\Http\Controllers\api\DistrictController;
use App\Http\Controllers\api\AppealsController;
use App\Http\Controllers\api\CenterController;
use App\Http\Controllers\api\RegionsController;
use App\Http\Controllers\api\FieldsController;
use App\Http\Controllers\api\JobsController;
use Illuminate\Support\Facades\Route;

Route::prefix('regions')->group(function() {
    Route::get('/', [RegionsController::class, 'index']);
    Route::get('/{region}', [RegionsController::class, 'show']);
});

Route::prefix('districts')->group(function() {
    Route::get('/', [DistrictController::class, 'index']);
    Route::get('/{district}', [DistrictController::class, 'show']);
});

Route::prefix('fields')->group(function() {
    Route::get('/', [FieldsController::class, 'index']);
    Route::get('/{field}', [FieldsController::class, 'show']);
    Route::get('/job/{field}', [FieldsController::class, "jobs"]);
});

Route::prefix('jobs')->group(function() {
    Route::get('/', [JobsController::class, 'index']);
    Route::get('/{job}', [JobsController::class, 'show']);
    Route::get('/field/{job}', [JobsController::class, "field"]);
});

Route::prefix('centers')->group(function() {
    Route::get('/', [CenterController::class, 'index']);
    Route::get('/{center}', [CenterController::class, 'show']);
});

Route::prefix('vacancies')->group(function() {
    Route::get('/', [VacanciesController::class, 'index']);
    Route::get('/count', [VacanciesController::class, 'count']);
    Route::get('/{vacancy}', [VacanciesController::class, 'show']);
    Route::get('/region/{region}', [VacanciesController::class, 'byRegion']);
    Route::get('/district/{district}', [VacanciesController::class, 'byDistrict']);
    Route::get('/{district}/{job}/{type}', [VacanciesController::class, 'main']);

});

Route::post('appeals', [AppealsController::class, 'store']);
