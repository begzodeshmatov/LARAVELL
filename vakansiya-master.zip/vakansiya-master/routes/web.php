<?php

use App\Http\Controllers\CenterController;
use App\Http\Controllers\JobsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VakansiyaController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});
Auth::routes();
Route::get('/register', function () {
    return redirect()->route('login');
});

Route::get('/home', 'VakansiyaController@ishorni');

Route::get('/murojaats', 'MurojaatController@murojaats');
Route::post('/murojatSave', 'MurojaatController@murojatSave');
Route::post('/murojatEditSave/{id}', 'MurojaatController@murojatEditSave');
Route::get('/deletemurojat/{id}', 'MurojaatController@murojatDelete');

Route::get('/vakansiyalar', 'VakansiyaController@ishorni')->name('vacancies');
Route::post('/vakansiyaSave', 'VakansiyaController@vakansiyaSave');
Route::post('/vakansiyaEditSave/{id}', 'VakansiyaController@vakansiyaEditSave');
Route::get('/deletevakansiya/{id}', 'VakansiyaController@vakansiyaDelete');

Route::get('/export', [VakansiyaController::class, 'export'])->name('export');
Route::post('/import', [VakansiyaController::class, 'import'])->name('import');
Route::prefix('jobs')->group(function() {
    Route::get('/', [JobsController::class, 'index']);
    Route::post('/', [JobsController::class, 'store']);
    Route::put('/{job}', [JobsController::class, 'update']);
    Route::delete('/{job}', [JobsController::class, 'destroy']);
});

Route::prefix('users')->group(function () {
    Route::get('/', [UserController::class, 'index'])->name('user.index');
    Route::post('/', [UserController::class, 'store'])->name('user.store');
    Route::put('/{user}', [UserController::class, 'update'])->name('user.update');
    Route::delete('/{user}', [UserController::class, 'destroy'])->name('user.destroy');
    Route::put('/restore/{user}', [UserController::class, 'restore'])->name('user.restore');
});

Route::prefix('profile')->group(function () {
    Route::get('/', [ProfileController::class, 'show'])->name('profile.show');
    Route::put('/', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/password', [ProfileController::class, 'password'])->name('profile.password');
    Route::delete('/', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::prefix('centers')->group(function () {
    Route::get('/', [CenterController::class, 'index'])->name('center.index');
    Route::get('/{center}', [CenterController::class, 'show'])->name('center.show');
    Route::post('/kasb/{center}/store', [CenterController::class, 'kasbStore'])->name('center.kasb.store');
    Route::post('/', [CenterController::class, 'store'])->name('center.store');
    Route::put('/kasb/{kasb}', [CenterController::class, 'kasbUpdate'])->name('center.kasb.update');
    Route::put('/{center}', [CenterController::class, 'update'])->name('center.update');
    Route::delete('/kasb/{kasb}', [CenterController::class, 'kasbDestroy'])->name('center.kasb.destroy');
    Route::delete('/{center}', [CenterController::class, 'destroy'])->name('center.destroy');
});
