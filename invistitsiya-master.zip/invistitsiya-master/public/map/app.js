var map = L.map('map').setView([41.308752, 63.223529], 6);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'Map data © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
}).addTo(map);

var currentRegionLayer = null;
var uzbekistanLayer = null;
var cityLayerGroup = null;
let marker;
var cityMarkersGroup = L.layerGroup(); // A layer group for city markers

var info = L.control();

info.onAdd = function (map) {
    this._div = L.DomUtil.create('div', 'info');
    this.update();
    return this._div;
};

info.update = async function (props) {
    this._div.innerHTML = (props ? `<b>${props.ADM2_UZ}</b><br />` : 'Hover over a region');
};

info.addTo(map);
map.setMaxZoom(10);

fetch('./geojsonfile/uzbekistan_regional.geojson')
    .then(response => response.json())
    .then(data => {
        createRepublicLayer(data);

        var title = L.control();
        title.onAdd = function (map) {
            var div = L.DomUtil.create('div', 'info');
            return div;
        };
        title.addTo(map);

        async function loadCityData(regionID) {
            try {
                const response = await fetch(`./geojsonfile/${getDistricts(regionID)}`);
                return await response.json();
            } catch (error) {
                console.error('Error loading city data:', error);
                throw error;
            }
        }

        function setRepublicLayer() {
            if (uzbekistanLayer && !map.hasLayer(uzbekistanLayer)) {
                uzbekistanLayer.addTo(map);
            }
            console.log(map.hasLayer(uzbekistanLayer));
        }

        setRepublicLayer();

        function createCityMarkers(cityData) {
            cityMarkersGroup.clearLayers();
            map.addLayer(cityMarkersGroup);
        }
        function createCityLayer(cityData) {
            if (cityLayerGroup) {
                map.removeLayer(cityLayerGroup);
            }

            cityLayerGroup = L.layerGroup();

            var marker; // Declare marker inside the function

            var cityLayer = L.geoJSON(cityData, {
                style: {
                    color: '#73a4ff',
                    weight: 2,
                    fillColor: '#73a4ff',
                    fillOpacity: 0.3,
                }
            });

            cityLayer.eachLayer(function (city) {
                city.on('mouseover', function (e) {
                    var layer = e.target;
                    layer.setStyle({ TransitionEvent: "1s", fillColor: '#ff6803', color: '#ff6803', fillOpacity: 0.6 });
                    info.update(layer.feature.properties);
                    console.log(layer.feature.properties)
                });

                city.on('mouseout', function (e) {
                    var layer = e.target;
                    layer.setStyle({ color: '#73a4ff', fillColor: '#73a4ff', fillOpacity: 0.3 });
                });

                city.on('click', function (e) {
                    map.setView([41.308752, 63.223529], 6); // Zoom out to the initial view coordinates
                    cityMarkersGroup.clearLayers(); // Remove city markers
                    if (marker) {
                        map.removeLayer(marker);
                    }

                    if (currentRegionLayer) {
                        map.removeLayer(currentRegionLayer);
                        createRepublicLayer(data);
                    }
                    let div = document.querySelectorAll('.population-marker2');
                    div.forEach(element => {
                        element.parentNode.removeChild(element);
                    });


                });
                const center = city.getBounds().getCenter();
                const ADM = getDisPopulation(city.feature.properties.ADM2_UZ);
                const popul = typeof ADM == "number" ? ADM : ADM[0]
                const org = typeof ADM == "number" ? false : true

                marker = new L.marker(center, {
                    icon: L.divIcon({
                        className: org ? "population-marker3" : "population-marker2",
                        html: `<p class='population'>${popul}<p>`
                    })
                }).addTo(map);




            });

            cityLayerGroup.addLayer(cityLayer);
            cityLayerGroup.addTo(map);

            return cityLayer;
        }


        async function setRepublicLayer() {
            if (uzbekistanLayer && !map.hasLayer(uzbekistanLayer)) {
                uzbekistanLayer.addTo(map);
                console.log(map.hasLayer(uzbekistanLayer));
            }
        }

        function bindUzbekistanLayerEvents() {
            uzbekistanLayer.eachLayer(function (layer) {


                const population = getPopulation(layer.feature.properties.id);
                const center = layer.getBounds().getCenter();
                L.marker(center, {
                    icon: L.divIcon({
                        className: 'population-marker',
                        html: `<p class='population'>${population}</p>`
                    })
                }).addTo(map);

                layer.on('click', function (e) {
                    var layer = e.target;

                    if (currentRegionLayer) {
                        map.removeLayer(currentRegionLayer);
                    }

                    map.eachLayer(function (layer) {
                        if (layer !== uzbekistanLayer) {
                            map.removeLayer(layer);
                        }
                    });

                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: 'Map data © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
                    }).addTo(map);

                    loadCityData(layer.feature.properties.id)
                        .then(cityData => {
                            var cityLayer = createCityLayer(cityData);
                            cityLayer.addTo(map);

                            map.flyToBounds(layer.getBounds(), { duration: 1 });  // Fly to the bounds of the region
                            currentRegionLayer = cityLayer;
                            createCityMarkers(cityData);
                        })
                        .catch(error => console.error('Error loading city data:', error));
                });

                layer.on('mouseover', function (e) {
                    var layer = e.target;
                    layer.setStyle({ TransitionEvent: "1s", color: '#ff6803', fillColor: '#ff6803', fillOpacity: 0.4, weight: 3 });
                    info.update(layer.feature.properties);

                    // showMarker(layer); // Вызываем функцию showMarker при наведении на регион
                });

                layer.on('mouseout', function (e) {
                    var layer = e.target;
                    layer.setStyle({
                        color: '#73a4ff',
                        weight: 2,
                        fillColor: '#73a4ff',
                        fillOpacity: 0.3,
                    });

                    info.update();
                });
            });


        }

        bindUzbekistanLayerEvents();

        function createRepublicLayer(data) {
            if (cityLayerGroup) {
                map.removeLayer(cityLayerGroup);
                cityLayerGroup = null;
            }

            if (currentRegionLayer) {
                map.removeLayer(currentRegionLayer);
                currentRegionLayer = null;
            }

            if (uzbekistanLayer) {
                uzbekistanLayer.addTo(map);
            }

            uzbekistanLayer = L.geoJSON(data.features, {
                style: {
                    color: '#73a4ff',
                    weight: 2,
                    fillColor: '#73a4ff',
                    fillOpacity: 0.3,

                }
            });

            uzbekistanLayer.addTo(map);

            bindUzbekistanLayerEvents();
        }
    })
    .catch(error => console.error('Error loading Uzbekistan geojson:', error));

function getPopulation(id) {
    var populations = {
        "1": "10",
        "2": "10",
        "3": "10",
        "4": "10",
        "5": "10",
        "6": "10",
        "7": "10",
        "8": "10",
        "9": "10",
        "10": "10",
        "11": "10",
        "12": "10",
        "13": "10",
        "14": "10",
    };

    return populations[id] || [];
}

function getDistricts(id) {
    var cityCoordinates = {
        "1": "andijon_region_districts.geojson",
        "2": "bukhara_region_districts.geojson",
        "3": "jizzakh_region_districts.geojson",
        "4": "qashqadaryo.geojson",
        "5": "navoiy_region_districts.geojson",
        "6": "namangan.geojson",
        "7": "samarqand_region_districts.geojson",
        "8": "surkhandarya_region_districts.geojson",
        "9": "sirdaryo_region_districts.geojson",
        "10": "tashkent_region_districts.geojson",
        "11": "fargona_region_districts.geojson",
        "12": "xorazm_region_districts.geojson",
        "13": "karakalpak.geojson",
        "14": "tashkent_districts.geojson",
    };

    return cityCoordinates[id] || [];
}

function getDisPopulation(name) {
    var populations = {
        "Ulug'nor": [Math.floor(Math.random() * 100), true],
        "Qo;rgontepa": Math.floor(Math.random() * 100),
        "Jalaquruq": Math.floor(Math.random() * 100),
        "Xo'jaobod": Math.floor(Math.random() * 100),
        "Buloqbosh": Math.floor(Math.random() * 100),
        "Marhamat": Math.floor(Math.random() * 100),
        "Asaka": Math.floor(Math.random() * 100),
        "Shahrixon": Math.floor(Math.random() * 100),
        "Bo'z": Math.floor(Math.random() * 100),
        "Baliqchi": Math.floor(Math.random() * 100),
        "Oltinko'l": Math.floor(Math.random() * 100),
        "Andijon": Math.floor(Math.random() * 100),
        "Izboskan": Math.floor(Math.random() * 100),
        "Paxtaobod": Math.floor(Math.random() * 100),
        "Arnasoy tumani": Math.floor(Math.random() * 100),
        "Baxmal tumani": Math.floor(Math.random() * 100),
        "Do'stlik tumani": Math.floor(Math.random() * 100),
        "Forish tumani": Math.floor(Math.random() * 100),
        "G'allaorol tumani": Math.floor(Math.random() * 100),
        "Sharof Rashidov tumani": Math.floor(Math.random() * 100),
        "Mirzacho'l tumani": Math.floor(Math.random() * 100),
        "Paxtakor tumani": Math.floor(Math.random() * 100),
        "Yangiobod tumani": Math.floor(Math.random() * 100),
        "Zomin tumani": Math.floor(Math.random() * 100),
        "Zafarobod tumani": Math.floor(Math.random() * 100),
        "Zarbdor tumani": Math.floor(Math.random() * 100),
        "Jizzax shahri": [Math.floor(Math.random() * 100), true],
        "Qarshi tumani": Math.floor(Math.random() * 100),
        "Ko'kdala tumani": Math.floor(Math.random() * 100),
        "Koson tumani": Math.floor(Math.random() * 100),
        "Kasbi tumani": Math.floor(Math.random() * 100),
        "Mirishkor tumani": Math.floor(Math.random() * 100),
        "Muborak tumani": Math.floor(Math.random() * 100),
        "Nuriston tumani": Math.floor(Math.random() * 100),
        "Chiroqchi tumani": Math.floor(Math.random() * 100),
        "Kitob tumani": Math.floor(Math.random() * 100),
        "Kattaqurg'on": Math.floor(Math.random() * 100),
        "Payariq": Math.floor(Math.random() * 100),
        "Bulung'ur": Math.floor(Math.random() * 100),
        "Urgut": Math.floor(Math.random() * 100),
        "Qushrobot": Math.floor(Math.random() * 100),
        "Ishtixon": Math.floor(Math.random() * 100),
        "Oqdaryo": Math.floor(Math.random() * 100),
        "Samarqand": Math.floor(Math.random() * 100),
        "Toyloq": Math.floor(Math.random() * 100),
        "Pastdarg'om": Math.floor(Math.random() * 100),
        "Narpay": Math.floor(Math.random() * 100),
        "Nurobod": Math.floor(Math.random() * 100),
        "Boyovut tumani": Math.floor(Math.random() * 100),
        "Guliston tumani": Math.floor(Math.random() * 100),
        "Mirzaobod tumani": Math.floor(Math.random() * 100),
        "Oqoltin tumani": Math.floor(Math.random() * 100),
        "Sardoba tumani": Math.floor(Math.random() * 100),
        "Sayxunobod tumani": Math.floor(Math.random() * 100),
        "Sirdaryo tumani": Math.floor(Math.random() * 100),
        "Xovos tumani": Math.floor(Math.random() * 100),
        "Guliston shahri": Math.floor(Math.random() * 100),
        "Yangiyer shahri": Math.floor(Math.random() * 100),
        "Shirin shahri": Math.floor(Math.random() * 100),
        "Dang'ara": Math.floor(Math.random() * 100),
        "Yozovon": Math.floor(Math.random() * 100),
        "Quva": Math.floor(Math.random() * 100),
        "Toshloq": Math.floor(Math.random() * 100),
        "Farg'ona": Math.floor(Math.random() * 100),
        "Oltiariq": Math.floor(Math.random() * 100),
        "Buvayda": Math.floor(Math.random() * 100),
        "Bog'dod": Math.floor(Math.random() * 100),
        "Rishot": Math.floor(Math.random() * 100),
        "Sux": Math.floor(Math.random() * 100),
        "Uchko'pkik": Math.floor(Math.random() * 100),
        "O'zbekiston": Math.floor(Math.random() * 100),
        "Furqat": Math.floor(Math.random() * 100),
        "Nukus": Math.floor(Math.random() * 100),
        "Chinoz tumani": Math.floor(Math.random() * 100),
        "Qibray tumani": Math.floor(Math.random() * 100),
        "Ohangaron tumani": Math.floor(Math.random() * 100),
        "Oqqo'rg'on tumani": Math.floor(Math.random() * 100),
        "Parkent tumani": Math.floor(Math.random() * 100),
        "Piskent tumani": Math.floor(Math.random() * 100),
        "Quyi Chirchiq tumani": Math.floor(Math.random() * 100),
        "O'rta Chirchiq tumani": Math.floor(Math.random() * 100),
        "Yangiyo'l tumani": Math.floor(Math.random() * 100),
        "Yuqori Chirchiq tumani": Math.floor(Math.random() * 100),
        "Zangiota tumani": Math.floor(Math.random() * 100),
        "Toshkent tumani": Math.floor(Math.random() * 100),
        "Olmaliq shahri": Math.floor(Math.random() * 100),
        "Angren shahri": Math.floor(Math.random() * 100),
        "Bekobod shahri": Math.floor(Math.random() * 100),
        "Ohangaron shahri": Math.floor(Math.random() * 100),
        "Nurafshon shahri": Math.floor(Math.random() * 100),
        "Chirchiq shahri": Math.floor(Math.random() * 100),
        "Yangiyo'l shahri": Math.floor(Math.random() * 100),
        "Dang'ara": Math.floor(Math.random() * 100),
        "Yozovon": Math.floor(Math.random() * 100),
        "Quva": Math.floor(Math.random() * 100),
        "Toshloq": Math.floor(Math.random() * 100),
        "Farg'ona": Math.floor(Math.random() * 100),
        "Oltiariq": Math.floor(Math.random() * 100),
        "Buvayda": Math.floor(Math.random() * 100),
        "Bog'dod": Math.floor(Math.random() * 100),
        "Rishot": Math.floor(Math.random() * 100),
        "Sux": Math.floor(Math.random() * 100),
        "Uchko'pkik": Math.floor(Math.random() * 100),
        "O'zbekiston": Math.floor(Math.random() * 100),
        "Furqat": Math.floor(Math.random() * 100),
        "Nukus": Math.floor(Math.random() * 100),
        "Takhiatash": Math.floor(Math.random() * 100),
        "Elikkala": Math.floor(Math.random() * 100),
        "Beruni": Math.floor(Math.random() * 100),
        "Turtkul": Math.floor(Math.random() * 100),
        "Takhtakupir": Math.floor(Math.random() * 100),
        "Karauzyak": Math.floor(Math.random() * 100),
        "Chimbay": Math.floor(Math.random() * 100),
        "Shumanai": Math.floor(Math.random() * 100),
        "Hojeili": Math.floor(Math.random() * 100),
        "Kegali": Math.floor(Math.random() * 100),
        "Kanlikkul": Math.floor(Math.random() * 100),
        "Bozatau": Math.floor(Math.random() * 100),
        "Muynak": Math.floor(Math.random() * 100),
        "Kungrad": Math.floor(Math.random() * 100),
        "Bektemir tumani": Math.floor(Math.random() * 100),
        "Chilonzor tumani": Math.floor(Math.random() * 100),
        "Mirobod tumani": Math.floor(Math.random() * 100),
        "Mirzo Ulug'bek tumani": Math.floor(Math.random() * 100),
        "Olmazor tumani": Math.floor(Math.random() * 100),
        "Sergeli tumani": Math.floor(Math.random() * 100),
        "Shayxontohur tumani": Math.floor(Math.random() * 100),
        "Uchtepa tumani": Math.floor(Math.random() * 100),
        "Yakkasaroy tumani": Math.floor(Math.random() * 100),
        "Yangihayot tumani": Math.floor(Math.random() * 100),
        "Yashnobod tumani": Math.floor(Math.random() * 100),
        "Yunusobod tumani": Math.floor(Math.random() * 100),
    };
    return populations[name] || 8;
}

// Example usage:
console.log(getDisPopulation("Ulug'nor"));
