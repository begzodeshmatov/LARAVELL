function formatCurrency(value) {
    let number = parseFloat(value);

    // Butun sonlar uchun formatlash
    if (Number.isInteger(number)) {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');  // Butun sonlar uchun bo'sh joy qo'yish
    } else {
        // Kasrli sonlar uchun formatlash
        let parts = number.toFixed(4).split('.'); // To'rt kasrli raqamgacha aniqlik bilan ajratish
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');  // Butun qismini bo'sh joylar bilan formatlash
        parts[1] = parts[1].replace(/0+$/, '');  // Kasr qismidagi ortiqcha nol raqamlarini olib tashlash
        return parts.join('.');  // Butun va kasr qismlarini '.' bilan birlashtirish
    }
}

function formatElements() {
    const elements = document.querySelectorAll('[id^="irregularPrice"]');
    elements.forEach(element => {
        const rawValue = element.getAttribute('data-price');
        if (rawValue) {
            const formattedValue = formatCurrency(rawValue);
            element.textContent = formattedValue;
        }
    });
}

document.addEventListener("DOMContentLoaded", formatElements);
