document.addEventListener("DOMContentLoaded", async function () {
    var district = document.querySelector('#district');
    var sector = document.querySelector('#sector');
    var company = document.querySelector('#company');

    sector.addEventListener("change", async (e) => {
        if (district.value) {
            try {
                const response = await fetch(`${url}/api/companies/${district.value}/${e.target.value}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const result = await response.json();

                company.innerHTML = '';

                var opt = document.createElement('option');
                opt.textContent = "Tanlash...";
                opt.disabled = true;
                opt.selected = true;
                company.appendChild(opt);
                result.data.forEach(job => {
                    const option = document.createElement('option');
                    option.value = job.id;
                    option.textContent = job.name;
                    company.appendChild(option);
                });

            } catch (error) {
                console.error('Fetch xatosi:', error);
            }
        }
    });

    district.addEventListener("change", async (e) => {
        if (sector.value) {
            try {
                const response = await fetch(`${url}/api/companies/${e.target.value}/${sector.value}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const result = await response.json();

                company.innerHTML = '';

                var opt = document.createElement('option');
                opt.textContent = "Tanlash...";
                opt.disabled = true;
                opt.selected = true;
                company.appendChild(opt);
                result.data.forEach(job => {
                    const option = document.createElement('option');
                    option.value = job.id;
                    option.textContent = job.name;
                    company.appendChild(option);
                });

            } catch (error) {
                console.error('Fetch xatosi:', error);
            }
        }
    });
});