const confirm_type = document.getElementById('type_confirmation');
confirm_type.addEventListener("change", () => {
    const type = document.getElementById('type_confirmation').value;
    const label = document.getElementById('label_confirmation');
    const input = document.getElementById('confirm_number');

    if (type === 'JSHSHIR') {
        label.textContent = 'JSHSHIR';
        input.placeholder = '0000000000000000';
        input.pattern = '\\d{16}';
        input.maxLength = 16;
        input.title = 'Faqat 16 ta raqam kiriting';
    } else if (type === 'STIR') {
        label.textContent = 'STIR';
        input.placeholder = '000000000';
        input.pattern = '\\d{9}';
        input.maxLength = 9;
        input.title = 'Faqat 9 ta raqam kiriting';
    }

    input.value = '';
});
document.getElementById('confirm_number').addEventListener('input', function () {
    const placeholder = this.placeholder;
    let value = this.value.replace(/\D/g, '');
    let newValue = '';
    this.value = value;
});
document.addEventListener("DOMContentLoaded", function () {
    const type = document.getElementById('type_confirmation').value;
    const label = document.getElementById('label_confirmation');
    const input = document.getElementById('confirm_number');

    if (type === 'JSHSHIR') {
        label.textContent = 'JSHSHIR';
        input.placeholder = '0000000000000000';
        input.pattern = '\\d{16}';
        input.maxLength = 16;
        input.title = 'Faqat 16 ta raqam kiriting';
    } else if (type === 'STIR') {
        label.textContent = 'STIR';
        input.placeholder = '000000000';
        input.pattern = '\\d{9}';
        input.maxLength = 9;
        input.title = 'Faqat 9 ta raqam kiriting';
    }
});