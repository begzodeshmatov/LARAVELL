var district = document.querySelector('#districtFilter');
var sector = document.querySelector('#sectorFilter');
var neighborhood = document.querySelector('#neighborhoodFilter');

function sort(result, neighborhoodId = false) {
    if (result) {
        if (neighborhoodId) {
            neighborhood.innerHTML = '';

            var opt = document.createElement('option');
            opt.textContent = "Mahalla";
            opt.value = "";
            neighborhood.appendChild(opt);
            result.data.forEach(item => {
                const option = document.createElement('option');
                option.textContent = item.name;
                option.value = item.id;
                if (item.id == neighborhoodId) {
                    option.selected = true;
                }
                neighborhood.appendChild(option);
            });
        } else {
            neighborhood.innerHTML = '';

            var opt = document.createElement('option');
            opt.textContent = "Mahalla";
            opt.value = "";
            opt.selected = true;
            neighborhood.appendChild(opt);
            result.data.forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = item.name;
                neighborhood.appendChild(option);
            });
        }
    }
}

sector.addEventListener("change", async (e) => {
    if (district.value) {
        try {
            const response = await fetch(`${url}/api/neighborhoods/${district.value}/${e.target.value}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();

            sort(result);
        } catch (error) {
            console.error('Fetch xatosi:', error);
        }
    } else {
        if (e.target.value) {

            try {
                const response = await fetch(`${url}/api/neighborhoods/sector/${e.target.value}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const result = await response.json();

                sort(result);
            } catch (error) {
                console.error('Fetch xatosi:', error);
            }

        }
    }
});

district.addEventListener("change", async (e) => {
    if (sector.value) {
        try {
            const response = await fetch(`${url}/api/neighborhoods/${e.target.value}/${sector.value}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();

            neighborhood.innerHTML = '';

            sort(result);

        } catch (error) {
            console.error('Fetch xatosi:', error);
        }
    } else {
        if (e.target.value) {
            try {
                const response = await fetch(`${url}/api/neighborhoods/district/${e.target.value}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const result = await response.json();

                sort(result);
            } catch (error) {
                console.error('Fetch xatosi:', error);
            }
        }
    }
});
document.addEventListener("DOMContentLoaded", async function () {
    var district = document.querySelector('#districtFilter');
    var sector = document.querySelector('#sectorFilter');
    var neighborhood = document.querySelector('#neighborhoodFilter');
    var neighborhoodId = neighborhood.getAttribute("data-neighborhood-id");

    if (district.value && sector.value) {
        try {
            const response = await fetch(`${url}/api/neighborhoods/${district.value}/${sector.value}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();

            sort(result, neighborhoodId);
        } catch (error) {
            console.error('Fetch xatosi:', error);
        }
    } else if (district.value) {
        try {
            const response = await fetch(`${url}/api/neighborhoods/district/${district.value}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();

            sort(result, neighborhoodId);
        } catch (error) {
            console.error('Fetch xatosi:', error);
        }
    } else if (sector.value) {
        try {
            const response = await fetch(`${url}/api/neighborhoods/sector/${sector.value}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();

            sort(result, neighborhoodId);
        } catch (error) {
            console.error('Fetch xatosi:', error);
        }
    }
});