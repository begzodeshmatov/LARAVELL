document.addEventListener("DOMContentLoaded", function () {
    var statusSelect = document.getElementById("status");
    var commentTextarea = document.getElementById("comment").parentElement;
    var comment = document.getElementById("comment");
    var doneAtDiv = document.getElementById("done_at").parentElement;
    var doneAt = document.getElementById("done_at");
    var extendAtDiv = document.getElementById("extend").parentElement;
    var extendAt = document.getElementById("extend");

    // Boshida hamma maydonlarni yashirib, kerakli atributlarni o'chirish
    commentTextarea.style.display = "none";
    comment.removeAttribute("required");
    doneAtDiv.style.display = "none";
    doneAt.removeAttribute("required");
    extendAtDiv.style.display = "none";
    extendAt.removeAttribute("required");

    statusSelect.addEventListener("change", function () {
        if (this.value == "hopeless") {
            allClose();
            commentTextarea.style.display = "block";
            comment.setAttribute("required", "required");
        } else if (this.value == "done") {
            allClose();
            doneAtDiv.style.display = "block";
            doneAt.removeAttribute("required");
        } else if (this.value == "extended") {
            allClose();
            commentTextarea.style.display = "block";
            comment.setAttribute("required", "required");
            extendAtDiv.style.display = "block";
            extendAt.removeAttribute("required");
        } else {
            allClose();
        }
    });

    function allClose()
    {
        commentTextarea.style.display = "none";
        comment.removeAttribute("required");

        doneAtDiv.style.display = "none";
        doneAt.removeAttribute("required");

        extendAtDiv.style.display = "none";
        extendAt.removeAttribute("required");

    }

    if (statusSelect.value == "hopeless") {
        commentTextarea.style.display = "block";
        comment.setAttribute("required", "required");
    } else if (statusSelect.value == "done") {
        doneAtDiv.style.display = "block";
        doneAt.removeAttribute("required");
    } else if (statusSelect.value == "extended") {
        commentTextarea.style.display = "block";
        comment.setAttribute("required", "required");
        extendAtDiv.style.display = "block";
        extendAt.removeAttribute("required");
    }
});
