<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>E-investitsiya Jizzax.uz</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="{{ asset('assets/img/logo-image-of-login.png') }}" rel="icon">
    <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="*:box-border *:p-0 *:m-0 select-none">
    <div class="flex justify-center h-screen items-center">
        <h1 class="text-gray-500 text-2xl md:text-3xl font-semibold capitalize">
            dalolatnoma kiritilmagan
        </h1>
    </div>
    </div>
</body>

</html>
