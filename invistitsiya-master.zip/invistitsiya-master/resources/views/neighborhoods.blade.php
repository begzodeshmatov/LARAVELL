@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Tumanlar va ularning mahallalari</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">Mahalalar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Mahallalar</h5>
                            <button
                                class="btn btn--add btn btn-primary  position-absolute top-0 end-0 mt-3  translate-middle-x"
                                type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                    class="bi bi-plus"></i></button>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Mahalla qo'shish
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="{{ route('neighborhood.store') }}" method="POST" class="row"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Mahalla nomi</label>
                                                    <input type="text" class="form-control" name="name"
                                                        placeholder="Mahalla nomi" required>
                                                </div>
                                                <div class="mb-3 col-3">
                                                    <label class="form-label">Tuman</label>
                                                    <select class="form-select" name="district" id="district">
                                                        <option selected disabled value="">Tanlash...</option>
                                                        @foreach ($districts as $district)
                                                            <option value="{{ $district->id }}">{{ $district->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-3">
                                                    <label class="form-label">Sektor</label>
                                                    <select class="form-select" name="sector" id="sector">
                                                        <option selected disabled value="">Tanlash...</option>
                                                        @foreach ($sectors as $sector)
                                                            <option value="{{ $sector->id }}">{{ $sector->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-primary">Qo'shish</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-around align-items-center">
                                <div class="mb-3 col-2">
                                    <label class="form-label">Tuman</label>
                                    <select class="form-select" id="districtSelection">
                                        <option selected disabled value="" id="default">Tanlash...</option>
                                        @foreach ($districts as $district)
                                            <option value="{{ $district->id }}">{{ $district->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3 col-2">
                                    <label class="form-label">Sektor</label>
                                    <select class="form-select" id="sectorFilter">
                                        <option selected disabled value="" id="default">Tanlash...</option>
                                        @foreach ($sectors as $sector)
                                            <option value="{{ $sector->id }}">{{ $sector->name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3 col-2">
                                    <label class="form-label">Qidirish</label>
                                    <input type="text" class="form-control" id="searchInput"
                                        placeholder="Mahalla nomi...">
                                </div>
                                <div class="mb-3 col-2">
                                    <button class="btn btn-success mt-4" id="clearButton">Hammasi</button>
                                </div>
                            </div>

                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col">Mahalla nomi</th>
                                            <th scope="col">Sektor</th>
                                            <th scope="col">Tuman</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody id="neighborhoodsTableBody">
                                        @foreach ($districts as $district)
                                            @foreach ($district->neighborhoods as $neighborhood)
                                                <tr data-district="{{ $district->id }}"
                                                    data-sector="{{ $neighborhood->sector->id }}">
                                                    <th scope="row">{{ $neighborhood->id }}</th>
                                                    <td>{{ $neighborhood->name }}</td>
                                                    <td>{{ $neighborhood->sector->name }}</td>
                                                    <td>{{ $neighborhood->district->name }}</td>
                                                    <td>
                                                        <a data-bs-toggle="modal" class="btn btn-primary"
                                                            data-bs-target="#editNeighborhood{{ $neighborhood->id }}"
                                                            href=""><i class='bx bx-pencil'></i></a>
                                                        <a data-bs-toggle="modal" class="btn btn-danger"
                                                            data-bs-target="#deleteNeighborhood{{ $neighborhood->id }}"
                                                            href="#"><i class='bx bx-trash'></i></a>

                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @foreach ($districts as $district)
                                @foreach ($district->neighborhoods as $neighborhood)
                                    <div class="modal fade" id="editNeighborhood{{ $neighborhood->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                        Tahririlash
                                                    </h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form
                                                        action="{{ route('neighborhood.update', ['neighborhood' => $neighborhood->id]) }}"
                                                        method="POST">
                                                        @method('PUT')
                                                        @csrf
                                                        <div class="mb-3 col-12">
                                                            <label class="form-label">Mahalla nomi</label>
                                                            <input type="text" class="form-control" name="name"
                                                                placeholder="Mahalla nomi"
                                                                value="{{ $neighborhood->name }}" required>
                                                        </div>
                                                        <div class="mb-3 col-12">
                                                            <label class="form-label">Sektor</label>
                                                            <select class="form-select" name="sector" id="sector">
                                                                <option selected disabled value="">Tanlash...
                                                                </option>
                                                                @foreach ($sectors as $sector)
                                                                    <option value="{{ $sector->id }}"
                                                                        {{ $neighborhood->sector->id == $sector->id ? 'selected' : '' }}>
                                                                        {{ $sector->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Bekor qilish</button>
                                                            <button type="submit" class="btn btn-primary">Ha</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="deleteNeighborhood{{ $neighborhood->id }}"
                                        tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                        O'chirish
                                                    </h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Haqiqatdan ham ushbu mahallani o'chirmoqchimisiz</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Yo'q</button>
                                                    <form
                                                        action="{{ route('neighborhood.destroy', ['neighborhood' => $neighborhood->id]) }}"
                                                        method="POST">
                                                        @method('DELETE')
                                                        @csrf
                                                        <button type="submit" class="btn btn-primary">Ha</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <script>
        var districtSelection = document.getElementById('districtSelection');
        var sectorFilter = document.getElementById('sectorFilter');
        var searchInput = document.getElementById('searchInput');
        var clearButton = document.getElementById('clearButton');

        districtSelection.addEventListener('change', function() {
            const districtId = this.value;
            const rows = document.querySelectorAll('#neighborhoodsTableBody tr');

            if (sectorFilter.value) {
                rows.forEach(row => {
                    if (row.getAttribute('data-district') === districtId && row.getAttribute(
                            'data-sector') === sectorFilter.value) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            } else {
                rows.forEach(row => {
                    if (row.getAttribute('data-district') === districtId) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
        });
        sectorFilter.addEventListener('change', function() {
            const sectorId = this.value;
            const rows = document.querySelectorAll('#neighborhoodsTableBody tr');
            if (districtSelection.value) {
                rows.forEach(row => {
                    if (row.getAttribute('data-sector') === sectorId && row.getAttribute(
                            'data-district') === districtSelection.value) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            } else {
                rows.forEach(row => {
                    if (row.getAttribute('data-sector') === sectorId) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
        });

        searchInput.addEventListener('input', () => {
            const query = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll('#neighborhoodsTableBody tr');

            districtSelection.querySelectorAll('option').forEach(option => {
                if (option.value === '') {
                    option.selected = true;
                } else {
                    option.selected = false;
                }
            });

            sectorFilter.querySelectorAll('option').forEach(option => {
                if (option.value === '') {
                    option.selected = true;
                } else {
                    option.selected = false;
                }
            });

            rows.forEach(row => {
                const cell = row.querySelector('td');
                if (cell) {
                    const cellText = cell.textContent.toLowerCase();
                    if (cellText.includes(query)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            });
        });
        clearButton.addEventListener('click', () => {
            const rows = document.querySelectorAll('#neighborhoodsTableBody tr');
            districtSelection.querySelectorAll('option').forEach(option => {
                if (option.value === '') {
                    option.selected = true;
                } else {
                    option.selected = false;
                }
            });

            sectorFilter.querySelectorAll('option').forEach(option => {
                if (option.value === '') {
                    option.selected = true;
                } else {
                    option.selected = false;
                }
            });

            searchInput.value = '';

            rows.forEach(row => {
                row.style.display = '';
            });
        });
    </script>
@endsection
