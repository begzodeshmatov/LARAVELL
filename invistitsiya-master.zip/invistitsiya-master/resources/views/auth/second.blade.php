<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biznes-himoya.uz</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="{{ asset('assets/img/logo-image-of-login.png') }}" rel="icon">
    <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="*:box-border *:p-0 *:m-0 select-none bg-right-top bg-no-repeat bg-cover"
    style="background-image: url({{ asset('assets/img/background-image-of-login.png') }})">
    <div class="flex justify-center h-screen items-center">
        <div class="bg-[#2017a9] block rounded-3xl max-w-[500px]">
            <div class="mb-16">
                <form action="{{ route('register.secont.store') }}" method="POST" class="block w-[72%] mx-auto mt-24">
                    @csrf
                    <input type="text" name="position"
                        class="outline-none w-full my-2 px-4 py-2 text-slate-500 text-xl font-medium placeholder:text-slate-500 border-2 border-slate-500 bg-[#2017a9] rounded"
                        placeholder="Lavozim" value="{{ old('position') }}" required>
                    @error('position')
                        <div>
                            <p class="text-red-600">{{ $message }}</p>
                        </div>
                    @enderror
                    <input type="text" name="phone_number"
                        class="outline-none w-full my-2 px-4 py-2 text-slate-500 text-xl font-medium placeholder:text-slate-500 border-2 border-slate-500 bg-[#2017a9] rounded"
                        placeholder="Telefon raqam" value="{{ old('phone_number') }}" required>
                    @error('phone_number')
                        <div>
                            <p class="text-red-600">{{ $message }}</p>
                        </div>
                    @enderror
                    <input type="text" name="address"
                        class="outline-none w-full my-2 px-4 py-2 text-slate-500 text-xl font-medium placeholder:text-slate-500 border-2 border-slate-500 bg-[#2017a9] rounded"
                        placeholder="Manzil" value="{{ old('address') }}" required>
                    @error('address')
                        <div>
                            <p class="text-red-600">{{ $message }}</p>
                        </div>
                    @enderror
                    <input type="number" name="inn" minlength="6" maxlength="6"
                        class="outline-none w-full my-2 px-4 py-2 text-slate-500 text-xl font-medium placeholder:text-slate-500 border-2 border-slate-500 bg-[#2017a9] rounded"
                        placeholder="INN" value="{{ old('inn') }}" required>
                    @error('inn')
                        <div>
                            <p class="text-red-600">{{ $message }}</p>
                        </div>
                    @enderror
                    <div class="flex justify-center">
                        <button type="submit"
                            class="my-2 py-2 px-12 bg-cyan-400 text-white text-lg font-bold rounded border-2 border-cyan-400 hover:border-white">Davom
                            etish</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
