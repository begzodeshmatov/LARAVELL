<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biznes-himoya.uz</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="{{ asset('assets/img/logo-image-of-login.png') }}" rel="icon">
    <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="*:box-border *:p-0 *:m-0 select-none bg-right-top bg-no-repeat bg-cover"
    style="background-image: url({{ asset('assets/img/background-image-of-login.png') }})">
    <div class="flex justify-center h-screen items-center">
        <div class="bg-[#2017a9] block rounded-3xl max-w-[500px]">
            <div>
                <div class="flex justify-center mt-12 my-4">
                    <img src="{{ asset('assets/img/logo-image-of-login.png') }}" width="120" alt="">
                </div>
                <div class="text-white text-center my-4">
                    <h1 class="text-xl font-semibold tracking-widest">BIZNES-HIMOYA PORTALI</h1>
                    <p class="font-medium tracking-wide">TIZIMGA KIRISH</p>
                </div>
            </div>
            <div class="mb-16">
                <form action="{{ route('login') }}" method="POST" class="block w-[72%] mx-auto">
                    @csrf
                    @error('email')
                        <div>
                            <p class="text-red-600">Email yoki parol xato!</p>
                        </div>
                    @enderror
                    <input type="email" name="email"
                        class="outline-none w-full my-2 px-4 py-2 text-slate-500 text-xl font-medium placeholder:text-slate-500 border-2 border-slate-500 bg-[#2017a9] rounded"
                        placeholder="Email..." value="{{ old('email') }}" required>
                    <input type="password" name="password"
                        class="outline-none w-full my-2 px-4 py-2 text-slate-500 text-xl font-medium placeholder:text-slate-500 border-2 border-slate-500 bg-[#2017a9] rounded"
                        placeholder="Parol..." required>
                    <div class="flex justify-center">
                        <button type="submit"
                            class="my-2 py-2 px-12 bg-cyan-400 text-white text-lg font-bold rounded border-2 border-cyan-400 hover:border-white">Kirish</button>
                    </div>
                    <div class="flex justify-center mt-4">
                        <a class="text-cyan-400 underline" href="{{ route('register') }}">Korxona sifatida ro'yxatdan o'tish</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
