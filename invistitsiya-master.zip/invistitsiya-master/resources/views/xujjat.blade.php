@extends('layouts.app')

@section('content')
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Hujjatlar aylanmasi</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">Hujjatlar aylanmasi</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="container mt-4">
                    <!-- Example entry -->
                    <div class="mb-2">
                        <div class=" d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i class="fas fa-clock"></i>
                                7.10.2024, 23:36</span>
                            <span class="me-2"> Б.А. Нарзуллаев <i class="fas fa-user"
                                    style=" font-size:20px; margin-left:10px;"></i></span>
                            <span class="badge bg-primary me-2">Рўйхатга олиш
                                учун</span><i class="fas fa-file-alt" style="color: blue; font-size:20px;"></i>
                        </div>
                    </div>

                    <div class="mb-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i class="fas fa-clock"></i> 7.10.2024, 23:36</span>
                            <span class="me-2"> Б.А. Нарзуллаев</span>
                            <span class="badge bg-info me-2"> Хужжат харакатлантирди</span>
                        </div>
                    </div>

                    <div class="mb-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i class="fas fa-clock"></i> 7.10.2024, 23:36</span>
                            <span class="me-2"> Б.Б. Валиев</span>
                            <span class="badge bg-secondary me-2"> Резолюция учун</span>
                            <span class="badge bg-primary"> Жараёнда</span>
                        </div>
                    </div>

                    <div class="mb-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i class="fas fa-clock"></i> 7.10.2024, 23:36</span>
                            <span class="me-2"> Б.Б. Валиев</span>
                            <span class="badge bg-secondary me-2"> Резолюция яратилди</span>

                        </div>
                    </div>

                    <div class="mb-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i class="fas fa-clock"></i> 7.10.2024, 23:36</span>
                            <span class="me-2"> Б.Б. Валиев</span>
                            <span class="badge bg-primary me-2"> Топшириқ берилди</span>
                            <span class="text-muted me-2"><i class="bi bi-people-fill" style="font-size: 25px;"></i>
                                Ижросини таъминлаш,
                                ахборот бериш: <i class='bx bx-calendar' style="color: green; font-size:20px;"></i>
                                08.10.2024</span>

                        </div>
                    </div>

                    <div class="mb-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i class="fas fa-clock"></i> 7.10.2024, 23:36</span>
                            <span class="me-2"> А.И. Эшмуродов</span>
                            <span class="badge bg-warning me-2">Асосий
                                ижрочи</span>
                            <span class="badge bg-info">Ижро учун</span>
                        </div>
                    </div>

                    <div class="mb-2">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-primary me-2 p-2"><i style="color: red; font-size:15px;"
                                    class='bx bx-arrow-from-bottom'></i><i class="fas fa-clock"
                                    style="margin-left: 5px;"></i> 7.10.2024, 23:36</span>
                            <span class="me-2"> А.И. Эшмуродов</span>
                            <span class="badge bg-warning me-2">Асосий
                                ижрочи</span>
                            <span class="badge bg-info"> Ижро учун</span> <i style="color: green; margin-left:10px;"
                                class="bi bi-check-circle-fill"></i><i
                                style="font-size: 25px; margin-left:10px; color:blue;" class='bx bxs-copy-alt'></i>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </main>
@endsection
