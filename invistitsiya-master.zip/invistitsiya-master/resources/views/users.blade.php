@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Foydalanuvchilar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">Foydalanuvchilar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger alert-dismissible fade show">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Foydalanuvchilar</h5>
                            <button
                                class="btn btn--add btn btn-primary  position-absolute top-0 end-0 mt-3  translate-middle-x"
                                type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                    class="bi bi-plus"></i></button>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Foydalanuvchilar qo'shish
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="{{ route('user.store') }}" method="POST" class="row"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Ismi</label>
                                                    <input type="text" class="form-control" name="name"
                                                        placeholder="Ismi" required>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Email manzili</label>
                                                    <input type="email" class="form-control" name="email"
                                                        placeholder="Email manzili" required>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Roli</label>
                                                    <select class="form-select" name="role" id="role" required>
                                                        <option selected disabled value="">Tanlash...</option>
                                                        <option value="admin">Admin</option>
                                                        <option value="observer">Kuzatuvchi</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Paroli</label>
                                                    <input type="password" class="form-control" name="password"
                                                        placeholder="Foydalanuvchi paroli" required>
                                                </div>
                                                <div class="model-footer">
                                                    <button class="btn btn-primary">Qo'shish</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col">Ismi</th>
                                            <th scope="col">Email manzili</th>
                                            <th scope="col">Roli</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($users as $user)
                                            <tr>
                                                <th scope="row">{{ $user->id }}</th>
                                                <td>{{ $user->name }}</td>
                                                <td>{{ $user->email }}</td>
                                                <td>
                                                    {{ $user->role == 'observer' ? 'Kuzatuvchi' : ($user->role == 'admin' ? 'Admin' : ($user->role == 'enterprise' ? 'Tadbirkor' : 'Admin')) }}
                                                </td>
                                                <td>
                                                    <a data-bs-toggle="modal" class="btn btn-primary m-1"
                                                        data-bs-target="#editUser{{ $user->id }}" href="#"><i
                                                            class="bx bx-pencil"></i></a>
                                                    <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                        data-bs-target="#deleteUser{{ $user->id }}" href="#"><i
                                                            class='bx bx-trash'></i></a>
                                                    <a data-bs-toggle="modal" class="btn btn-success m-1"
                                                        data-bs-target="#restoreUser{{ $user->id }}"
                                                        href="#"><i class="bi bi-arrow-clockwise"></i></a>
                                            </tr>
                                            <div class="modal fade" id="deleteUser{{ $user->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish
                                                            </h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Haqiqatdan ham ushbu foydalanuvchini o'chirmoqchimisiz</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Yo'q</button>
                                                            <form
                                                                action="{{ route('user.destroy', ['user' => $user->id]) }}"
                                                                method="POST">
                                                                @method('DELETE')
                                                                @csrf
                                                                <button type="submit" class="btn btn-primary">Ha</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            {{ $users->links() }}
                            <div>
                                @foreach ($users as $user)
                                    <div class="modal fade" id="editUser{{ $user->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Foydalanuvchini
                                                        tahrirlash</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="{{ route('user.update', ['user' => $user->id]) }}"
                                                        method="POST" class="row" enctype="multipart/form-data">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="mb-3 col-6">
                                                            <label class="form-label">Ismi</label>
                                                            <input type="text" class="form-control" name="name"
                                                                placeholder="Ismi" value="{{ $user->name }}" required>
                                                        </div>
                                                        <div class="mb-3 col-6">
                                                            <label class="form-label">Email manzili</label>
                                                            <input type="email" class="form-control" name="email"
                                                                placeholder="Email manzili" value="{{ $user->email }}"
                                                                required>
                                                        </div>
                                                        <div class="mb-3 col-6">
                                                            <label class="form-label">Roli</label>
                                                            <select class="form-select" name="role" id="role">
                                                                <option value="">Tanlash...</option>
                                                                <option value="admin"
                                                                    {{ $user->role == 'admin' ? 'selected' : '' }}>Admin
                                                                </option>
                                                                <option value="observer"
                                                                    {{ $user->role == 'observer' ? 'selected' : '' }}>
                                                                    Kuzatuvchi</option>
                                                            </select>
                                                        </div>
                                                        <div class="model-footer">
                                                            <button class="btn btn-primary">Saqlash</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="restoreUser{{ $user->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Foydalanuvchi
                                                        parolini tiklash </h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="{{ route('user.restore', ['user' => $user->id]) }}"
                                                        method="POST" class="row" enctype="multipart/form-data">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="mb-3 col-6">
                                                            <label class="form-label">Paroli</label>
                                                            <input type="password" class="form-control" name="password"
                                                                placeholder="Foydalanuvchi paroli" required>
                                                        </div>
                                                        <div class="model-footer">
                                                            <button class="btn btn-primary">Tiklash</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
