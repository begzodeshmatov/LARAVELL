@extends('../layouts.app')

@section('link')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <script src="https://cdn.tailwindcss.com"></script>
@endsection

@section('content')
    <main id="main" class="*:box-border *:p-0 *:m-0 select-none p-5 main">
        <div class="pagetitle mb-5">
            <h1>{{ $name }}</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item">Tumanlar</li>
                    <li class="breadcrumb-item">Loyihalar</li>
                    <li class="breadcrumb-item active">Loyiha</li>
                </ol>
            </nav>
        </div>
        <div class="min-w-[1280px] max-w-[1280px] bg-white rounded-lg mx-auto p-5 shadow-2xl z-0">
            <h1 class="text-2xl font-bold ml-12 my-4">Jizzax viloyati, {{ $name }}</h1> {{-- Region name --}}
            {{-- line div --}}
            <div class="w-full h-1 bg-blue-900 rounded-full my-4"></div>
            {{-- end line div --}}
            {{-- loop div --}}
            <div class="container-md mx-auto p-4">
                <div class="w-full h-1 bg-blue-900 rounded-full my-4"></div>
                {{-- title div --}}
                <div class="flex my-8 items-center my-12">
                    <div class="w-24 h-16 bg-blue-900 mr-8"></div>
                    <div>
                        <h1 class="text-xl text-blue-900 font-bold">TASHABBUSKOR: <span
                                class="text-black font-semibold">{{ $project->name }}</span></h1>
                        <p class="font-semibold text-gray-500">{{ $project->goal }}</p>
                    </div>
                </div>
                {{-- end title div --}}
                <div class="flex my-8 items-center my-12">
                    <div class="w-24 h-16 bg-blue opocity-0 mr-8"></div>
                    <div>
                        <h1 class="text-lg text-blue-900 font-bold"><span class="text-uppercase">Rahbar</span>: <span
                                class="text-black font-semibold">{{ $project->leader }}</span></h1>
                        <h1 class="text-lg text-blue-900 font-bold"><span class="text-uppercase">Manzili</span>: <span
                                class="text-black font-semibold">{{ $project->address }}</span></h1>
                        <h1 class="text-lg text-blue-900 font-bold"><span class="text-uppercase">Hududi</span>: <span
                                class="text-black font-semibold">{{ $project->area }}</span></h1>
                        <h1 class="text-lg text-blue-900 font-bold"><span class="text-uppercase">Xizmat ko'rsatuvchi bank</span>: <span
                                class="text-black font-semibold">{{ $project->bank }}</span></h1>
                    </div>
                </div>
                {{-- body div --}}
                <div class="">
                    {{-- images div --}}
                    <div class="max-h-[600px] min-h-[600px] grid grid-cols-2 gap-y-8 gap-x-12 my-12 z-30">
                        <div class="max-w-[1200px] min-w-[1200px] min-h-[250px] max-h-[250px] z-0 absolute">
                            <div class="bg-[#ffffff] max-w-[1150px] min-w-[1150px] min-h-[100px] max-h-[100px]"></div>
                            <div
                                class="bg-gradient-to-r from-[#afdafc] to-[#145ba3] max-w-[1150px] min-w-[1150px] min-h-[400px] max-h-[400px]">
                            </div>
                            <div class="bg-[#ffffff] max-w-[1150px] min-w-[1150px] min-h-[100px] max-h-[100px]"></div>
                        </div>
                        @foreach ($project->images as $image)
                            <div class="my-2 mx-16 z-10">
                                <img class="max-w-[450px] min-w-[450px] max-h-[250px] min-h-[250px] border-1 border-blue-900 object-cover"
                                    src="{{ asset('storage/' . str_replace('public/', '', $image->path)) }}"
                                    alt="{{ $image->name }}">
                            </div>
                        @endforeach
                    </div>
                    {{-- end images div --}}
                    {{-- statistic div --}}
                    <div class="max-h-20 min-h-20 flex justify-around my-12">
                        <div class="min-h-full flex justify-between items-center text-center">
                            {{-- <div>
                                <i class="bi bi-coin text-5xl text"></i>
                            </div> --}}
                            <div
                                class="min-h-full max-h-full py-2 px-8 my-4 bg-gradient-to-l from-[#cccccc] to-white to-90% rounded-tr-[60px]">
                                <b class="text-sm text-blue-800 font-bold">Loyiha qiymati</b>
                                <h1 class="text-sm font-bold" id="irregularPrice" data-price="{{ $project->value }}"></h1>
                                <h2 class="text-sm">mln. dollar</h2>
                            </div>
                        </div>
                        <div class="min-h-full flex justify-between items-center text-center">
                            {{-- <div>
                                <i class="bi bi-kanban text-5xl text"></i>
                            </div> --}}
                            <div
                                class="min-h-full max-h-full py-2 px-8 my-4 bg-gradient-to-l from-[#cccccc] to-white to-90% rounded-tr-[60px]">
                                <b class="text-sm text-blue-800 font-bold">Loyiha quvvati</b>
                                <h1 class="text-sm font-bold" id="irregularPrice" data-price="{{ $project->power }}"></h1>
                                <h2 class="text-sm">{{ $project->unity->name ?? '0' }}</h2>
                            </div>
                        </div>
                        <div class="min-h-full flex justify-between items-center text-center">
                            {{-- <div>
                                <i class="bi bi-map text-5xl text"></i>
                            </div> --}}
                            <div
                                class="min-h-full max-h-full py-2 px-8 my-4 bg-gradient-to-l from-[#cccccc] to-white to-90% rounded-tr-[60px]">
                                <b class="text-sm text-blue-800 font-bold">Mavjud ish o'rni</b>
                                <h1 class="text-sm font-bold">{{ $project->available_vacancies }}</h1>
                                <h2 class="text-sm">nafar</h2>
                            </div>
                        </div>
                        <div class="min-h-full flex justify-between items-center text-center">
                            {{-- <div>
                                <i class="bi bi-person text-5xl text"></i>
                            </div> --}}
                            <div
                                class="min-h-full max-h-full py-2 px-8 my-4 bg-gradient-to-l from-[#cccccc] to-white to-90% rounded-tr-[60px]">
                                <b class="text-sm text-blue-800 font-bold">Tashkil etilgan ish o'rni</b>
                                <h1 class="text-sm font-bold">{{ $project->number_of_vacancies }}</h1>
                                <h2 class="text-sm">nafar</h2>
                            </div>
                        </div>
                        <div class="min-h-full flex justify-between items-center text-center">
                            <div
                                class="min-h-full max-h-full py-2 px-8 my-4 bg-gradient-to-l from-[#cccccc] to-white to-90% rounded-tr-[60px]">
                                <b
                                    class="text-sm text-blue-800 font-bold">{{ $project->status->key == 'done' ? 'Ishga tushgan vaqti' : 'Ishga tushish muddati' }}</b>
                                <h1 class="text-sm font-bold" class="text-sm"
                                    data-date="{{ $project->status->key == 'done' ? $project->done_at : $project->date }}"
                                    id="done-at-{{ $project->id }}"></h1>
                                <h2 id="done-month-{{ $project->id }}"></h2>
                            </div>
                        </div>
                        <div class="min-h-full flex justify-between items-center text-center">
                            <div
                                class="min-h-full py-2 px-8 my-4 bg-gradient-to-l from-[#cccccc] to-white to-90% rounded-tr-[60px]">
                                <b class="my-2 text-sm text-blue-800 font-bold">Dalolatnoma</b>
                                <h1 class="my-2 text-sm font-bold" class="text-sm"><a target="_blank"
                                        href="{{ $project->file ? asset('storage/' . str_replace('public/', '', $project->file->path)) : route('not.available') }}">
                                        {{ $project->file ? $project->file->name : 'Mavjud emas' }}
                                    </a>
                                </h1>
                            </div>
                        </div>
                    </div>
                    {{-- end statistic div --}}
                </div>
                {{-- end body div --}}

                <div class="flex my-8 items-center my-12">
                    <div class="w-24 h-16 bg-blue opocity-0 mr-8"></div>
                    <div>
                        <div class="my-2">
                            <h1 class="text-lg text-blue-900 font-bold"><span class="text-uppercase">Mavjud
                                    muammolar</span>:</h1>
                            @if ($project->problems()->count() == 0)
                                <ul class="ml-10">
                                    <li class="max-w-[1000px] text-balance">Mavjud emas</li>
                                </ul>
                            @else
                                <ul class="ml-10 list-decimal">
                                    @foreach ($project->problems as $problem)
                                        <li class="max-w-[1000px] text-balance">{{ $problem->text }}</li>
                                    @endforeach
                                </ul>
                            @endif
                        </div>
                        <div class="my-2">
                            <h1 class="text-lg text-blue-900 font-bold"><span class="text-uppercase">O'rganish natijasi
                                    bo'yicha xulosa</span>:</h1>
                            <div class="ml-7">
                                <p>{{ $project->conclusion }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{-- end loop div --}}
        </div>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let dateField, monthField, doneAt, date;
            const monthNames = ["Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun", "Iyul", "Avgust", "Sentabr",
                "Oktabr", "Noyabr", "Dekabr"
            ];
            dateField = document.getElementById('done-at-{{ $project->id }}');
            monthField = document.getElementById('done-month-{{ $project->id }}');

            doneAt = dateField.getAttribute('data-date');

            if (doneAt) {
                date = new Date(doneAt);
                dateField.innerText = date.getFullYear();
                monthField.innerText = monthNames[date.getMonth()]
            } else {
                dateField.innerText = 'Hali yakunlanmagan';
                monthField.innerText = '--';
            }
        });
        document.addEventListener("contextmenu", (e) => {
            e.preventDefault()
        })
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'u') {
                e.preventDefault();
            }
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'F12') {
                e.preventDefault();
            }
        });
    </script>
@endsection
