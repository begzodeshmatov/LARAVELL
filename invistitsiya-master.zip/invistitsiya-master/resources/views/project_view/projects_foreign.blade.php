@extends('../layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Loyihalar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item">Tumanlar</li>
                    <li class="breadcrumb-item active">Loyihalar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Loyihalar</h5>
                        <table class="table table-hover table-bordered text-center">
                            <tbody>
                                @php
                                    $count = 1;
                                @endphp
                                @foreach ($projects as $project)
                                    <tr>
                                        <th scope="row">{{ $count++ }}</th>
                                        <td>
                                            <a href="{{ route('project.show.foreign', ['project' => $project->id]) }}"
                                                class="text-black btn px-5 py-0 border-0">
                                                {{ $project->name }}
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('project.show.foreign', ['project' => $project->id]) }}"
                                                class="btn btn-outline-primary">
                                                <i class="bi bi-arrow-right"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{ $projects->links() }}
                </div>
            </div>
        </section>
    </main>
@endsection
