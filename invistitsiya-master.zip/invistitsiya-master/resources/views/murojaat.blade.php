@extends('layouts.app')

@section('content')
    <main id="main" class="main">
        <style>
            .line {
                position: absolute;
                top: 60px;
                left: 50%;
                width: 3px;
                height: 80px;
                background: blue;
            }

            .card1 {
                height: 80px;
                margin-bottom: 10px
            }

            .card_1 {
                height: 170px;
            }
        </style>


        <div class="container ">
            <div class="row">
                <div class="col-md-4 col-lg-3 ">
                    <div class="card card1 p-3 p-lg-2">
                        <div class="row">
                            <div class="col-4  text-center">
                                <i class="bx bx-bookmarks fs-1 text-info"></i>
                            </div>
                            <div class="col-8 text-center">
                                <a href="{{ route('murojaat.index', ['type' => 'all']) }}">
                                    <h1 class="fs-lg-6 text-info">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'count') }}
                                    </h1>
                                    <p class="fs-lg-6 text-info" style="color: blue;">Jami murojaatlar</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card card1 p-2">
                        <div class="row">
                            <div class="col-4 text-center">
                                <i class='bx bx-brightness fs-1  text-warning'></i>
                            </div>
                            <div class="col-8 text-center">
                                <a href="{{ route('murojaat.index', ['type' => 'execution']) }}">
                                    <h1 class="fs-6 text-warning">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'execution') }}
                                    </h1>
                                    <p class="fs-lg-6" style="color:orange">Ijrodagi murojaatlar</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card card1 p-2">
                        <div class="row">
                            <div class="col-4 text-center">
                                <i class='bx bxs-check-shield fs-1 text-success'></i>
                            </div>
                            <div class="col-8 text-center">
                                <a href="{{ route('murojaat.index', ['type' => 'done']) }}">
                                    <h1 class=" fs-6 text-success">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'done') }}
                                    </h1>
                                    <p class="fs-6" style=" color:rgb(37, 159, 37);">Hal qilingan murojaatlar</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card card1 p-2">
                        <div class="row">
                            <div class="col-12 text-center">
                                <a href="{{ route('murojaat.index', ['type' => 'overdue']) }}">
                                    <h1 class=" fs-6 text-danger-emphasis text-black">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'overdue') }}
                                    </h1>
                                    <p class="fs-6 text-black">Muddati buzilib bajarilgan</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="row">
                        <div class="col-6">
                            <div class="card card1 p-2">
                                <div class="row">
                                    <div class="col-4 text-center">
                                        <i class='bx bx-x fs-1  text-danger'></i>
                                    </div>
                                    <div class="col-8 text-center">
                                        <a href="{{ route('murojaat.index', ['type' => 'expired']) }}">
                                            <h1 class=" fs-6 text-danger">
                                                {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'expired') }}
                                            </h1>
                                            <p class="fs-6" style="color:red">Muddati buzilgan xujjatlar</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card card1 p-2">
                                <div class="row">
                                    <div class="col-4 text-center">
                                        <i class='bx bxs-file-import fs-1  text-primary'></i>
                                    </div>
                                    <div class="col-8 text-center">
                                        <a href="{{ route('murojaat.index', ['type' => 'new']) }}">
                                            <h1 class=" fs-6 text-primary">
                                                {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'new') }}
                                            </h1>
                                            <p class="fs-6" style="color:blue">Yangi murojaatlar</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card card1 p-2">
                                <div class="row">
                                    <div class="col-4 text-center">
                                        <i class='bx bxs-calendar-plus fs-1  text-warning'></i>
                                    </div>
                                    <div class="col-8 text-center">
                                        <a href="{{ route('murojaat.index', ['type' => 'extended']) }}">
                                            <h1 class=" fs-6 text-warning">
                                                {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'extended') }}
                                            </h1>
                                            <p class="fs-6" style="color:rgb(201, 193, 33)">Muddati uzaytirilgan</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card card1 p-2">
                                <div class="row">
                                    <div class="col-4 text-center">
                                        <i class='bx bxs-calendar-check fs-1  text-primary-emphasis'></i>
                                    </div>
                                    <div class="col-8 text-center">
                                        <a href="{{ route('murojaat.index', ['type' => 'done']) }}">
                                            <h1 class=" fs-6 text-primary-emphasis">
                                                {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'done') }}
                                            </h1>
                                            <p class="fs-6" style="color:rgb(65, 65, 96)">Nazoratdan yechishga</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card card_1 p-2">
                        <h3 class="text-center fs-3 text-primary mb-4 fw-bold">Muddat</h3>
                        <div class="line"></div>
                        <div class="row">
                            <div class="col-6 mb-2  d-flex justify-content-between">
                                <div class="muddat_1">
                                    <h1 class="text-danger">
                                        <a href="{{ route('murojaat.index', ['type' => 'today']) }}">Bugun</a>
                                    </h1>
                                </div>
                                <div class="muddat_2">
                                    <h1 class="bg-danger text-light px-1">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'today') }}
                                        ta</h1>
                                </div>
                            </div>
                            <div class="col-6 mb-2  d-flex justify-content-between">
                                <div class="muddat_1">
                                    <h1 class="text-primary">
                                        <a href="{{ route('murojaat.index', ['type' => 'three']) }}">3 kun</a>
                                    </h1>
                                </div>
                                <div class="muddat_2">
                                    <h1 class="bg-primary text-light px-1">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'three') }}
                                        ta</h1>
                                </div>
                            </div>
                            <div class="col-6 mb-2  d-flex justify-content-between">
                                <div class="muddat_1">
                                    <h1 class="text-warning">
                                        <a href="{{ route('murojaat.index', ['type' => 'tomorrow']) }}">Ertaga</a>
                                    </h1>
                                </div>
                                <div class="muddat_2">
                                    <h1 class="bg-warning text-light px-1">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'tomorrow') }}
                                        ta</h1>
                                </div>
                            </div>
                            <div class="col-6 mb-2  d-flex justify-content-between">
                                <div class="muddat_1">
                                    <h1 class="text-primary">
                                        <a href="{{ route('murojaat.index', ['type' => 'four']) }}">4 kun</a>
                                    </h1>
                                </div>
                                <div class="muddat_2">
                                    <h1 class="bg-primary text-light px-1">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'four') }}
                                        ta</h1>
                                </div>
                            </div>
                            <div class="col-6 mb-2  d-flex justify-content-between">
                                <div class="muddat_1">
                                    <h1 class="text-primary">
                                        <a href="{{ route('murojaat.index', ['type' => 'aftertomarrow']) }}">Indinga</a>
                                    </h1>
                                </div>
                                <div class="muddat_2">
                                    <h1 class="bg-primary text-light px-1">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'aftertomarrow') }}
                                        {{-- three --}}
                                        ta</h1>
                                </div>
                            </div>
                            <div class="col-6 mb-2  d-flex justify-content-between">
                                <div class="muddat_1">
                                    <h1 class="text-primary">
                                        <a href="{{ route('murojaat.index', ['type' => 'five']) }}">5 kun</a>
                                    </h1>
                                </div>
                                <div class="muddat_2">
                                    <h1 class="bg-primary text-light px-1">
                                        {{ app(App\Services\MurojaatCalculator::class)->calculate($forCalculating, 'five') }}
                                        ta</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                @if ($errors->any())
                    <div class="alert alert-danger ">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show " role="alert">
                        <i class="bi bi-check-circle me-1"></i>
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                @if (session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-octagon me-1"></i>
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
            </div>

            <div class="row">
                <div class="card p-0">
                    <div class="card-header bg-secondary d-flex justify-content-between p-1">
                        <h5 class="text-light mt-2 ms-2">Murojatlar</h5>
                        <button class="btn btn--add btn btn-primary  translate-middle-x btn-sm mt-0" style="width: 50px"
                            type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                class="bi bi-plus"></i>
                        </button>
                        {{-- Modal --}}
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Murojaat yuborish
                                        </h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="{{ route('murojaat.store') }}" method="POST" class="row"
                                            enctype="multipart/form-data">
                                            @csrf
                                            <div class="mb-2 col-sm-12 col-12">
                                                <label class="form-label">Mavzu</label>
                                                <input type="text" class="form-control" name="subject"
                                                    placeholder="Mavzu" required>
                                            </div>
                                            @if (auth()->user()->role == 'enterprise')
                                                <div class="mb-2 col-sm-12 col-122">
                                                    <input name="tadbirkor_id" value="{{ auth()->user()->id }}" hidden>
                                                </div>
                                            @else
                                                <div class="mb-2 col-sm-12 col-122">
                                                    <label class="form-label">Tadbirkor</label>
                                                    <select class="form-select" name="tadbirkor_id">
                                                        <option selected disabled value="">Tanlash...</option>
                                                        @foreach ($users as $user)
                                                            <option value="{{ $user->id }}">
                                                                {{ $user->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            @endif

                                            <div class="mb-2 col-sm-12 col-12">
                                                <label class="form-label">Murojaat turi</label>
                                                <select class="form-select" name="murojaat_type">
                                                    <option selected disabled value="">Tanlash...</option>
                                                    <option value="Bino-inshootlar ajratish">Bino-inshootlar ajratish
                                                    </option>
                                                    <option value="Boj to'lovlariga imtiyoz berish">Boj to'lovlariga
                                                        imtiyoz berish</option>
                                                    <option value="Buzilgan bino-inshootlar masalasi">Buzilgan
                                                        bino-inshootlar masalasi</option>
                                                    <option value="Elektr energiya masalalari">Elektr energiya masalalari
                                                    </option>
                                                    <option value="Elektr energiya tarmoqlariga ulanish">Elektr energiya
                                                        tarmoqlariga ulanish</option>
                                                    <option value="Gaz masalasi">Gaz masalasi</option>
                                                    <option value="Kameral soliq tekshiruvi">Kameral soliq tekshiruvi
                                                    </option>
                                                    <option value="Kompensatsiya to'lovini undirish masalasi">Kompensatsiya
                                                        to'lovini undirish masalasi</option>
                                                    <option value="Kredit foizi uchun subsidiya ajratish">Kredit foizi
                                                        uchun subsidiya ajratish</option>
                                                    <option value="Kredit muddatini uzaytirish">Kredit muddatini uzaytirish
                                                    </option>
                                                </select>
                                            </div>

                                            <div class="mb-2 col-sm-12 col-12">
                                                <label class="form-label">Qisqacha malumot</label>
                                                <textarea class="form-control" name="qisqacha" placeholder="Qisqacha malumot" required></textarea>
                                            </div>


                                            <div class="mb-2 col-sm-12 col-12">
                                                <label class="form-label">Tadbirkor sohasi</label>
                                                <select class="form-select" name="soha">
                                                    <option selected disabled value="">Tanlash...</option>
                                                    <option value="Ishlab chiqarish">Ishlab chiqarish</option>
                                                    <option value="Xizmat ko'rsatish">Xizmat ko'rsatish</option>
                                                    <option value="Qishloq xo'jaligi">Qishloq xo'jaligi</option>
                                                    <option value="Boshqa">Boshqa</option>
                                                </select>
                                            </div>
                                            <div class="mb-2 col-sm-12 col-12">
                                                <label class="form-label">File yuklash</label>
                                                <input type="file" class="form-control" name="file"required>
                                            </div>
                                            <div class="mb-2 col-sm-12 col-12">
                                                <style>
                                                    #recordedVideo,
                                                    #deleteButton,
                                                    #localVideoContainer {
                                                        display: none;
                                                    }

                                                    #audioRecordedContainer {
                                                        display: none;
                                                    }

                                                    #recordingIndicator {
                                                        display: none;
                                                        /* Dastlab yashirin */
                                                        color: red;
                                                        /* Matn rangini qizil qilib belgilash */
                                                        font-weight: bold;
                                                        margin-top: 10px;
                                                        font-size: 20px;
                                                        /* Matn o'lchamini oshirish */
                                                    }

                                                    /* Yozilayotgan audio ko'rsatkichining tarzi */
                                                    .recording {
                                                        display: inline-block;
                                                        /* Inline-block uslubini qo'llash */
                                                        animation: blinker 1s linear infinite;
                                                        /* Blinking effect */
                                                    }

                                                    @keyframes blinker {
                                                        50% {
                                                            opacity: 0;
                                                        }

                                                        /* Yozuvni ko'rinmas qilish */
                                                    }
                                                </style>
                                                <div id="localVideoContainer">
                                                    <video id="localVideo" autoplay playsinline
                                                        style="width: 600px; height: auto; border: 1px solid black;"></video>
                                                    <video id="recordedVideo" controls
                                                        style="width: 600px; height: auto; border: 1px solid black;"></video>
                                                    <button id="deleteButton" class="btn btn-danger"><i
                                                            class='bx bx-trash'></i></button>
                                                </div>
                                                <div id="recordingIndicator">Yozilmoqda... <span
                                                        class="recording">●</span></div>
                                                <div id="audioRecordedContainer">
                                                    <audio id="recordedAudioPlayer" controls style="width: 100%;"></audio>
                                                    <br>
                                                    <button id="audioDeleteButton" class="btn btn-danger"><i
                                                            class='bx bx-trash'></i></button>
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-between">
                                                <div class="salom">
                                                    <a href="javascript:void(0);" id="startRecordingButton"
                                                        class="btn btn-success"><i class='bx bxs-video'></i></a>
                                                    <a href="javascript:void(0);" id="audioStartButton"
                                                        class="btn btn-warning"><i class='bx bxs-microphone'></i></a>
                                                </div>
                                                <div>
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Yopish</button>
                                                    <button class="btn btn-primary">Saqlash</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover text-center">
                                <thead>
                                    <tr>
                                        <th scope="col">Murojaat ID</th>
                                        <th scope="col">Mazmuni</th>
                                        <th scope="col">Tadbirkor</th>
                                        <th scope="col">Murojaat sohasi</th>
                                        <th scope="col">Masul</th>
                                        <th scope="col">Muddat</th>
                                        <th scope="col">Bajarildi</th>
                                        <th scope="col">Joriy holati</th>
                                        <th scope="col">Tadbirkorlik sohasi</th>
                                        <th scope="col">Hujjat aylanmasi</th>
                                        <th scope="col">Yuklangan file</th>
                                        <th scope="col">Amallar</th>
                                    </tr>
                                </thead>
                                <tbody id="murojaatsTableBody">
                                    @foreach ($murojaatlar as $murojaat)
                                        <tr>
                                            <th scope="row">{{ $murojaat->id }}</th>
                                            <td>{{ $murojaat->subject }}</td>
                                            <td>
                                                <a
                                                    href="{{ route('murojaat.batafsil', ['murojaat' => $murojaat->company->id]) }}">{{ $murojaat->company->name ?? '0' }}</a>
                                            </td>
                                            <td>{{ $murojaat->murojaat_type }}</td>
                                            <td>
                                                @if ($murojaat->nazoratchi == '0')
                                                    <span style="font-weight:bold">-</span>
                                                @else
                                                    <img src="{{ asset('assets/img/avatar.png') }}"
                                                        style="border-radius:50%;width:30px" alt="Profile">
                                                    {{ $murojaat->nazoratchi }}
                                                @endif
                                            </td>
                                            <td>
                                                @if ($murojaat->time === null)
                                                    <span style="font-weight:bold">-</span>
                                                @else
                                                    {{ $murojaat->time->format('d-m-Y H:i A') }}
                                                @endif
                                            </td>
                                            <td>
                                                @if ($murojaat->done_at === null)
                                                    <span style="font-weight:bold">-</span>
                                                @else
                                                    {{ $murojaat->done_at->format('d-m-Y H:i A') }}
                                                @endif
                                            </td>
                                            <td>
                                                @if ($murojaat->holat == '1' || $murojaat->holat == null)
                                                    <span class="badge bg-warning large">Yangi</span>
                                                @elseif($murojaat->holat == '2')
                                                    <span class="badge bg-danger large">Ko'rib chiqilmoqda</span>
                                                @elseif($murojaat->holat == '3')
                                                    <span class="badge bg-info large">Yopilgan</span>
                                                @elseif($murojaat->holat == '4')
                                                    <span class="badge bg-info large">Muddati uzaytirilgan</span>
                                                @elseif($murojaat->holat == '5')
                                                    <span class="badge bg-success large">Bajarilgan</span>
                                                @endif
                                            </td>
                                            <td>{{ $murojaat->soha }}</td>
                                            <td>
                                                <a href="/xujjat">Ko'rish</a>
                                            </td>
                                            <td>
                                                <a href="files/{{ $murojaat->file }}" target="_blank">Fileni
                                                    ochish</a>
                                            </td>
                                            <td>
                                                @if (Auth::user()->role == 'super')
                                                    @if ($murojaat->holat !== 5 && $murojaat->holat !== 1)
                                                        <a data-bs-toggle="modal" class="btn btn-success m-1"
                                                            data-bs-target="#yechildimurojaat{{ $murojaat->id }}"
                                                            href=""><i class='bx bx-briefcase-alt'></i>
                                                        </a>
                                                        <a data-bs-toggle="modal" class="btn btn-info m-1"
                                                            data-bs-target="#extending{{ $murojaat->id }}"
                                                            href=""><i class="bi bi-arrows-angle-expand"></i>
                                                        </a>
                                                    @endif
                                                    <a data-bs-toggle="modal" class="btn btn-primary m-1"
                                                        data-bs-target="#editmurojaat{{ $murojaat->id }}"
                                                        href=""><i class='bx bx-pencil'></i>
                                                    </a>
                                                @endif
                                                <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                    data-bs-target="#deletemurojaat{{ $murojaat->id }}" href="#"><i
                                                        class='bx bx-trash'></i></a>

                                            </td>
                                            <div class="col-12">
                                                <div class="modal fade" id="editmurojaat{{ $murojaat->id }}"
                                                    tabindex="-1" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                    Murojaatni biriktirish
                                                                </h1>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form
                                                                    action="{{ route('murojaat.biriktirish', ['biriktirish' => $murojaat->id]) }}"
                                                                    method="POST" class="row"
                                                                    enctype="multipart/form-data">
                                                                    @csrf
                                                                    <div class="mb-3 col-sm-12 col-12">
                                                                        <label class="form-label">Mavzu</label>
                                                                        <input type="text" class="form-control"
                                                                            name="subject" placeholder="Mavzu"
                                                                            value="{{ $murojaat->subject }}" required>
                                                                    </div>

                                                                    <div class="mb-3 col-sm-12 col-12">
                                                                        <label class="form-label">Nazoratchi</label>
                                                                        <select class="form-select" name="nazoratchi">
                                                                            <option selected disabled value="">
                                                                                Tanlash...</option>
                                                                            <option value="Bojxona qo'mitasi">Bojxona
                                                                                qo'mitasi
                                                                            </option>
                                                                            <option value="Markaziy bank">Markaziy bank
                                                                            </option>
                                                                            <option value="Prokuratura shtabi">
                                                                                Prokuratura
                                                                                shtabi</option>
                                                                            <option value="Savdo-sanoat palatasi">
                                                                                Savdo-sanoat palatasi</option>
                                                                            <option value="Soliq boshqarmasi">Soliq
                                                                                boshqarmasi</option>
                                                                        </select>
                                                                    </div>

                                                                    <div class="mb-3 col-sm-12 col-12">
                                                                        <label class="form-label">Muxlat</label>
                                                                        <input type="datetime-local" class="form-control"
                                                                            name="time" placeholder="Muxlat" required>
                                                                    </div>

                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Yopish</button>
                                                                        <button class="btn btn-primary">Saqlash</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal fade" id="deletemurojaat{{ $murojaat->id }}"
                                                tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                O'chirish
                                                            </h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Haqiqatdan ham ushbu murojaatni o'chirmoqchimisiz?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Yo'q</button>
                                                            <form
                                                                action="{{ route('murojaat.destroy', ['murojaat' => $murojaat->id]) }}"
                                                                method="POST">
                                                                @method('DELETE')
                                                                @csrf
                                                                <button type="submit" class="btn btn-primary">Ha</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal fade" id="yechildimurojaat{{ $murojaat->id }}"
                                                tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                Murojaatni yechish
                                                            </h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form
                                                                action="{{ route('murojaat.done', ['murojaat' => $murojaat->id]) }}"
                                                                method="POST">
                                                                @csrf
                                                                @method('PUT')
                                                                <div class="mb-3 col-sm-12 col-12">
                                                                    <label class="form-label">Bajarilgan vaqti</label>
                                                                    <input type="datetime-local" class="form-control"
                                                                        name="done_at" placeholder="Bajarilgan vaqti"
                                                                        required>
                                                                </div>
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Yo'q</button>
                                                                <button type="submit" class="btn btn-primary">Xa</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal fade" id="extending{{ $murojaat->id }}"
                                                tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                Murojaat muddatini uzaytirish
                                                            </h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form
                                                                action="{{ route('murojaat.extend', ['murojaat' => $murojaat->id]) }}"
                                                                method="POST">
                                                                @csrf
                                                                @method('PUT')
                                                                <div class="mb-3 col-sm-12 col-12">
                                                                    <label class="form-label">Yangi muddat</label>
                                                                    <input type="datetime-local" class="form-control"
                                                                        name="time" placeholder="Yangi muddat"
                                                                        required>
                                                                </div>
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Yo'q</button>
                                                                <button type="submit" class="btn btn-primary">O'zgartirish</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        {{-- <div class="conatainer px-2">
        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body p-0">
                            <h5 class="card-title mt-1 mx-3">Murojaatlar</h5>
                            <button
                                class="btn btn--add btn btn-primary  position-absolute top-0 end-0 mt-3  translate-middle-x"
                                type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                    class="bi bi-plus"></i></button>
                            <div class="col-12">
                                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Murojaat yuborish
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="{{ route('murojaat.store') }}" method="POST" class="row"
                                                    enctype="multipart/form-data">
                                                    @csrf
                                                    <div class="mb-3 col-sm-12 col-12">
                                                        <label class="form-label">Mavzu</label>
                                                        <input type="text" class="form-control" name="subject"
                                                            placeholder="Mavzu" required>
                                                    </div>
                                                    @if (auth()->user()->role == 'enterprise')
                                                        <div class="mb-3 col-sm-12 col-122">
                                                            <input name="tadbirkor_id" value="{{ auth()->user()->id }}" hidden>
                                                        </div>
                                                    @else
                                                        <div class="mb-3 col-sm-12 col-122">
                                                            <label class="form-label">Tadbirkor</label>
                                                            <select class="form-select" name="tadbirkor_id">
                                                                <option selected disabled value="">Tanlash...</option>
                                                                @foreach ($getCompanys as $getCompany)
                                                                    <option value="{{ $getCompany->id }}">
                                                                        {{ $getCompany->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    @endif

                                                    <div class="mb-3 col-sm-12 col-12">
                                                        <label class="form-label">Murojaat turi</label>
                                                        <select class="form-select" name="murojaat_type">
                                                            <option selected disabled value="">Tanlash...</option>
                                                            <option value="Bino-inshootlar ajratish">Bino-inshootlar ajratish</option>
                                                            <option value="Boj to'lovlariga imtiyoz berish">Boj to'lovlariga imtiyoz berish</option>
                                                            <option value="Buzilgan bino-inshootlar masalasi">Buzilgan bino-inshootlar masalasi</option>
                                                            <option value="Elektr energiya masalalari">Elektr energiya masalalari</option>
                                                            <option value="Elektr energiya tarmoqlariga ulanish">Elektr energiya tarmoqlariga ulanish</option>
                                                            <option value="Gaz masalasi">Gaz masalasi</option>
                                                            <option value="Kameral soliq tekshiruvi">Kameral soliq tekshiruvi</option>
                                                            <option value="Kompensatsiya to'lovini undirish masalasi">Kompensatsiya to'lovini undirish masalasi</option>
                                                            <option value="Kredit foizi uchun subsidiya ajratish">Kredit foizi uchun subsidiya ajratish</option>
                                                            <option value="Kredit muddatini uzaytirish">Kredit muddatini uzaytirish</option>
                                                        </select>
                                                    </div>

                                                    <div class="mb-3 col-sm-12 col-12">
                                                        <label class="form-label">Qisqacha malumot</label>
                                                        <textarea class="form-control" name="qisqacha" placeholder="Qisqacha malumot" required></textarea>
                                                    </div>


                                                    <div class="mb-3 col-sm-12 col-12">
                                                        <label class="form-label">Tadbirkor sohasi</label>
                                                        <select class="form-select" name="soha">
                                                            <option selected disabled value="">Tanlash...</option>
                                                            <option value="Ishlab chiqarish">Ishlab chiqarish</option>
                                                            <option value="Xizmat ko'rsatish">Xizmat ko'rsatish</option>
                                                            <option value="Qishloq xo'jaligi">Qishloq xo'jaligi</option>
                                                            <option value="Boshqa">Boshqa</option>
                                                        </select>
                                                    </div>
                                                    <div class="mb-3 col-sm-12 col-12">
                                                        <label class="form-label">File yuklash</label>
                                                        <input type="file" class="form-control"
                                                            name="file"required>
                                                    </div>
                                                    <div class="mb-3 col-sm-12 col-12">
                                                        <style>
                                                            #recordedVideo,
                                                            #deleteButton,
                                                            #localVideoContainer {
                                                                display: none;
                                                            }

                                                            #audioRecordedContainer {
                                                                display: none;
                                                            }

                                                            #recordingIndicator {
                                                                display: none;
                                                                /* Dastlab yashirin */
                                                                color: red;
                                                                /* Matn rangini qizil qilib belgilash */
                                                                font-weight: bold;
                                                                margin-top: 10px;
                                                                font-size: 20px;
                                                                /* Matn o'lchamini oshirish */
                                                            }

                                                            /* Yozilayotgan audio ko'rsatkichining tarzi */
                                                            .recording {
                                                                display: inline-block;
                                                                /* Inline-block uslubini qo'llash */
                                                                animation: blinker 1s linear infinite;
                                                                /* Blinking effect */
                                                            }

                                                            @keyframes blinker {
                                                                50% {
                                                                    opacity: 0;
                                                                }

                                                                /* Yozuvni ko'rinmas qilish */
                                                            }
                                                        </style>
                                                        <div id="localVideoContainer">
                                                            <video id="localVideo" autoplay playsinline
                                                                style="width: 600px; height: auto; border: 1px solid black;"></video>
                                                            <video id="recordedVideo" controls
                                                                style="width: 600px; height: auto; border: 1px solid black;"></video>
                                                            <button id="deleteButton" class="btn btn-danger"><i
                                                                    class='bx bx-trash'></i></button>
                                                        </div>
                                                        <div id="recordingIndicator">Yozilmoqda... <span
                                                                class="recording">●</span></div>
                                                        <div id="audioRecordedContainer">
                                                            <audio id="recordedAudioPlayer" controls
                                                                style="width: 100%;"></audio>
                                                            <br>
                                                            <button id="audioDeleteButton" class="btn btn-danger"><i
                                                                    class='bx bx-trash'></i></button>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer justify-content-between">
                                                        <div class="salom">
                                                            <a href="javascript:void(0);" id="startRecordingButton"
                                                                class="btn btn-success"><i class='bx bxs-video'></i></a>
                                                            <a href="javascript:void(0);" id="audioStartButton"
                                                                class="btn btn-warning"><i
                                                                    class='bx bxs-microphone'></i></a>
                                                        </div>
                                                        <div>
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Yopish</button>
                                                            <button class="btn btn-primary">Saqlash</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    var url = "{{ url('/') }}";
                                </script>
                                <script src="{{ asset('js/fetch.js') }}"></script>
                                <script src="{{ asset('js/confirm_code.js') }}"></script>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">Murojaat ID</th>
                                            <th scope="col">Mazmuni</th>
                                            <th scope="col">Tadbirkor</th>
                                            <th scope="col">Murojaat sohasi</th>
                                            <th scope="col">Masul</th>
                                            <th scope="col">Muddat</th>
                                            <th scope="col">Joriy holati</th>
                                            <th scope="col">Tadbirkorlik sohasi</th>
                                            <th scope="col">Yuklangan file</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody id="murojaatsTableBody">
                                        @foreach ($murojaatlar as $murojaat)
                                            <tr>
                                                <th scope="row">{{ $murojaat->id }}</th>
                                                <td>{{ $murojaat->subject }}</td>
                                                <td>
                                                    <a href="{{ route('murojaat.batafsil', ['murojaat' => $murojaat->company->id]) }}">{{ $murojaat->company->name ?? '0' }}</a>
                                                </td>
                                                <td>{{ $murojaat->murojaat_type }}</td>
                                                <td>
                                                    <img src="{{ asset('assets/img/avatar.png') }}"
                                                        style="border-radius:50%;width:30px" alt="Profile">
                                                    @if ($murojaat->nazoratchi == '0')
                                                        <span style="font-weight:bold">-</span>
                                                    @else
                                                        {{ $murojaat->nazoratchi }}
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($murojaat->time == '0')
                                                        <span style="font-weight:bold">-</span>
                                                    @else
                                                        {{ $murojaat->time }}
                                                    @endif
                                                </td>
                                                <td>
                                                    @if ($murojaat->holat == '1' || $murojaat->holat == null)
                                                        <span class="badge bg-warning large">Yangi</span>
                                                    @elseif($murojaat->holat == '2')
                                                        <span class="badge bg-danger large">Ko'rib chiqilmoqda</span>
                                                    @elseif($murojaat->holat == '3')
                                                        <span class="badge bg-info large">Yopilgan</span>
                                                    @endif
                                                </td>
                                                <td>{{ $murojaat->soha }}</td>
                                                <td>
                                                    <a href="files/{{ $murojaat->file }}" target="_blank">Fileni
                                                        ochish</a>
                                                </td>
                                                <td>
                                                @if (Auth::user()->role == 'super')
                                                    <a data-bs-toggle="modal" class="btn btn-primary"
                                                        data-bs-target="#editmurojaat{{ $murojaat->id }}"
                                                        href=""><i class='bx bx-pencil'></i>
                                                    </a>
                                                @endif
                                                    <a data-bs-toggle="modal" class="btn btn-danger"
                                                        data-bs-target="#deletemurojaat{{ $murojaat->id }}"
                                                        href="#"><i class='bx bx-trash'></i></a>

                                                </td>
                                                <div class="col-12">
                                                    <div class="modal fade" id="editmurojaat{{ $murojaat->id }}"
                                                        tabindex="-1" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                        Murojaatni taxrirlash
                                                                    </h1>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <form
                                                                        action="{{ route('murojaat.update', ['murojaat' => $murojaat->id]) }}"
                                                                        method="POST" class="row"
                                                                        enctype="multipart/form-data">
                                                                        @csrf
                                                                        <div class="mb-3 col-sm-12 col-12">
                                                                            <label class="form-label">Mavzu</label>
                                                                            <input type="text" class="form-control"
                                                                                name="subject" placeholder="Mavzu"
                                                                                value="{{ $murojaat->subject }}" required>
                                                                        </div>

                                                                        <div class="mb-3 col-sm-12 col-12">
                                                                            <label class="form-label">Nazoratchi</label>
                                                                            <select class="form-select" name="nazoratchi">
                                                                                <option selected disabled value="">
                                                                                    Tanlash...</option>
                                                                                <option value="Bojxona qo'mitasi">Bojxona qo'mitasi
                                                                                </option>
                                                                                <option value="Markaziy bank">Markaziy bank</option>
                                                                                <option value="Prokuratura shtabi">Prokuratura shtabi</option>
                                                                                <option value="Savdo-sanoat palatasi">Savdo-sanoat palatasi</option>
                                                                                <option value="Soliq boshqarmasi">Soliq boshqarmasi</option>
                                                                            </select>
                                                                        </div>

                                                                        <div class="mb-3 col-sm-12 col-12">
                                                                            <label class="form-label">Muxlat</label>
                                                                            <input type="datetime-local"
                                                                                class="form-control" name="time"
                                                                                placeholder="Muxlat" required>
                                                                        </div>

                                                                        <div class="modal-footer">
                                                                            <button type="button"
                                                                                class="btn btn-secondary"
                                                                                data-bs-dismiss="modal">Yopish</button>
                                                                            <button
                                                                                class="btn btn-primary">Saqlash</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade" id="deletemurojaat{{ $murojaat->id }}"
                                                    tabindex="-1" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                    O'chirish
                                                                </h1>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Haqiqatdan ham ushbu murojaatni o'chirmoqchimisiz?</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Yo'q</button>
                                                                <form
                                                                    action="{{ route('murojaat.destroy', ['murojaat' => $murojaat->id]) }}"
                                                                    method="POST">
                                                                    @method('DELETE')
                                                                    @csrf
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Ha</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </section>
    </div> --}}

    </main>
    <script>
        let stream; // Oqim uchun o'zgaruvchi
        let mediaRecorder; // `MediaRecorder` yozish uchun
        let recordedChunks = []; // Yozilgan qismlarni saqlash uchun

        // Oqimni va `MediaRecorder`ni boshlash
        async function startRecording() {
            document.getElementById('localVideoContainer').style.display = "block";

            try {
                // Kamera va mikrofondan oqim olish
                stream = await navigator.mediaDevices.getUserMedia({
                    video: true,
                    audio: true
                });

                // Oqimni video elementga biriktirish
                const videoElement = document.getElementById('localVideo');
                videoElement.srcObject = stream;

                // `MediaRecorder`ni oqim bilan boshlash
                mediaRecorder = new MediaRecorder(stream);

                // Yozilgan qismlarni saqlash
                mediaRecorder.ondataavailable = (event) => {
                    if (event.data.size > 0) recordedChunks.push(event.data);
                };

                // Yozishni boshlash
                mediaRecorder.start();
                console.log("Yozish boshlandi");

                // Tugma matnini "Yozishni to'xtatish" deb o'zgartirish
                document.getElementById('startRecordingButton').textContent = "Yozishni to'xtatish";

            } catch (error) {
                console.error("Video va audio oqimini boshlashda xatolik:", error);
            }
        }

        // Yozishni to'xtatish va yozilgan videoni ko'rsatish
        function stopRecording() {
            if (mediaRecorder && mediaRecorder.state !== "inactive") {
                // Yozishni to'xtatish
                mediaRecorder.stop();
                console.log("Yozish to'xtatildi");

                // Oqimdagi barcha treklarni to'xtatish
                stream.getTracks().forEach(track => track.stop());

                // Yozilgan videoni chiqarish
                mediaRecorder.onstop = () => {
                    const recordedBlob = new Blob(recordedChunks, {
                        type: "video/webm"
                    });
                    const recordedUrl = URL.createObjectURL(recordedBlob);

                    // Jonli video o'rniga yozilgan videoni qo'yish
                    const localVideo = document.getElementById('localVideo');
                    localVideo.style.display = "none"; // Jonli video ko'rinmaydi

                    const recordedVideo = document.getElementById('recordedVideo');
                    recordedVideo.src = recordedUrl;
                    recordedVideo.style.display = "block"; // Yozilgan video ko'rinadi

                    // "O'chirish" tugmasini ko'rsatish
                    document.getElementById('deleteButton').style.display = "inline-block";

                    // Tugma matnini "Yozishni boshlash" deb qayta o'zgartirish
                    document.getElementById('startRecordingButton').textContent = "Yozishni boshlash";
                    console.log("Yozilgan video tayyor va chiqarildi");
                };
            }
        }

        // Yozilgan videoni o'chirish
        function deleteRecording() {
            document.getElementById('localVideoContainer').style.display = "none";
            const recordedVideo = document.getElementById('recordedVideo');
            recordedVideo.src = ""; // Yozilgan video URL-ni o'chirish
            recordedVideo.style.display = "none"; // Yozilgan videoni yashirish

            // "O'chirish" tugmasini yashirish
            document.getElementById('deleteButton').style.display = "none";

            // Yana jonli video olish imkonini yaratish
            document.getElementById('localVideo').style.display = "block";
            recordedChunks = []; // Yozilgan qismlarni tozalash
        }

        // Tugmani bosganda yozishni boshlash yoki to'xtatish
        document.getElementById('startRecordingButton').addEventListener('click', () => {
            if (!mediaRecorder || mediaRecorder.state === "inactive") {
                startRecording(); // Agar yozish hali boshlanmagan bo'lsa, boshlash
            } else {
                stopRecording(); // Aks holda, yozishni to'xtatish
            }
        });

        // "O'chirish" tugmasi uchun event qo'shish
        document.getElementById('deleteButton').addEventListener('click', deleteRecording);
    </script>
    <script>
        let audioRecorder; // Audio yozish uchun MediaRecorder
        let audioChunks = []; // Yozilgan audio qismlarni saqlash uchun

        // Oqimni va `MediaRecorder`ni boshlash
        async function startAudioRecording() {
            // Dastlab audio konteynerini yashirish
            document.getElementById('audioRecordedContainer').style.display = "none";

            try {
                // Faqat audio oqimini olish
                const audioStream = await navigator.mediaDevices.getUserMedia({
                    audio: true
                });

                // `MediaRecorder`ni audio oqim bilan boshlash
                audioRecorder = new MediaRecorder(audioStream);

                // Yozilgan qismlarni saqlash
                audioRecorder.ondataavailable = (event) => {
                    if (event.data.size > 0) audioChunks.push(event.data);
                };

                // Yozishni boshlash
                audioRecorder.start();
                console.log("Audio yozish boshlandi");

                // Tugma matnini "Yozishni to'xtatish" deb o'zgartirish
                document.getElementById('audioStartButton').textContent = "Yozishni to'xtatish";
            } catch (error) {
                console.error("Audio oqimini boshlashda xatolik:", error);
            }
        }

        // Yozishni to'xtatish va yozilgan audiolarni ko'rsatish
        function stopAudioRecording() {
            if (audioRecorder && audioRecorder.state !== "inactive") {
                audioRecorder.stop();
                console.log("Audio yozish to'xtatildi");

                // Yozilgan audiolarni chiqarish
                audioRecorder.onstop = () => {
                    const recordedAudioBlob = new Blob(audioChunks, {
                        type: "audio/webm"
                    });
                    const audioUrl = URL.createObjectURL(recordedAudioBlob);

                    // Yozilgan audiolarni audio elementiga qo'yish va ko'rinadigan qilish
                    const audioPlayer = document.getElementById('recordedAudioPlayer');
                    audioPlayer.src = audioUrl;
                    document.getElementById('audioRecordedContainer').style.display =
                        "block"; // Konteynerni ko'rinadigan qilish

                    // Tugma matnini "Yozishni boshlash" deb qayta o'zgartirish
                    document.getElementById('audioStartButton').textContent = "Yozishni boshlash";
                    console.log("Yozilgan audio tayyor va chiqarildi");
                };
            }
        }

        // Yozilgan audiolarni o'chirish
        function deleteRecordedAudio() {
            audioChunks = []; // Avvalgi yozilgan qismlarni tozalash
            const audioPlayer = document.getElementById('recordedAudioPlayer');
            audioPlayer.src = ""; // Audio URLini tozalash
            document.getElementById('audioRecordedContainer').style.display = "none"; // Konteynerni yashirish
        }

        // Tugmani bosganda yozishni boshlash yoki to'xtatish
        document.getElementById('audioStartButton').addEventListener('click', () => {
            if (!audioRecorder || audioRecorder.state === "inactive") {
                startAudioRecording(); // Agar yozish hali boshlanmagan bo'lsa, boshlash
            } else {
                stopAudioRecording(); // Aks holda, yozishni to'xtatish
            }
        });

        // O'chirish tugmasi uchun event qo'shish
        document.getElementById('audioDeleteButton').addEventListener('click', deleteRecordedAudio);
    </script>




@endsection
