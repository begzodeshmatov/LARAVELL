@extends('layouts.app')

@section('content')
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Kabinet</h1>
        </div>
        <section class="section profile">
            <div class="row">
                <div class="col-xl-4">
                    <div class="card">
                        <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                            <img src="{{ asset($myself->image->name ?? 'assets/img/profile-image.png') }}" alt="Profile"
                                class="max-w-[200px] min-w-[200px] max-h-[200px] min-h-[200px] rounded-full border-1 border-blue-900 object-cover">
                            <h2>{{ $myself->name }}</h2>
                            <h3>{{ $myself->position }}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="card">
                        <div class="card-body pt-3">
                            <ul class="nav nav-tabs nav-tabs-bordered">

                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab"
                                        data-bs-target="#profile-overview">Akkaunt ma'lumotlari</button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Profilni
                                        tahrirlash</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab"
                                        data-bs-target="#profile-change-password">Parolni o'zgartirish</button>
                                </li>
                            </ul>
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade show active profile-overview" id="profile-overview">

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">F.I.O</div>
                                        <div class="col-lg-9 col-md-8">{{ $myself->name }}</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Lavozim</div>
                                        <div class="col-lg-9 col-md-8">{{ $myself->position }}</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Telefon raqam</div>
                                        <div class="col-lg-9 col-md-8">{{ $myself->phone_number }}</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Manzil</div>
                                        <div class="col-lg-9 col-md-8">{{ $myself->address }}</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">INN</div>
                                        <div class="col-lg-9 col-md-8">{{ $myself->inn }}</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Email</div>
                                        <div class="col-lg-9 col-md-8">{{ $myself->email }}</div>
                                    </div>
                                </div>
                                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                                    <form action="{{ route('cabinet.update') }}" method="POST"
                                        enctype="multipart/form-data">
                                        @csrf
                                        @method('PUT')
                                        <div class="row mb-3">
                                            <label for="image" class="col-md-4 col-lg-3 col-form-label">Profil
                                                rasmi</label>
                                            <div class="col-md-8 col-lg-9">
                                                <img class="max-w-[150px] min-w-[150px] max-h-[150px] min-h-[150px] rounded-full border-1 border-blue-900 object-cover"
                                                    src="{{ asset($myself->image->name ?? 'assets/img/profile-image.png') }}"
                                                    alt="Profile">
                                                <input name="image" type="file" class="form-control" id="image"
                                                    hidden>
                                                <div class="pt-2">
                                                    <a href="#" class="btn btn-primary btn-sm"
                                                        onclick="document.getElementById('image').click()"
                                                        title="Upload new profile image"><i class="bi bi-upload"></i></a>
                                                    <a href="#" class="btn btn-danger btn-sm"
                                                        title="Remove my profile image"><i class="bi bi-trash"></i></a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="name" class="col-md-4 col-lg-3 col-form-label">F.I.O</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="name" type="text" class="form-control" id="name"
                                                    value="{{ $myself->name }}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="position" class="col-md-4 col-lg-3 col-form-label">Lavozim</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="position" type="text" class="form-control" id="position"
                                                    value="{{ $myself->position }}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="phone_number" class="col-md-4 col-lg-3 col-form-label">Telefon
                                                raqm</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="phone_number" type="text" class="form-control"
                                                    id="phone_number" value="{{ $myself->phone_number }}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="address" class="col-md-4 col-lg-3 col-form-label">Manzil</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="address" type="text" class="form-control" id="address"
                                                    value="{{ $myself->address }}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="inn" class="col-md-4 col-lg-3 col-form-label">INN</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="inn" type="number" class="form-control" id="inn"
                                                    value="{{ $myself->inn }}">
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="email" type="email" class="form-control" id="email"
                                                    value="{{ $myself->email }}">
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">O'zgarishlarni saqlash</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade pt-3" id="profile-change-password">
                                    <form action="{{ route('profile.password') }}" method="POST">
                                        @csrf
                                        @method('PUT')
                                        <div class="row mb-3">
                                            <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Joriy parol</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="old_password" type="password" class="form-control"
                                                    id="currentPassword">
                                            </div>
                                        </div>
                                        <p class="text-danger my-3">Parol esdan chiqsa admin bilan bog'lanib emailingizni taqdim eting</p>

                                        <div class="row mb-3">
                                            <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">Yangi parol</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="password" type="password" class="form-control"
                                                    id="newPassword">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Yangi parolni tasdiqlang</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="password_confirmation" type="password" class="form-control"
                                                    id="renewPassword">
                                            </div>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">O'zgartirish</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
