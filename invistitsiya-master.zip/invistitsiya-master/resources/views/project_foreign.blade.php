@extends('layouts.app')

@section('css')
    <script src="https://cdn.tailwindcss.com"></script>
@endsection

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Loyihani tahrirlash</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('foreign') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active"><a href="{{ route('project.index.foreign') }}">Loyihalar</a></li>
                    <li class="breadcrumb-item active">Loyihani tahrirlash</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <section class="section">
            <div class="row">
                <div class="col-xxl-8 col-12">
                    <div class="card ">
                        <div class="card-body">
                            <h5 class="card-title">Loyiha ma'lumotlarini tahrirlash</h5>

                            <form action="{{ route('project.update.foreign', ['project' => $project->id]) }}" method="POST"
                                class="row g-3" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')

                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyiha tashabbuskori</label>
                                    <input type="text" class="form-control" name="name" value="{{ $project->name }}"
                                        required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyiha nomi</label>
                                    <input type="text" class="form-control" name="goal" value="{{ $project->goal }}"
                                        required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyiha raxbari</label>
                                    <input type="text" class="form-control" name="leader" value="{{ $project->leader }}"
                                        placeholder="Loyiha raxbari" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Manzili</label>
                                    <input type="text" class="form-control" name="address"
                                        value="{{ $project->address }}" placeholder="Manzili" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Turi</label>
                                    <select class="form-select" name="type" id="type_confirmation">
                                        <option {{ $project->confirmation['type'] == 'JSHSHIR' ? 'selected' : '' }}
                                            value="JSHSHIR">JSHSHIR</option>
                                        <option {{ $project->confirmation['type'] == 'STIR' ? 'selected' : '' }}
                                            value="STIR">STIR</option>
                                    </select>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label"><span id="label_confirmation">JSHSHIR</span></label>
                                    <input type="text" id="confirm_number" class="form-control" name="confirm_number"
                                        placeholder="0000000000000000"
                                        value="{{ $project->confirmation['confirm_number'] }}" pattern="\d{16}"
                                        maxlength="16" title="Faqat 16 ta raqam kiriting" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">O'rganish natijasi bo'yicha xulosa</label>
                                    <textarea class="form-control" name="conclusion" cols="30" rows="6" required>{{ $project->conclusion }}</textarea>
                                </div>
                                <div class="mb-3 col-sm-3 col-12">
                                    <label class="form-label">Tuman</label>
                                    <select class="form-select" name="district" id="district">
                                        <option selected disabled value="">Tanlash...</option>
                                        @foreach ($districts as $district)
                                            <option value="{{ $district->id }}"
                                                {{ $project->district->id == $district->id ? 'selected' : '' }}>
                                                {{ $district->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-sm-3 col-12">
                                    <label class="form-label">Soha</label>
                                    <select class="form-select" name="field" id="field">
                                        <option selected disabled value="">Tanlash...</option>
                                        @foreach ($fields as $field)
                                            <option value="{{ $field->id }}"
                                                {{ $project->field->id == $field->id ? 'selected' : '' }}>
                                                {{ $field->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Hudud maydoni</label>
                                    <input type="text" class="form-control" name="area"
                                        value="{{ $project->area }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Muddati</label>
                                    <input type="date" class="form-control" name="date"
                                        value="{{ $project->date }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyiha qiymati (mln. dollar)</label>
                                    <input type="text" class="form-control" name="value"
                                        value="{{ $project->value }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyihaga xizmat ko'rsatuvchi bank</label>
                                    <input type="text" class="form-control"
                                        placeholder="Loyihaga xizmat ko'rsatuvchi bank" name="bank"
                                        value="{{ $project->bank }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Bank krediti (mln. dollar)</label>
                                    <input type="text" class="form-control" name="credit"
                                        value="{{ $project->credit }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Amalda bajarildi (mln. dollar)</label>
                                    <input type="text" class="form-control" placeholder="Amalda bajarildi"
                                        name="actually_done" value="{{ $project->actually_done }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">O'z mablag'i hisobidan (mln. dollar)</label>
                                    <input type="text" class="form-control" placeholder="O'z mablag'i hisobidan"
                                        name="own_price" value="{{ $project->own_price }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Xorijiy investitsiya (mln. dollar)</label>
                                    <input type="tel" class="form-control" name="foreign"
                                        value="{{ $project->foreign }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyiha quvvati</label>
                                    <input type="text" class="form-control" name="power"
                                        value="{{ $project->power }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Loyiha quvvati birligi</label>
                                    <select class="form-select" name="unity" id="unity">
                                        <option selected disabled value="">Tanlash...</option>
                                        @foreach ($unities as $unity)
                                            <option value="{{ $unity->id }}"
                                                {{ $project->unity_id == $unity->id ? 'selected' : '' }}>
                                                {{ $unity->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Yaratilgan ish o'rni</label>
                                    <input type="number" class="form-control" name="number_of_vacancies"
                                        value="{{ $project->number_of_vacancies }}" required>
                                </div>
                                <div class="mb-3 col-sm-6 col-12">
                                    <label class="form-label">Amalda</label>
                                    <input type="number" class="form-control" name="available_vacancies"
                                        value="{{ $project->available_vacancies }}" required>
                                </div>
                                <button type="submit" class="btn btn-primary">O'zgartirish</button>
                            </form>
                        </div>
                        <script src="{{ asset('js/confirm_code.js') }}"></script>
                    </div>
                    <div class="card ">
                        <div class="card-body col">
                            <h5 class="card-title">Loyihaga rasm yuklash</h5>
                            <p>Siz faqat 4 ta rasm qo'shishingiz mumkun <span>{{ $project->images()->count() }}/4</span>
                            </p>
                            <form action="{{ route('project.image.foreign', ['project' => $project->id]) }}"
                                method="POST" class="row g-3" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3 col-12">
                                    <label class="form-label">Rasm yuklang</label>
                                    <input type="file" {{ $project->images()->count() == 4 ? 'disabled' : '' }}
                                        class="form-control" name="image" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Yuklash</button>
                            </form>
                        </div>
                    </div>
                    <div class="card ">
                        <div class="card-body col">
                            <h5 class="card-title">Loyiha holatini tahrirlash</h5>

                            <form action="{{ route('project.change.foreign', ['project' => $project->id]) }}"
                                method="POST" class="row g-3" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <div class="mb-3 col-12">
                                    <label class="form-label">Holati</label>
                                    <select class="form-select" name="status" id="status">
                                        <option selected disabled value="">Tanlash...</option>
                                        @foreach ($statuses as $status)
                                            <option value="{{ $status->key }}"
                                                {{ $project->status->id == $status->id ? 'selected' : '' }}>
                                                {{ $status->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-12">
                                    <label class="form-label">Izoh</label>
                                    <textarea class="form-control" name="comment" id="comment" cols="30" rows="10" required>{{ $project->comment }}</textarea>
                                </div>
                                <div class="mb-3 col-12">
                                    <label class="form-label">Bajarilgan sana</label>
                                    <input class="form-control" type="date" name="done_at" id="done_at"
                                        value="{{ $project->done_at }}" required>
                                </div>
                                <div class="mb-3 col-12">
                                    <label class="form-label">Muddatni uzytirish</label>
                                    <input class="form-control" type="date" name="date" id="extend"
                                        value="{{ $project->date }}" required>
                                </div>
                                <button type="submit" class="btn btn-primary">O'zgartirish</button>
                            </form>
                        </div>
                        <script src="{{ asset('js/status.js') }}"></script>
                    </div>
                    <div class="card">
                        <div class="card-body col">
                            <h5 class="card-title">
                                {{ $project->file ? "Loyihadagi dalolatnomani o'zgartirish, o'chirish" : 'Loyihaga dalolatnoma kiritish' }}
                            </h5>
                            @if ($project->file == null)
                                <form action="{{ route('project.deed.foreign', ['project' => $project->id]) }}"
                                    method="POST" class="row g-3" enctype="multipart/form-data">
                                    @csrf
                                    <div class="mb-3 col-12">
                                        <label class="form-label">Fayl yuklang</label>
                                        <input type="file" class="form-control" name="file" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Yuklash</button>
                                </form>
                            @else
                                <form
                                    action="{{ route('deed.update.foreign', ['project' => $project->id, 'file' => $project->file->id]) }}"
                                    method="POST" class="row g-3" enctype="multipart/form-data">
                                    @method('PUT')
                                    @csrf
                                    <div class="mb-3 col-12">
                                        <label class="form-label">O'zgartirish uchun fayl yuklang</label>
                                        <input type="file" class="form-control" name="file" required>
                                    </div>
                                    <div class="row">
                                        <div class="col-11">
                                            <button type="submit" class="btn btn-primary px-md-5 mx-md-5">Yuklash</button>
                                        </div>
                                        <div class="col-1">
                                            <a data-bs-toggle="modal" class="btn btn-danger mr-5"
                                                data-bs-target="#deleteDeed" href="#"><i
                                                    class='bx bx-trash'></i></a>
                                        </div>
                                    </div>
                                </form>
                                <div class="modal fade" id="deleteDeed" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Haqiqatdan ham <span class="text-uppercase">dalolatnoma</span> ni
                                                    o'chirmoqchimisiz</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Yo'q</button>
                                                <form
                                                    action="{{ route('deed.destroy.foreign', ['project' => $project->id, 'file' => $project->file->id ?? 1]) }}"
                                                    method="POST">
                                                    @method('DELETE')
                                                    @csrf
                                                    <button type="submit" class="btn btn-primary">Ha</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body col">
                            <h5 class="card-title">
                                Loyihadagi muammolar
                            </h5>
                            <button
                                class="btn btn--add btn btn-primary  position-absolute top-0 end-0 mt-3  translate-middle-x"
                                type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                    class="bi bi-plus"></i></button>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Loyihada mavjud
                                                muammolarni kiritish
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form
                                                action="{{ route('project.problem.foreign', ['project' => $project->id]) }}"
                                                method="POST" class="row" enctype="multipart/form-data">
                                                @csrf
                                                <div class="mb-3 col-12">
                                                    <textarea class="form-control" name="text" cols="15" rows="6" required></textarea>
                                                </div>
                                                <div class="model-footer">
                                                    <button class="btn btn-primary">Qo'shish</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col" style="min-width: 250px">Matni</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($project->problems as $problem)
                                            <tr>
                                                <th scope="row">{{ $problem->id }}</th>
                                                <td>
                                                    <p class="max-w-96 max-h-32 overflow-auto text-wrap">
                                                        {{ $problem->text }}</p>
                                                </td>
                                                <td>
                                                    <a data-bs-toggle="modal" class="btn btn-primary m-1"
                                                        data-bs-target="#editProblem{{ $problem->id }}"
                                                        href="#"><i class="bx bx-pencil"></i></a>
                                                    <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                        data-bs-target="#deleteProblem{{ $problem->id }}"
                                                        href="#"><i class='bx bx-trash'></i></a>
                                            </tr>
                                            <div class="modal fade" id="deleteProblem{{ $problem->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Bekor qilish</button>
                                                            <form
                                                                action="{{ route('problem.destroy.foreign', ['project' => $project->id, 'problem' => $problem->id]) }}"
                                                                method="POST">
                                                                @method('DELETE')
                                                                @csrf
                                                                <button type="submit"
                                                                    class="btn btn-primary">O'chirish</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div>
                                @foreach ($project->problems as $problem)
                                    <div class="modal fade" id="editProblem{{ $problem->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Muammo mantnini
                                                        tahrirlash</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form
                                                        action="{{ route('problem.update.foreign', ['project' => $project->id, 'problem' => $problem->id]) }}"
                                                        method="POST" class="row" enctype="multipart/form-data">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="mb-3 col-12">
                                                            <textarea class="form-control" name="text" cols="15" rows="6" required>{{ $problem->text }}</textarea>
                                                        </div>
                                                        <div class="model-footer">
                                                            <button class="btn btn-primary">Saqlash</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body col">
                            <h5 class="card-title">Loyiha rasmlari</h5>
                            <p>Hozirgi rasmlar soni <span>{{ $project->images()->count() }}/4</span></p>
                            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-indicators">
                                    @foreach ($project->images as $index => $image)
                                        <button type="button" data-bs-target="#carouselExampleIndicators"
                                            data-bs-slide-to="{{ $index }}"
                                            class="{{ $index == 0 ? 'active' : '' }}"
                                            aria-current="{{ $index == 0 ? 'true' : 'false' }}"
                                            aria-label="Slide {{ $index + 1 }}"></button>
                                    @endforeach
                                </div>
                                <div class="carousel-inner">
                                    @foreach ($project->images as $index => $image)
                                        <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                            <div class="d-flex justify-content-around m-2">
                                                <a data-bs-toggle="modal" class="btn btn-primary"
                                                    data-bs-target="#editImage{{ $image->id }}" href="#"><i
                                                        class='bx bx-pencil'></i></a>
                                                <a data-bs-toggle="modal" class="btn btn-danger ml-5"
                                                    data-bs-target="#deleteImage{{ $image->id }}" href="#"><i
                                                        class='bx bx-trash'></i></a>
                                            </div>
                                            <img src="{{ asset('storage/' . str_replace('public/', '', $image->path)) }}"
                                                class="d-block w-100" alt="{{ $image->name }}">
                                        </div>
                                        <div class="modal fade" id="editImage{{ $image->id }}" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Rasmni
                                                            tahrirlash</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form
                                                            action="{{ route('image.update.foreign', ['project' => $project->id, 'image' => $image->id]) }}"
                                                            method="POST" class="row g-3" enctype="multipart/form-data">
                                                            @method('PUT')
                                                            @csrf
                                                            <div class="mb-3 col-12">
                                                                <label class="form-label">Rasm yuklang</label>
                                                                <input type="file" class="form-control" name="image"
                                                                    required>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Bekor qilish</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Yuklash</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal fade" id="deleteImage{{ $image->id }}" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Haqiqatdan ham ushbu rasmni o'chirmoqchimisiz</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Yo'q</button>
                                                        <form
                                                            action="{{ route('image.destroy.foreign', ['project' => $project->id, 'image' => $image->id]) }}"
                                                            method="POST">
                                                            @method('DELETE')
                                                            @csrf
                                                            <button type="submit" class="btn btn-primary">Ha</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <button class="carousel-control-prev" type="button"
                                    data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button"
                                    data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
