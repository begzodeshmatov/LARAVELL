@extends('layouts.app')

@section('content')
    <main id="main" class="main">
        <img src="{{ asset('assets/img/logo-image-of-login.png') }}" alt="" id="orqafon_rasm">
        <div class="pagetitle">
            <h1>Yillar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item active">Yillar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            {{-- <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <h2 class="text-center mb-4 text-dark font-weight-bold bg-light text-uppercase fs-3">JIZZAX VILOYATI EXPORT<span class="text-primary"> KO'RSATKICHLARI</span></h2>
                        @foreach ($years as $year)
                            @php
                                $months = App\Company::with(['companyReports' => function ($query) use ($year) {
                                        $query->where('year', $year);
                                    },
                                    'companyReports.monthlyReports',
                                ])->get()->flatMap(function ($company) {
                                        return $company->companyReports->flatMap->monthlyReports;
                                    });
                                $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($months);
                                $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz(
                                    $months,
                                );
                            @endphp
                            <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                                <div class="card info-card sales-card">
                                    <a href="{{ route('report.districts', ['year' => $year]) }}">
                                        <div class="card-body">
                                            <h5 class="card-title fs-1">{{ $year }}</h5>
                                            <div class="d-flex align-items-center">
                                                <div class="ps-3">
                                                    <h6 class="text-danger fs-5">Pragnoz: <span id="irregularPrice" data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }} </span> ming doll.
                                                    </h6>
                                                    <h6 class="text-danger fs-5">Amalda: <span id="irregularPrice" data-price="{{ $totalPrice }}">{{ $totalPrice }}</span> ming doll.
                                                    </h6>
                                                    <h6 class="text-danger fs-5">Foizda: <span id="irregularPrice" data-price="
                                                        @if ($tottalPragnoz > 0)
                                                            @if ( round($totalPrice * 100 / $tottalPragnoz, 2) > 100 )
                                                                {{100}}
                                                            @else
                                                                {{ round($totalPrice * 100 / $tottalPragnoz, 2) }}
                                                            @endif
                                                        @else
                                                            {{0}}
                                                        @endif">
                                                        @if ($tottalPragnoz > 0)
                                                            @if ( round($totalPrice * 100 / $tottalPragnoz, 2) > 100 )
                                                                {{100}}
                                                            @else
                                                                {{ round($totalPrice * 100 / $tottalPragnoz, 2) }}
                                                            @endif
                                                        @else
                                                            {{0}}
                                                        @endif
                                                    </span> %</h6>
                                                    <h6 class="text-danger fs-5">Farqi: <span id="irregularPrice" data-price="{{ $totalPrice - $tottalPragnoz }}">{{ $totalPrice - $tottalPragnoz }} </span> ming doll.
                                                    </h6>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div> --}}
            <div class="card">
                <div class="card-body mt-4">
                    <table class="table table-hover table-bordered text-center">
                        <thead>
                            <tr>
                                <th>Yil</th>
                                <th>Pragnoz</th>
                                <th>Amalda</th>
                                <th>Foizda</th>
                                <th>Farqi</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($years as $year)
                                @php
                                    $months = App\Company::with(['companyReports' => function ($query) use ($year) {
                                            $query->where('year', $year);
                                        },
                                        'companyReports.monthlyReports',
                                    ])->get()->flatMap(function ($company) {
                                            return $company->companyReports->flatMap->monthlyReports;
                                        });
                                    $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($months);
                                    $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz(
                                        $months,
                                    );
                                @endphp
                                <tr class="align-items-center ">
                                    <td>
                                        <a href="{{ route('report.districts', ['year' => $year]) }}"
                                            class="text-black btn px-5 py-0 border-0">
                                            {{ $year }}
                                        </a>
                                    </td>
                                    <td>
                                        <p id="irregularPrice" data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}
                                        </p>
                                    </td>
                                    <td>
                                        <p id="irregularPrice" data-price="{{ $totalPrice }}">{{ $totalPrice }}</p>
                                    </td>
                                    <td>
                                        <p><span id="irregularPrice" data-price="
                                            @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif">
                                            @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif
                                        </span> %</p>
                                    </td>
                                    <td>
                                        <p id="irregularPrice" data-price="{{ $totalPrice - $tottalPragnoz }}">{{ $totalPrice - $tottalPragnoz }}</p>
                                    </td>
                                    <td>
                                        <a href="{{ route('report.districts', ['year' => $year]) }}"
                                            class="btn btn-outline-primary">
                                            <i class="bi bi-arrow-right"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </main>
@endsection
