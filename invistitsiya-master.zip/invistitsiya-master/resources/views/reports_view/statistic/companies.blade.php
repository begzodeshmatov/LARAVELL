@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Korxonalar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item">Tumanlar</li>
                    <li class="breadcrumb-item">Sektorlar</li>
                    <li class="breadcrumb-item active">Korxonalar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="card">
                    <div class="card-body mt-4">
                        <table class="table table-hover table-bordered text-center">
                            <thead>
                                <tr>
                                    <th>Korxona</th>
                                    <th>Pragnoz</th>
                                    <th>Amalda</th>
                                    <th>Foizda</th>
                                    <th>Farqi</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($companies as $company)
                                    @php
                                        $months = $company->companyReports->flatMap->monthlyReports;

                                        $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($months);
                                        $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz($months);
                                    @endphp

                                    <tr class="align-items-center ">
                                        <td>
                                            <a href="{{ route('export.company', ['company' => $company->id,]) }}"
                                                class="text-black btn px-5 py-0 border-0">
                                                {{ $company->name }}
                                            </a>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}
                                            </p>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $totalPrice }}">{{ $totalPrice }}</p>
                                        </td>
                                        <td>
                                            <p><span id="irregularPrice" data-price="
                                                @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif">
                                                @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif"
                                            </span> %</p>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $totalPrice - $tottalPragnoz }}">{{ $totalPrice - $tottalPragnoz }}</p>
                                        </td>
                                        <td>
                                            <a href="{{ route('export.company', ['company' => $company->id,]) }}" class="btn btn-outline-primary">
                                                <i class="bi bi-arrow-right"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
