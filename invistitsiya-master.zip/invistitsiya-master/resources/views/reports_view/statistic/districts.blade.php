@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Tumanlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item active">Tumanlar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tumanlar</h5>

                        <table class="table table-hover table-bordered text-center">
                            <tbody>
                                @foreach ($districts as $district)
                                    @php
                                        $companies = $district->companies;
                                        $value = app(App\Services\ReportCalculator::class)->calculate(
                                            $companies,
                                            $type,
                                        );
                                    @endphp
                                    <tr class="align-items-center ">
                                        <th scope="row">{{ $district->id }}</th>
                                        <td>
                                            <a href="{{ route('export.sectors', ['district' => $district->id, 'type' => $type]) }}"
                                                class="text-black btn px-5 py-0 border-0">
                                                {{ $district->name }}
                                            </a>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary rounded-pill p-2" id="irregularPrice"
                                                data-price="{{ $value }}">{{ $value }}</span>
                                        </td>
                                        <td>
                                            <a href="{{ route('export.sectors', ['district' => $district->id, 'type' => $type]) }}"
                                                class="btn btn-outline-primary">
                                                <i class="bi bi-arrow-right"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
