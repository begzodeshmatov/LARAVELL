@extends('layouts.app')

@section('css')
    <style>
        .qizil {
            animation: chiq 5s linear infinite;
        }

        .sariq {
            animation: sariq 5s linear infinite;
            animation-delay: 5s;
        }

        .yashil {
            animation: yashil 5s linear infinite;
            animation-delay: 5s;
        }

        @keyframes yashil {
            100% {
                background: green;
            }
        }

        @keyframes chiq {
            100% {
                background: red;
            }
        }

        @keyframes sariq {
            100% {
                background: yellow;
            }
        }

        .district-btn {
            display: inline-block;
            margin: 5px;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }

        #districts-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
    </style>
    <style>
        #map {
            height: 550px;
        }

        .custom {
            background: #000 !important;
        }

        .population-marker,
        .population-marker2,
        .population-marker3 {
            background: white;
            height: 50px;
            width: 50px;
            transition: all 0.1s;
            display: flex;
            padding: 5px;
            box-shadow: 2px 2px 2px 1px;
            border-radius: 100%;
            justify-content: center;
            align-items: center;
            pointer-events: none;
        }

        .population-marker3 {
            background: #cc0e0e !important;
        }

        .population {
            color: #333;
            pointer-events: none;
            font-size: 15px;
        }

        .attribution {
            font-size: 30px;
            padding: 15px;
        }

        h2 {
            background: white;
            padding: 10px;
        }

        .info {
            padding: 6px 8px;
            font: 14px/16px Arial, Helvetica, sans-serif;
            background: white;
            background: rgba(255, 255, 255, 0.8);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
        }

        .info h4 {
            margin: 0 0 5px;
            color: #777;
        }

        #orqafon_rasm {
            width: 40%;
            height: 80%;
            z-index: -5;
            position: absolute;
            filter: blur(3px);
            top: 40%;
            left: 35%;
        }
    </style>
@endsection

@section('content')
    <main id="main" class="main orqafon">
        <img src="{{ asset('assets/img/logo-image-of-login.png') }}" alt="" id="orqafon_rasm">
        <div class="pagetitle">
            <h1>Loyihalar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('export.statistic') }}">Export</a></li>
                    <li class="breadcrumb-item active">{{ $district->name }}
                        {{ $district->name == 'Jizzax' ? 'shahrida' : 'tumanida' }}</li>
                </ol>
            </nav>
        </div>
        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <h2 class="text-center mb-4 text-dark font-weight-bold bg-light text-uppercase fs-1">
                            {{ $district->name }}
                            {{ $district->name == 'Jizzax' ? 'shahrida' : 'tumanida' }}
                            <span class="text-primary">EXPORT KO'RSATKICHLARI</span>
                        </h2>

                        @php
                            $monthlyReports = $companies->flatMap(function ($company) {
                                return $company->companyReports->flatMap->monthlyReports;
                            });

                            $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($monthlyReports);

                            $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz($monthlyReports);
                            $percentage;
                            if ($tottalPragnoz > 0) {
                                $percentage = round(($totalPrice * 100) / $tottalPragnoz);
                            } else {
                                $percentage = 0;
                            }
                        @endphp
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card sales-card">
                                <a href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'count']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Korxonalar soni</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="ri-slideshow-line"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;" class="text-danger">{{ $companies->count() }}
                                                    <span class="text-dark" style="font-size:20px">ta</span>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'pragnoz']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Yillik pragnoz</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger" id="irregularPrice"
                                                        data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}</span> ming
                                                    doll.
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'price']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Amalda bajarildi</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger" id="irregularPrice"
                                                        data-price="{{ $totalPrice }}">{{ $totalPrice }}</span> ming
                                                    doll.
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'percentage']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Foizda</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;"
                                                        class="text-danger">{{ $percentage }}</span>%
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        @php
                            $monthlyReports = $companies
                                ->where('type', 'Sanoat mahsulotlari')
                                ->flatMap(function ($company) {
                                    return $company->companyReports->flatMap->monthlyReports;
                                });

                            $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($monthlyReports);

                            $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz($monthlyReports);
                        @endphp
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'typefirstpragnoz']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Sanoat mahsulotlari pragnozi</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger" id="irregularPrice"
                                                        data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}</span> ming
                                                    doll.
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'typefirstprice']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Sanoat mahsulotlari amalda</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger"
                                                        id="irregularPrice"
                                                        data-price="{{ $totalPrice }}">{{ $totalPrice }}</span> ming
                                                    doll.
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        @php
                            $monthlyReports = $companies
                                ->where('type', 'Meva-sabzavot mahsulotlari')
                                ->flatMap(function ($company) {
                                    return $company->companyReports->flatMap->monthlyReports;
                                });

                            $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($monthlyReports);

                            $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz($monthlyReports);
                        @endphp
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'typesecondpragnoz']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Meva-sabzavot mahsulotlari pragnozi</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger"
                                                        id="irregularPrice"
                                                        data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}</span>
                                                    ming doll.
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('export.sectors', ['district' => $district->id, 'type' => 'typesecondprice']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Meva-sabzavot mahsulotlari amalda</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class='bx bx-coin'></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger"
                                                        id="irregularPrice"
                                                        data-price="{{ $totalPrice }}">{{ $totalPrice }}</span> ming
                                                    doll.
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xxl-4 col-md-6">
                    <div class="col-12 mt-0">
                        <div class="card info-card  bg-primary"
                            style="clip-path: polygon(0 0, 100% 0, 89% 100%, 12% 100%);">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2 fs-6"> <span class="text-warning">Sanoat
                                        mahsulotlari</span></h5>
                            </div>
                        </div>
                    </div>

                    <div class="card p-3">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-12 mb-0">
                                        <div class="card info-card mb-0 bg-success pb-0">
                                            <h3 class="card-title text-center mb-0 pt-1 pb-1 text-light fs-5">
                                                Jami
                                            </h3>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex  justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center text-center justify-content-center">
                                            <i class="ri-slideshow-line" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-currency-dollar" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin-stack' style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bi bi-people' style="color:green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @php
                                $sortCompanies = $companies->where('type', 'Sanoat mahsulotlari');
                                $companiesCount = $sortCompanies->count();

                                $monthlyReports = $sortCompanies->flatMap(function ($company) {
                                    return $company->companyReports->flatMap->monthlyReports;
                                });

                                $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($monthlyReports);

                                $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz(
                                    $monthlyReports,
                                );
                            @endphp
                            <div class="col-3  px-1">
                                <div class="card h-75 info-card d-flex flex-column">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Loyihalar </h5>
                                    </div>
                                    <div class="card-footer border-0 m-0 p-0 mb-2 text-center">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center">
                                            {{ $companiesCount }} </h6><span class="text-dark"
                                            style="font-size:12px;">ta</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3  px-1 ">
                                <div class="card h-75 info-card text-center">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Pragnoz</h5>
                                    </div>
                                    <div class=" card-footer m-0 p-0 border-0 mb-2">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center"
                                            id="irregularPrice" data-price="{{ $tottalPragnoz }}">
                                            {{ $tottalPragnoz }} </h6><span class="text-dark"
                                            style="font-size:12px;">ming
                                            doll.</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3  px-1">
                                <div class="card h-75 info-card d-flex">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Amalda</h5>
                                    </div>
                                    <div class="card-footer m-0 p-0 border-0 mb-2 text-center">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center"
                                            id="irregularPrice" data-price="{{ $totalPrice }}">
                                            {{ $totalPrice }} </h6><span class="text-dark" style="font-size:12px;">ming
                                            doll.</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3  px-1">
                                <div class="card h-75 info-card d-flex">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Foizda</h5>
                                    </div>
                                    <div class="card-footer border-0 m-0 p-0 mb-2 text-center">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center"
                                            id="irregularPrice"
                                            data-price="
                                            @if ($tottalPragnoz > 0)
                                                {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                            @else
                                                {{0}}
                                            @endif">
                                            @if ($tottalPragnoz > 0)
                                                {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                            @else
                                                {{0}}
                                            @endif
                                        </h6><span class="text-dark" style="font-size:12px;">%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-6">
                    <div class="col-12 mt-0">
                        <div class="card info-card  bg-primary"
                            style="clip-path: polygon(0 0, 100% 0, 89% 100%, 12% 100%);">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2 fs-6"> <span
                                        class="text-warning">Meva-sabzavot mahsulotlari</span></h5>
                            </div>
                        </div>
                    </div>

                    <div class="card p-3">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col-12 mb-0">
                                        <div class="card info-card mb-0 bg-success pb-0">
                                            <h3 class="card-title text-center mb-0 pt-1 pb-1 text-light fs-5">
                                                Jami
                                            </h3>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex  justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center text-center justify-content-center">
                                            <i class="ri-slideshow-line" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-currency-dollar" style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-coin-stack' style="color:green;"></i>
                                        </div>
                                    </div>
                                    <div class="col-3 mt-0 d-flex justify-content-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bi bi-people' style="color:green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @php
                                $sortCompanies = $companies->where('type', 'Meva-sabzavot mahsulotlari');
                                $companiesCount = $sortCompanies->count();

                                $monthlyReports = $sortCompanies->flatMap(function ($company) {
                                    return $company->companyReports->flatMap->monthlyReports;
                                });

                                $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($monthlyReports);

                                $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz(
                                    $monthlyReports,
                                );
                            @endphp
                            <div class="col-3  px-1">
                                <div class="card h-75 info-card d-flex flex-column">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Loyihalar </h5>
                                    </div>
                                    <div class="card-footer border-0 m-0 p-0 mb-2 text-center">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center">
                                            {{ $companiesCount }} </h6><span class="text-dark"
                                            style="font-size:12px;">ta</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3  px-1 ">
                                <div class="card h-75 info-card text-center">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Pragnoz</h5>
                                    </div>
                                    <div class=" card-footer m-0 p-0 border-0 mb-2">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center"
                                            id="irregularPrice" data-price="{{ $tottalPragnoz }}">
                                            {{ $tottalPragnoz }} </h6><span class="text-dark"
                                            style="font-size:12px;">ming doll.</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3  px-1">
                                <div class="card h-75 info-card d-flex">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Amalda</h5>
                                    </div>
                                    <div class="card-footer m-0 p-0 border-0 mb-2 text-center">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center"
                                            id="irregularPrice" data-price="{{ $totalPrice }}">
                                            {{ $totalPrice }} </h6><span class="text-dark" style="font-size:12px;">ming
                                            doll.</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-3  px-1">
                                <div class="card h-75 info-card d-flex">
                                    <div class="flex-grow-1">
                                        <h5 style="font-size:11px;" class="card-title text-center align-items-center">
                                            Foizda</h5>
                                    </div>
                                    <div class="card-footer border-0 m-0 p-0 mb-2 text-center">
                                        <h6 style="font-size: 18px;" class="text-center text-danger align-items-center"
                                            id="irregularPrice"
                                            data-price="
                                            @if ($tottalPragnoz > 0)
                                                {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                            @else
                                                {{0}}
                                            @endif">
                                            @if ($tottalPragnoz > 0)
                                                {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                            @else
                                                {{0}}
                                            @endif
                                        </h6><span class="text-dark" style="font-size:12px;">%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-4 col-md-6">
                    <div class="col-12">
                        <div class="card info-card  bg-primary">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2">{{ $district->name }}
                                    {{ $district->name == 'Jizzax' ? 'shahri' : 'tumani' }}</h5>
                            </div>
                        </div>
                        <div class="col-12">
                            <img src="{{ $district->image }}" class="img-fluid w-100" alt="Responsive image">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection

@section('js')
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const buttons = document.querySelectorAll(".district-btn");

            const colors = ["#49C754", "#E3D26F", "#33658A", "#276FBF", "#55DBCB", "#9FA4C4", "#B3CDD1", "#4A4E69"];
            const widths = ["150px", "180px", "200px", "170px", "220px", "160px", "190px", "210px"];

            const buttonGroups = [3, 2];

            let groupIndex = 0;

            buttons.forEach((button, index) => {
                const randomColor = colors[Math.floor(Math.random() * colors.length)];
                const randomWidth = widths[Math.floor(Math.random() * widths.length)];

                button.style.backgroundColor = randomColor;
                button.style.borderColor = randomColor;
                button.style.width = randomWidth;

                if (index + 1 >= buttonGroups.slice(0, groupIndex + 1).reduce((a, b) => a + b, 0)) {
                    groupIndex = (groupIndex + 1) % buttonGroups.length;
                }
            });
        });
    </script>
@endsection
