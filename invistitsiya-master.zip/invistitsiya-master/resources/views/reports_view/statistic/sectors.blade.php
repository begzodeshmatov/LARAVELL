@extends('../layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Sektorlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item">Tumanlar</li>
                    <li class="breadcrumb-item active">Sektorlar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Sektorlar</h5>

                        <table class="table table-hover table-bordered text-center">
                            <tbody>
                                @foreach ($sectors as $sector)
                                    @php
                                        $companies = $sector->companies()->where('district_id', $district->id)->get();
                                        $value = app(App\Services\ReportCalculator::class)->calculate(
                                            $companies,
                                            $type,
                                        );
                                    @endphp

                                    <tr class="align-items-center ">
                                        <th scope="row">{{ $sector->id }}</th>
                                        <td>
                                            <a href="{{ route('export.companies', ['district' => $district->id, 'sector' => $sector->id, 'type' => $type]) }}"
                                                class="text-black btn px-5 py-0 border-0">
                                                {{ $sector->name }}
                                            </a>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary rounded-pill p-2" id="irregularPrice"
                                                data-price="{{ $value }}">{{ $value }}</span>
                                        </td>
                                        <td>
                                            <a href="{{ route('export.companies', ['district' => $district->id, 'sector' => $sector->id, 'type' => $type]) }}"
                                                class="btn btn-outline-primary">
                                                <i class="bi bi-arrow-right"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
