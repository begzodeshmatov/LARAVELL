@extends('layouts.app')

@section('content')
    <main id="main" class="main">
        <img src="{{ asset('assets/img/logo-image-of-login.png') }}" alt="" id="orqafon_rasm">
        <div class="pagetitle">
            <h1>Tumanlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('report.years') }}">{{ $year }}-yil</a></li>
                    <li class="breadcrumb-item active">Tumanlar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            {{-- <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        @foreach ($districts as $district)
                            @php
                                $months = $district->companies->flatMap(function ($company) use ($year) {
                                    return $company->companyReports->where('year', $year)->flatMap->monthlyReports;
                                });
                                $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($months);
                                $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz($months);
                            @endphp
                            <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                                <div class="card info-card sales-card">
                                    <a href="{{ route('report.sectors', ['year' => $year, 'district' => $district->id]) }}">
                                        <div class="card-body">
                                            <h5 class="card-title fs-1">{{ $district->name }}</h5>
                                            <div class="d-flex align-items-center">
                                                <div class="ps-3">
                                                    <h6 class="text-danger fs-5">Pragnoz: <span id="irregularPrice" data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}</span>
                                                    </h6>
                                                    <h6 class="text-danger fs-5">Amalda: <span id="irregularPrice" data-price="{{ $totalPrice }}">{{ $totalPrice }}</span>
                                                    </h6>
                                                    <h6 class="text-danger fs-5">Foizda: <span id="irregularPrice" data-price="
                                                        @if ($tottalPragnoz > 0)
                                                            @if ( round($totalPrice * 100 / $tottalPragnoz, 2) > 100 )
                                                                {{100}}
                                                            @else
                                                                {{ round($totalPrice * 100 / $tottalPragnoz, 2) }}
                                                            @endif
                                                        @else
                                                            {{0}}
                                                        @endif">
                                                        @if ($tottalPragnoz > 0)
                                                            @if ( round($totalPrice * 100 / $tottalPragnoz, 2) > 100 )
                                                                {{100}}
                                                            @else
                                                                {{ round($totalPrice * 100 / $tottalPragnoz, 2) }}
                                                            @endif
                                                        @else
                                                            {{0}}
                                                        @endif
                                                    </span> %</h6>
                                                    <h6 class="text-danger fs-5">Farqi: <span id="irregularPrice" data-price="{{ $totalPrice - $tottalPragnoz }}">{{ $totalPrice - $tottalPragnoz }}</span>
                                                    </h6>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div> --}}
            <div class="row">
                <div class="card">
                    <div class="card-body mt-4">
                        <table class="table table-hover table-bordered text-center">
                            <thead>
                                <tr>
                                    <th>Tuman</th>
                                    <th>Pragnoz</th>
                                    <th>Amalda</th>
                                    <th>Foizda</th>
                                    <th>Farqi</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($districts as $district)
                                    @php
                                        $months = $district->companies->flatMap(function ($company) use ($year) {
                                            return $company->companyReports->where('year', $year)->flatMap->monthlyReports;
                                        });
                                        $totalPrice = app(App\Services\ReportCalculator::class)->totalPrice($months);
                                        $tottalPragnoz = app(App\Services\ReportCalculator::class)->tottalPragnoz($months);
                                    @endphp
                                    <tr class="align-items-center ">
                                        <td>
                                            <a href="{{ route('report.sectors', ['year' => $year, 'district' => $district->id]) }}"
                                                class="text-black btn px-5 py-0 border-0">
                                                {{ $district->name }}
                                            </a>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $tottalPragnoz }}">{{ $tottalPragnoz }}</p>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $totalPrice }}">{{ $totalPrice }}</p>
                                        </td>
                                        <td>
                                            <p><span id="irregularPrice" data-price="
                                                @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif">
                                                @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif
                                            </span> %</p>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $totalPrice - $tottalPragnoz }}">{{ $totalPrice - $tottalPragnoz }}</p>
                                        </td>
                                        <td>
                                            <a href="{{ route('report.sectors', ['year' => $year, 'district' => $district->id]) }}"
                                                class="btn btn-outline-primary">
                                                <i class="bi bi-arrow-right"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
