@extends('layouts.app')
@php
    $months = [
        '1' => 'Yanvar',
        '2' => 'Fevral',
        '3' => 'Mart',
        '4' => 'Aprel',
        '5' => 'May',
        '6' => 'Iyun',
        '7' => 'Iyul',
        '8' => 'Avgust',
        '9' => 'Sentabr',
        '10' => 'Oktabr',
        '11' => 'Noyabr',
        '12' => 'Dekabr',
    ];
@endphp
@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Oylar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Statistika</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('report.years') }}">{{ $year }}-yil</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('report.districts' , ['year' => $year]) }}">{{ $district->name }}</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('report.sectors' , ['year' => $year, 'district' => $district->id]) }}">{{ $sector->name }}</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('report.companies' , ['year' => $year, 'district' => $district->id, 'sector' => $sector->id]) }}">{{ $company->name }}</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('report.company' , ['year' => $year, 'district' => $district->id, 'sector' => $sector->id, 'company' => $company->id]) }}">Korxona</a></li>
                    <li class="breadcrumb-item active">Oylar</li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="card">
                    <div class="card-body mt-4">
                        <table class="table table-hover table-bordered text-center">
                            <thead>
                                <tr>
                                    <th>Oy</th>
                                    <th>Pragnoz</th>
                                    <th>Amalda</th>
                                    <th>Foizda</th>
                                    <th>Farqi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($montlyReports as $montlyReport)
                                    <tr class="align-items-center ">
                                        <td>{{ $months[$montlyReport->month] }}</td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $montlyReport->pragnoz }}">{{ $montlyReport->pragnoz }}
                                            </p>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $montlyReport->in_practice }}">{{ $montlyReport->in_practice }}</p>
                                        </td>
                                        <td>
                                            <p><span id="irregularPrice" data-price="
                                                @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif">
                                                @if ($tottalPragnoz > 0)
                                                    {{ round($totalPrice * 100 / $tottalPragnoz) }}
                                                @else
                                                    {{0}}
                                                @endif
                                            </span> %</p>
                                        </td>
                                        <td>
                                            <p id="irregularPrice" data-price="{{ $montlyReport->in_practice - $montlyReport->pragnoz }}">{{ $montlyReport->in_practice - $montlyReport->pragnoz }}</p>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
