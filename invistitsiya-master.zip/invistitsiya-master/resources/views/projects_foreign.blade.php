@extends('layouts.app')

@section('css')
    <script src="https://cdn.tailwindcss.com"></script>
@endsection

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Xorijiy loyihalar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">Xorijiy loyihalar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 my-2">
                                    <div class="d-flex justify-content-between">
                                        <h5 class="card-title fs-2">Loyihalar</h5>
                                        <div class="d-flex justify-content-end align-items-center">

                                            <a href="{{ route('project.export.foreign', request()->query()) }}"
                                                class="btn btn btn-outline-success">Export</a>
                                            @can('create', App\ForeignProject::class)
                                                <button class="btn btn--add btn btn-primary mx-2" type="button"
                                                    data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                                        class="bi bi-plus"></i></button>
                                            @endcan
                                        </div>
                                    </div>
                                </div>
                                @can('create', App\ForeignProject::class)
                                    <div class="col-12">
                                        <div class="modal fade" id="exampleModal" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Loyiha qo'shish
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="{{ route('project.store.foreign') }}" method="POST"
                                                            class="row" enctype="multipart/form-data">
                                                            @csrf
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Loyiha tashabbuskori</label>
                                                                <input type="text" class="form-control" name="name"
                                                                    placeholder="Loyiha tashabbuskori" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Loyiha nomi</label>
                                                                <input type="text" class="form-control" name="goal"
                                                                    placeholder="Loyiha nomi" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Loyiha raxbari</label>
                                                                <input type="text" class="form-control" name="leader"
                                                                    placeholder="Loyiha raxbari" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Manzili</label>
                                                                <input type="text" class="form-control" name="address"
                                                                    placeholder="Manzili" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Turi</label>
                                                                <select class="form-select" name="type"
                                                                    id="type_confirmation">
                                                                    <option slected value="JSHSHIR">JSHSHIR</option>
                                                                    <option value="STIR">STIR</option>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label"><span
                                                                        id="label_confirmation">JSHSHIR</span></label>
                                                                <input type="text" id="confirm_number" class="form-control"
                                                                    name="confirm_number" placeholder="0000000000000000"
                                                                    pattern="\d{16}" maxlength="16"
                                                                    title="Faqat 16 ta raqam kiriting" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">O'rganish natijasi bo'yicha
                                                                    xulosa</label>
                                                                <textarea class="form-control" name="conclusion" cols="30" rows="3" required></textarea>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Tuman</label>
                                                                <select class="form-select" name="district" id="district">
                                                                    <option selected disabled value="">Tanlash...
                                                                    </option>
                                                                    @foreach ($districts as $district)
                                                                        <option value="{{ $district->id }}">
                                                                            {{ $district->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Soha</label>
                                                                <select class="form-select" name="field"
                                                                    id="validationDefault04">
                                                                    <option selected disabled value="">Tanlash...
                                                                    </option>
                                                                    @foreach ($fields as $field)
                                                                        <option value="{{ $field->id }}">{{ $field->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Hudud maydoni</label>
                                                                <input type="text" class="form-control" name="area"
                                                                    placeholder="Hudud maydoni" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Muddati</label>
                                                                <input type="date" class="form-control" name="date"
                                                                    placeholder="Sana" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Loyiha qiymati (mln. dollar)</label>
                                                                <input type="text" class="form-control" name="value"
                                                                    placeholder="Loyiha qiymati" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-12 col-12">
                                                                <label class="form-label">Loyihaga xizmat ko'rsatuvchi
                                                                    bank</label>
                                                                <input type="text" class="form-control"
                                                                    placeholder="Loyihaga xizmat ko'rsatuvchi bank"
                                                                    name="bank"required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Bank krediti (mln. dollar)</label>
                                                                <input type="text" class="form-control"
                                                                    placeholder="Bank krediti" name="credit"required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Amalda bajarildi (mln.
                                                                    dollar)</label>
                                                                <input type="text" class="form-control"
                                                                    placeholder="Amalda bajarildi"
                                                                    name="actually_done"required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">O'z mablag'i hisobidan (mln.
                                                                    dollar)</label>
                                                                <input type="text" class="form-control"
                                                                    placeholder="O'z mablag'i hisobidan"
                                                                    name="own_price"required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Xorijiy investitsiya (mln.
                                                                    dollar)</label>
                                                                <input type="tel" class="form-control" name="foreign"
                                                                    placeholder="Xorijiy investitsiya" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Loyiha quvvati</label>
                                                                <input type="text" class="form-control" name="power"
                                                                    placeholder="Loyiha quvvati" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Loyiha quvvati birligi</label>
                                                                <select class="form-select" name="unity"
                                                                    id="validationDefault04">
                                                                    <option selected disabled value="">Tanlash...
                                                                    </option>
                                                                    @foreach ($unities as $unity)
                                                                        <option value="{{ $unity->id }}">
                                                                            {{ $unity->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Yaratilgan ish o'rni</label>
                                                                <input type="number" class="form-control"
                                                                    name="number_of_vacancies"
                                                                    placeholder="Yaratilgan ish o'rni" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-6 col-12">
                                                                <label class="form-label">Amalda</label>
                                                                <input type="number" class="form-control"
                                                                    name="available_vacancies"
                                                                    placeholder="Yaratilgan ish o'rni" required>
                                                            </div>
                                                            <div class="mb-3 col-sm-12 col-12">
                                                                <label class="form-label">Dalolatnoma</label>
                                                                <input type="file" class="form-control" name="file">
                                                            </div>
                                                            <button class="btn btn-primary">Qo'shish</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <script src="{{ asset('js/confirm_code.js') }}"></script>
                                    </div>
                                @endcan
                                <div class="col-12 my-2">
                                    <form action="{{ route('project.index.foreign') }}" method="GET">
                                        <div class="row">
                                            <div class="col-2">
                                                <select name="district" id="districtFilter" class="form-control p-2">
                                                    <option value="">Tuman</option>
                                                    @foreach ($districts as $district)
                                                        <option value="{{ $district->id }}"
                                                            {{ request('district') == $district->id ? 'selected' : '' }}>
                                                            {{ $district->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <select name="status" class="form-control p-2">
                                                    <option value="">Holati</option>
                                                    @foreach ($statuses as $status)
                                                        <option value="{{ $status->id }}"
                                                            {{ request('status') == $status->id ? 'selected' : '' }}>
                                                            {{ $status->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-3">
                                                <input type="text" name="project_name"
                                                    placeholder="Loyiha tashabbuskori"
                                                    value="{{ request('project_name') }}" class="form-control p-2">
                                            </div>
                                            <div class="col-1">
                                                <button type="submit" class="btn btn-primary">Topish</button>
                                            </div>
                                            <div class="col-1">
                                                <a href="{{ route('project.index.foreign') }}"
                                                    class="btn btn-success">Hammasi</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-12 my-2">
                                    <div class="table-responsive m-b-40">
                                        <table class="table table-bordered table-striped table-hover text-center">
                                            <thead>
                                                <tr>
                                                    <th scope="col">№</th>
                                                    <th scope="col" style="min-width: 250px">Loyiha tashabbuskori</th>
                                                    <th scope="col" style="min-width: 250px">Loyiha nomi</th>
                                                    <th scope="col" style="min-width: 250px">O'rganish natijasi
                                                        bo'yicha
                                                        xulosa
                                                    </th>
                                                    <th scope="col" style="min-width: 250px">Manzili</th>
                                                    <th scope="col" style="min-width: 250px">STIR & JSHSHIR</th>
                                                    <th scope="col" style="min-width: 250px">Loyiha raxbari</th>
                                                    <th scope="col" style="min-width: 150px">Tuman</th>
                                                    <th scope="col" style="min-width: 250px">Soha</th>
                                                    <th scope="col" style="min-width: 250px">Xizmat ko'rsativchi bank
                                                    </th>
                                                    <th scope="col">Bank krediti</th>
                                                    <th scope="col">Amalda bajarildi</th>
                                                    <th scope="col">O'z mablag'i hisobidan</th>
                                                    <th scope="col">Xorijiy investitsiya</th>
                                                    <th scope="col">Loyiha qiymati</th>
                                                    <th scope="col" style="min-width: 250px">Maydoni</th>
                                                    <th scope="col">Loyiha quvvati</th>
                                                    <th scope="col">Yaratilgan ish o'rni</th>
                                                    <th scope="col">Amalda</th>
                                                    <th scope="col">Muammolar soni</th>
                                                    <th scope="col" style="min-width: 120px">Sana</th>
                                                    <th scope="col">Holati</th>
                                                    @canany(['update', 'delete'], $projects[0])
                                                        <th scope="col">Amallar</th>
                                                    @endcanany
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($projects as $project)
                                                    <tr>
                                                        <th scope="row">{{ $project->id }}</th>
                                                        <td>{{ $project->name }}</td>
                                                        <td>{{ $project->goal }}</td>
                                                        <td>
                                                            <p class="max-w-96 max-h-32 overflow-auto text-wrap">
                                                                {{ $project->conclusion }}</p>
                                                        </td>
                                                        <td>{{ $project->address }}</td>
                                                        <td><span
                                                                class="text-uppercase">{{ $project->confirmation['type'] }}:</span>{{ $project->confirmation['confirm_number'] }}
                                                        </td>
                                                        <td>{{ $project->leader }}</td>
                                                        <td>{{ $project->district->name }}</td>
                                                        <td>{{ $project->field->name }}</td>
                                                        <td>{{ $project->bank }}</td>
                                                        <td id="irregularPrice" data-price="{{ $project->credit }}">
                                                            {{ $project->credit }}</td>
                                                        <td id="irregularPrice"
                                                            data-price="{{ $project->actually_done }}">
                                                            {{ $project->actually_done }}</td>
                                                        <td id="irregularPrice" data-price="{{ $project->own_price }}">
                                                            {{ $project->own_price }}</td>
                                                        <td id="irregularPrice"
                                                            data-price="{{ $project->foreign }}"{{ $project->foreign }}</td>
                                                        <td id="irregularPrice" data-price="{{ $project->value }}">
                                                            {{ $project->value }}</td>
                                                        <td>
                                                            <p class="max-w-96 max-h-32 overflow-auto text-wrap">
                                                                {{ $project->area }}ga
                                                        </td>
                                                        <td><span id="irregularPrice"
                                                                data-price="{{ $project->power }}"></span>
                                                            {{ $project->unity->name ?? '0' }}</td>
                                                        <td>{{ $project->number_of_vacancies }}</td>
                                                        <td>{{ $project->available_vacancies }}</td>
                                                        <td>{{ $project->problems()->count() }}</td>
                                                        <td>{{ $project->date }}</td>
                                                        <td>{{ $project->status->name }}</td>
                                                        @canany(['update', 'delete'], $project)
                                                            <td>
                                                                <a class="btn btn-primary m-1"
                                                                    href="{{ route('project.edit.foreign', ['project' => $project->id]) }}"><i
                                                                        class="bx bx-pencil"></i></a>
                                                                <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                                    data-bs-target="#deleteProject{{ $project->id }}"
                                                                    href="#"><i class='bx bx-trash'></i></a>
                                                            @endcanany
                                                    </tr>
                                                    @canany(['update', 'delete'], $project)
                                                        <div class="modal fade" id="deleteProject{{ $project->id }}"
                                                            tabindex="-1" aria-labelledby="exampleModalLabel"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                            O'chirish
                                                                        </h1>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p>Haqiqatdan ham ushbu loyihani o'chirmoqchimisiz</p>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Yo'q</button>
                                                                        <form
                                                                            action="{{ route('project.destroy.foreign', ['project' => $project->id]) }}"
                                                                            method="POST">
                                                                            @method('DELETE')
                                                                            @csrf
                                                                            <button type="submit"
                                                                                class="btn btn-primary">Ha</button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endcanany
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-12 my-2">
                                    {{ $projects->links() }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
