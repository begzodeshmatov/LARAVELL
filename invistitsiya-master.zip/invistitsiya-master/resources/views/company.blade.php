@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Korxonani tahrirlash</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active"><a href="{{ route('company.index') }}">Korxonalar</a></li>
                    <li class="breadcrumb-item active">Korxonani tahrirlash</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <section class="section">
            <div class="row">
                <div class="col-xxl-8 col-12">
                    <div class="card ">
                        <div class="card-body col">
                            <h5 class="card-title">Korxona ma'lumotlarini tahrirlash</h5>

                            <form action="{{ route('company.update', ['company' => $company->id]) }}" method="POST"
                                class="row g-3" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <div class="mb-3 col-sm-4 col-12">
                                    <label class="form-label">Tuman</label>
                                    <select class="form-select" name="district" id="district">
                                        <option selected disabled value="">Tanlash...</option>
                                        @foreach ($districts as $district)
                                            <option value="{{ $district->id }}"
                                                {{ $company->district->id == $district->id ? 'selected' : '' }}>
                                                {{ $district->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-sm-4 col-12">
                                    <label class="form-label">Sektor</label>
                                    <select class="form-select" name="sector" id="sector">
                                        <option selected disabled value="">Tanlash...</option>
                                        @foreach ($sectors as $sector)
                                            <option value="{{ $sector->id }}"
                                                {{ $company->sector->id == $sector->id ? 'selected' : '' }}>
                                                {{ $sector->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-sm-4 col-12">
                                    <label class="form-label">Turi</label>
                                    <select class="form-select" name="type"
                                        id="type" required>
                                        <option selected disabled value="">Tanlash...</option>
                                        <option value="Sanoat mahsulotlari" {{ $company->type == 'Sanoat mahsulotlari' ? 'selected' : '' }}>Sanoat mahsulotlari</option>
                                        <option value="Meva-sabzavot mahsulotlari" {{ $company->type == 'Meva-sabzavot mahsulotlari' ? 'selected' : '' }}>Meva-sabzavot mahsulotlari</option>
                                    </select>
                                </div>
                                <div class="mb-3 col-12">
                                    <label class="form-label">Korxona nomi</label>
                                    <input type="text" class="form-control" name="name" value="{{ $company->name }}"
                                        required>
                                </div>
                                <button type="submit" class="btn btn-primary">O'zgartirish</button>
                            </form>
                        </div>
                    </div>
                    <div class="card ">
                        <div class="card-body col">
                            <h5 class="card-title">Korxonaga rasm yuklash</h5>
                            <p>Siz faqat 4 ta rasm qo'shishingiz mumkun <span>{{ $company->images()->count() }}/4</span>
                            </p>
                            <form action="{{ route('company.image', ['company' => $company->id]) }}" method="POST"
                                class="row g-3" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3 col-12">
                                    <label class="form-label">Rasm yuklang</label>
                                    <input type="file" {{ $company->images()->count() == 4 ? 'disabled' : '' }}
                                        class="form-control" name="image" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Yuklash</button>
                            </form>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body col">
                            <h5 class="card-title">Korxona rasmlari</h5>
                            <p>Hozirgi rasmlar soni <span>{{ $company->images()->count() }}/4</span></p>
                            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-indicators">
                                    @foreach ($company->images as $index => $image)
                                        <button type="button" data-bs-target="#carouselExampleIndicators"
                                            data-bs-slide-to="{{ $index }}"
                                            class="{{ $index == 0 ? 'active' : '' }}"
                                            aria-current="{{ $index == 0 ? 'true' : 'false' }}"
                                            aria-label="Slide {{ $index + 1 }}"></button>
                                    @endforeach
                                </div>
                                <div class="carousel-inner">
                                    @foreach ($company->images as $index => $image)
                                        <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                                            <div class="d-flex justify-content-around m-2">
                                                <a data-bs-toggle="modal" class="btn btn-primary"
                                                    data-bs-target="#editImage{{ $image->id }}" href="#"><i
                                                        class='bx bx-pencil'></i></a>
                                                <a data-bs-toggle="modal" class="btn btn-danger ml-5"
                                                    data-bs-target="#deleteImage{{ $image->id }}" href="#"><i
                                                        class='bx bx-trash'></i></a>
                                            </div>
                                            <img src="{{ asset('storage/' . str_replace('public/', '', $image->path)) }}"
                                                class="d-block w-100" alt="{{ $image->name }}">
                                        </div>
                                        <div class="modal fade" id="editImage{{ $image->id }}" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Rasmni
                                                            tahrirlash</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form
                                                            action="{{ route('image.update.company', ['company' => $company->id, 'image' => $image->id]) }}"
                                                            method="POST" class="row g-3" enctype="multipart/form-data">
                                                            @method('PUT')
                                                            @csrf
                                                            <div class="mb-3 col-12">
                                                                <label class="form-label">Rasm yuklang</label>
                                                                <input type="file" class="form-control" name="image"
                                                                    required>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Bekor qilish</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Yuklash</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal fade" id="deleteImage{{ $image->id }}" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Haqiqatdan ham ushbu rasmni o'chirmoqchimisiz</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Yo'q</button>
                                                        <form
                                                            action="{{ route('image.destroy.company', ['company' => $company->id, 'image' => $image->id]) }}"
                                                            method="POST">
                                                            @method('DELETE')
                                                            @csrf
                                                            <button type="submit" class="btn btn-primary">Ha</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <button class="carousel-control-prev" type="button"
                                    data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button"
                                    data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
