@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Targ'ibotlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Asosiy</a></li>
                    <li class="breadcrumb-item active">Targ'ibotlar</li>
                </ol>
            </nav>
        </div>

        <section class="section">

            @can('create', App\ForeignProject::class)
                <button style="position:relative;right:-98%" class="btn btn--add btn btn-primary mt-3 mb-3 translate-middle-x"
                    type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-plus"></i></button>
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Targ'ibot qo'shish
                                </h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            <form action="{{ route('announcements.store') }}" method="POST" class="row" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3 col-12">
                                    <label class="form-label">Title</label>
                                    <input type="text" class="form-control" name="title" placeholder="Title" required>
                                </div>
                                <div class="mb-3 col-12">
                                    <label class="form-label">Izoh</label>
                                    <textarea class="form-control" name="izoh" placeholder="Izoh" required></textarea>
                                </div>
                                <div class="mb-3 col-6">
                                    <label class="form-label">Turi</label>
                                    <select id="typeSelect" class="form-select" name="type" required>
                                        <option selected disabled value="">Tanlash...</option>
                                        <option value="1">E'lon</option>
                                        <option value="2">Targ'ibot</option>
                                        <option value="3">Video</option>
                                    </select>
                                </div>
                                <div id="fileUploadDiv" class="mb-3 col-6">
                                    <label class="form-label">File yuklash</label>
                                    <input type="file" class="form-control" name="file" placeholder="File yuklash">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yopish</button>
                                    <button class="btn btn-primary">Saqlash</button>
                                </div>
                            </form>

                            <!-- JavaScript -->
                            <script>
                                // Select elementni tanlash
                                const typeSelect = document.getElementById('typeSelect');
                                const fileUploadDiv = document.getElementById('fileUploadDiv');

                                // Funksiya: tanlovga qarab file yuklash inputini yashirish/ko'rsatish
                                typeSelect.addEventListener('change', function () {
                                    if (typeSelect.value === '1') {
                                        // "E'lon" tanlangan bo'lsa, file yuklash inputi yashiriladi
                                        fileUploadDiv.style.display = 'none';
                                    } else {
                                        // Boshqa tanlov bo'lsa, file yuklash inputi ko'rsatiladi
                                        fileUploadDiv.style.display = 'block';
                                    }
                                });

                                // Dastlabki holatda yashirish
                                if (typeSelect.value === '1') {
                                    fileUploadDiv.style.display = 'none';
                                }
                            </script>

                            </div>
                        </div>
                    </div>
                </div>
            @endcan
            <div class="row row-cols-1 row-cols-md-3 g-4">
                @foreach ($targibots as $targibot)
                    <div class="col">
                        <div class="card h-100">
                            @if ($targibot->type == '1')
                                <img src="{{ asset('assets/img/elon.webp') }}" style="height:350px" class="card-img-top"
                                    alt="Targibotlar">
                            @endif
                            @if ($targibot->type == '2')
                                <img src="targibot/{{ $targibot->file }}" style="height:350px" class="card-img-top"
                                    alt="Targibotlar">
                            @endif
                            @if ($targibot->type == '3')
                                <video controls style="height:350px">
                                    <source src="targibot/{{ $targibot->file }}" type="video/mp4">
                                </video>
                            @endif
                            <div class="card-body">
                                <h5 class="card-title"><a
                                        href="{{ route('announcements.batafsil', ['announcements' => $targibot->id]) }}">{{ $targibot->title }}</a>
                                </h5>
                            </div>
                            @can('create', App\ForeignProject::class)
                                <div class="card-body">
                                    <a data-bs-toggle="modal" class="btn btn-primary"
                                        data-bs-target="#edittargibot{{ $targibot->id }}" href=""><i
                                            class='bx bx-pencil'></i></a>
                                    <a data-bs-toggle="modal" class="btn btn-danger"
                                        data-bs-target="#deletetargibot{{ $targibot->id }}" href="#"><i
                                            class='bx bx-trash'></i>
                                    </a>
                                    <div class="col-12">
                                        <div class="modal fade" id="edittargibot{{ $targibot->id }}" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Postni taxrirlash
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form
                                                            action="{{ route('announcements.update', ['announcements' => $targibot->id]) }}"
                                                            method="POST" class="row" enctype="multipart/form-data">
                                                            @csrf
                                                            <div class="mb-3 col-sm-12 col-12">
                                                                <label class="form-label">Title</label>
                                                                <input type="text" class="form-control" name="title"
                                                                    placeholder="Title" value="{{ $targibot->title }}"
                                                                    required>
                                                            </div>
                                                            <div class="mb-3 col-12">
                                                                <label class="form-label">Izoh</label>
                                                                <textarea class="form-control" name="izoh" placeholder="Izoh" required>{{ $targibot->izoh }}</textarea>
                                                            </div>
                                                            <div class="mb-3 col-sm-12 col-12">
                                                                <label class="form-label">File yuklash</label>
                                                                <input type="file" class="form-control" name="file"
                                                                    placeholder="File yuklash" value="{{ $targibot->file }}">
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Yopish</button>
                                                                <button class="btn btn-primary">Saqlash</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="deletetargibot{{ $targibot->id }}" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                        O'chirish
                                                    </h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Haqiqatdan ham o'chirmoqchimisiz?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Yo'q</button>
                                                    <form
                                                        action="{{ route('announcements.destroy', ['announcements' => $targibot->id]) }}"
                                                        method="POST">
                                                        @method('DELETE')
                                                        @csrf
                                                        <button type="submit" class="btn btn-primary">Ha</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endcan
                        </div>
                    </div>
                @endforeach
            </div>
        </section>

    </main><!-- End #main -->
@endsection
