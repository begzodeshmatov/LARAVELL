@extends('layouts.main')

@section('card-body')
    <h5 class="card-title">Xabar yozish</h5>
    <form action="{{ route('message.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3 col-6">
            <label for="user" class="form-label">Kimga:</label>
            <select class="form-select" name="user" id="user" required>
                <option selected disabled value="">Tanlash...</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="mb-3 col-12">
            <label for="message" class="form-label">Xabar matni</label>
            <textarea class="form-control" name="message" id="message" cols="30" rows="10" placeholder="Xabar matnini kiriting ..." required></textarea>
        </div>
        <button type="submit" class="btn btn-outline-info">Yuborish</button>
    </form>
@endsection

@section('title')
Xabar yozish
@endsection