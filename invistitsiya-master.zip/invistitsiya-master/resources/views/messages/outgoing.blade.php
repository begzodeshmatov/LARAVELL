@extends('layouts.main')

@section('card-body')
    <h5 class="card-title">Yuborilgan xabarlar</h5>
    <p class="text-danger mb-3">Yuborgan habarlaringizni faqatgina yuborganingizdan keyin 10 kun ichida o'zgartira olasiz!
    </p>
    @if ($messages->count() == 0)
        Hali siz hech kimga xabar yubormagansiz
    @else
        @foreach ($messages as $item)
            <div class="row border border-secondary-subtle p-3 mb-3">
                <div class="col-2">
                    <h3 class="h3">Kimga:</h3>
                    <h4 class="h4">Xabar:</h4>
                </div>
                <div class="col-10">
                    <h3 class="h3">{{ $item->receiver->name }}</h3>
                    <div class="border border-info-subtle p-3">
                        <p>
                            {{ $item->message }}
                        </p>
                    </div>
                    <div class="float-right d-flex align-items-center">
                        @can('update', $item)
                            <button type="button" class="btn btn--add btn btn-primary m-2" data-bs-toggle="modal"
                                data-bs-target="#edit{{ $item->id }}"><i class="bi bi-pen"></i></button>
                        @endcan
                        <button type="button" class="btn btn--add btn btn-danger m-2" data-bs-toggle="modal"
                            data-bs-target="#delete{{ $item->id }}"><i class="bi bi-trash"></i></button>
                        <p class="mt-2">{{ $item->updated_at->format('Y.m.d') }}</p>
                    </div>
                </div>
            </div>
            @can(['delete'], $item)
                <div class="modal fade" id="delete{{ $item->id }}" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                    O'chirish
                                </h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Haqiqatdan ham ushbu xabarni o'chirmoqchimisiz</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yo'q</button>
                                <form action="{{ route('message.destroy', ['mailMessage' => $item->id]) }}" method="POST">
                                    @method('DELETE')
                                    @csrf
                                    <button type="submit" class="btn btn-primary">Ha</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endcan
            @can(['update'], $item)
                <div class="modal fade" id="edit{{ $item->id }}" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Xabarni tahrirlash</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="{{ route('message.update', ['mailMessage' => $item->id]) }}" method="POST"
                                    class="row" enctype="multipart/form-data">
                                    @csrf
                                    @method('PUT')
                                    <div class="mb-3 col-12">
                                        <label for="message" class="form-label">Xabar matni</label>
                                        <textarea class="form-control" name="message" id="message" cols="30" rows="10"
                                            placeholder="Xabar matnini kiriting ..." required>{{ $item->message }}</textarea>
                                    </div>
                                    <div class="model-footer">
                                        <button class="btn btn-primary">Saqlash</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endcan
        @endforeach
    @endif
@endsection

@section('title')
    Yuborilgan xabarlar
@endsection
