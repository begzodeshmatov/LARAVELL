@extends('layouts.main')

@section('card-body')
    <h4 class="card-title h4">Kiruvchi xabarlar</h4>
    @if ($messages->count() == 0)
        Hali sizga hech kimga xabar yubormagan
    @else
        @foreach ($messages as $item)
            <div class="row border border-secondary-subtle p-3 mb-3">
                <div class="col-2">
                    <h3 class="h3">Kim:</h3>
                    <h4 class="h4">Xabar:</h4>
                </div>
                <div class="col-10">
                    <h3 class="h3">{{ $item->sender->name }}</h3>
                    <div class="border border-info-subtle p-3">
                        <p>
                            {{ $item->message }}
                        </p>
                    </div>
                    <div class="float-right d-flex align-items-center">
                        @can('delete', $item)
                        <button type="button" class="btn btn--add btn btn-danger m-2" data-bs-toggle="modal"
                            data-bs-target="#delete{{ $item->id }}"><i class="bi bi-trash"></i></button>
                        @endcan
                        <p class="mt-2">{{ $item->updated_at->format('Y.m.d') }}</p>
                    </div>
                </div>
            </div>
            @can(['delete'], $item)
                <div class="modal fade" id="delete{{ $item->id }}" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                    O'chirish
                                </h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Haqiqatdan ham ushbu xabarni o'chirmoqchimisiz</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Yo'q</button>
                                <form action="{{ route('message.destroy', ['mailMessage' => $item->id]) }}" method="POST">
                                    @method('DELETE')
                                    @csrf
                                    <button type="submit" class="btn btn-primary">Ha</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endcan
        @endforeach
    @endif
@endsection

@section('title')
    Kiruvchi xabarlar
@endsection
