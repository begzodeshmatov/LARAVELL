@extends('layouts.app')

@section('css')
    <script src="https://cdn.tailwindcss.com"></script>
@endsection

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Savat</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('project.index') }}">Loyihalar</a></li>
                    <li class="breadcrumb-item active">O'chirlgan loyihalar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">O'chirilgan hududiy loyihalar</h5>
                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center"">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col" style="min-width: 250px">Loyiha tashabbuskori</th>
                                            <th scope="col" style="min-width: 250px">Loyiha nomi</th>
                                            <th scope="col" style="min-width: 250px">STIR & JSHSHIR</th>
                                            <th scope="col" style="min-width: 150px">Tuman</th>
                                            <th scope="col" style="min-width: 150px">Sektor</th>
                                            <th scope="col" style="min-width: 150px">Mahalla</th>
                                            <th scope="col" style="min-width: 150px">Soha</th>
                                            <th scope="col" style="min-width: 150px">Tarmoq</th>
                                            <th scope="col" style="min-width: 250px">Xizmat ko'rsativchi bank</th>
                                            <th scope="col">Bank krediti</th>
                                            <th scope="col">Amalda bajarildi</th>
                                            <th scope="col">O'z mablag'i hisobidan</th>
                                            <th scope="col">Xorijiy investitsiya</th>
                                            <th scope="col">Loyiha qiymati</th>
                                            <th scope="col">Maydoni</th>
                                            <th scope="col">Loyiha quvvati</th>
                                            <th scope="col">Yaratilgan ish o'rni</th>
                                            <th scope="col">Amalda</th>
                                            <th scope="col">Sana</th>
                                            <th scope="col">Holati</th>
                                            <th scope="col">O'chirildi</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($projects as $project)
                                            <tr>
                                                <th scope="row">{{ $project->id }}</th>
                                                <td>{{ $project->name }}</td>
                                                <td>{{ $project->goal }}</td>
                                                <td><span
                                                        class="text-uppercase">{{ $project->confirmation['type'] }}:</span>{{ $project->confirmation['confirm_number'] }}
                                                </td>
                                                <td>{{ $project->district->name }}</td>
                                                <td>{{ $project->neighborhood->sector->name }}</td>
                                                <td>{{ $project->neighborhood->name }}</td>
                                                <td>{{ $project->field->name }}</td>
                                                <td>{{ $project->network->name }}</td>
                                                <td>{{ $project->bank }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->credit }}">{{ $project->credit }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->actually_done }}">{{ $project->actually_done }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->own_price }}">{{ $project->own_price }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->foreign }}"{{ $project->foreign }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->value }}">{{ $project->value }}</td>
                                                <td>{{ $project->area }} ga</td>
                                                <td><span id="irregularPrice" data-price="{{ $project->power }}"></span> {{ $project->unity->name ?? '0' }}</td>
                                                <td>{{ $project->number_of_vacancies }}</td>
                                                <td>{{ $project->available_vacancies }}</td>
                                                <td>{{ $project->date }}</td>
                                                <td>{{ $project->status->name }}</td>
                                                <td style="color: red;">{{ $project->deleted_at->format('Y.m.d') }}</td>
                                                <td>
                                                    <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                        data-bs-target="#deleteProject{{ $project->id }}"
                                                        href="#"><i class="bx bx-trash"></i></a>
                                                    <a class="btn btn-success m-1"
                                                        href="{{ route('bucket.restore', ['id' => $project->id]) }}"><i
                                                            class="bi bi-arrow-counterclockwise"></i></a>
                                            </tr>
                                            <div class="modal fade" id="deleteProject{{ $project->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish
                                                            </h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Haqiqatdan ham ushbu loyihani o'chirmoqchimisiz</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Yo'q</button>
                                                            <form
                                                                action="{{ route('bucket.destroy', ['id' => $project->id]) }}"
                                                                method="POST">
                                                                @method('DELETE')
                                                                @csrf
                                                                <button type="submit" class="btn btn-primary">Ha</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            {{ $projects->links() }}
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">O'chirilgan xorijiy loyihalar</h5>
                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center"">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col" style="min-width: 250px">Loyiha tashabbuskori</th>
                                            <th scope="col" style="min-width: 250px">Loyiha nomi</th>
                                            <th scope="col" style="min-width: 250px">O'rganish natijasi bo'yicha xulosa
                                            </th>
                                            <th scope="col" style="min-width: 250px">Manzili</th>
                                            <th scope="col" style="min-width: 250px">STIR & JSHSHIR</th>
                                            <th scope="col" style="min-width: 250px">Loyiha rahbari</th>
                                            <th scope="col" style="min-width: 150px">Tuman</th>
                                            <th scope="col" style="min-width: 250px">Soha</th>
                                            <th scope="col" style="min-width: 250px">Xizmat ko'rsativchi bank</th>
                                            <th scope="col">Bank krediti</th>
                                            <th scope="col">Amalda bajarildi</th>
                                            <th scope="col">O'z mablag'i hisobidan</th>
                                            <th scope="col">Xorijiy investitsiya</th>
                                            <th scope="col">Loyiha qiymati</th>
                                            <th scope="col" style="min-width: 250px">Maydoni</th>
                                            <th scope="col">Loyiha quvvati</th>
                                            <th scope="col">Yaratilgan ish o'rni</th>
                                            <th scope="col">Amalda</th>
                                            <th scope="col">Muammolar soni</th>
                                            <th scope="col" style="min-width: 120px">Sana</th>
                                            <th scope="col">Holati</th>
                                            <th scope="col">O'chirildi</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($foreignProjects as $foreignProject)
                                            <tr>
                                                <th scope="row">{{ $foreignProject->id }}</th>
                                                <td>{{ $foreignProject->name }}</td>
                                                <td>{{ $foreignProject->goal }}</td>
                                                <td><p class="max-w-96 max-h-32 overflow-auto text-wrap">{{ $foreignProject->conclusion }}</p></td>
                                                <td>{{ $foreignProject->address }}</td>
                                                <td><span
                                                        class="text-uppercase">{{ $project->confirmation['type'] }}:</span>{{ $project->confirmation['confirm_number'] }}
                                                </td>
                                                <td>{{ $foreignProject->leader }}</td>
                                                <td>{{ $foreignProject->district->name }}</td>
                                                <td>{{ $foreignProject->field->name }}</td>
                                                <td>{{ $foreignProject->bank }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->credit }}">{{ $foreignProject->credit }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->actually_done }}">{{ $project->actually_done }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->own_price }}">{{ $project->own_price }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->foreign }}">{{ $foreignProject->foreign }}</td>
                                                <td id="irregularPrice" data-price="{{ $project->value }}">{{ $foreignProject->value }}</td>
                                                <td><p class="max-w-96 max-h-32 overflow-auto text-wrap">{{ $foreignProject->area }}ga</td>
                                                <td><span id="irregularPrice" data-price="{{ $project->power }}"></span> {{ $foreignProject->unity->name ?? '0' }}</td>
                                                <td>{{ $foreignProject->number_of_vacancies }}</td>
                                                <td>{{ $foreignProject->available_vacancies }}</td>
                                                <td>{{ $foreignProject->problems()->count() }}</td>
                                                <td>{{ $foreignProject->date }}</td>
                                                <td>{{ $foreignProject->status->name }}</td>
                                                <td style="color: red;">{{ $foreignProject->deleted_at->format('Y.m.d') }}</td>
                                                <td>
                                                    <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                        data-bs-target="#deleteProject{{ $foreignProject->id }}"
                                                        href="#"><i class="bx bx-trash"></i></a>
                                                    <a class="btn btn-success m-1"
                                                        href="{{ route('bucket.restore.foreign', ['id' => $foreignProject->id]) }}"><i
                                                            class="bi bi-arrow-counterclockwise"></i></a>
                                            </tr>
                                            <div class="modal fade" id="deleteProject{{ $foreignProject->id }}" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">O'chirish
                                                            </h1>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Haqiqatdan ham ushbu loyihani o'chirmoqchimisiz</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Yo'q</button>
                                                            <form
                                                                action="{{ route('bucket.destroy.foreign', ['id' => $foreignProject->id]) }}"
                                                                method="POST">
                                                                @method('DELETE')
                                                                @csrf
                                                                <button type="submit" class="btn btn-primary">Ha</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            {{ $projects->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
