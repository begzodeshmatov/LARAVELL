<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biznes-himoya.uz</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="{{ asset('assets/img/logo-image-of-login.png') }}" rel="icon">
    <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="*:box-border *:p-0 *:m-0 select-none bg-no-repeat bg-cover bg-center backdrop-blur"
    style="background-image: url({{ asset('assets/img/col-image.jpg') }})">
    <div class="flex justify-center h-screen items-center">
        <div class="block">
            <div class="mb-20">
                <h1 class="text-center text-balance text-white text-2xl md:text-4xl font-semibold uppercase">shaxsiy
                    kabinetga kirish uchun
                    <br>
                    loyihalar
                    turini tanlang
                </h1>
            </div>
            <div class="flex justify-center my-8">

                <div
                    class="mx-2 bg-white border-2 border-gray-300 shadow-black border-blur-sm rounded text-white text-lg font-medium hover:border-gray-400">
                    <div class="my-8 mx-12 md:my-12 md:mx-14">
                        <img src="{{ asset('assets/img/local-image.jpg') }}" class="w-[150px] md:w-[200px]"
                            alt="">
                    </div>
                    <div class="flex w-[85%] mx-auto my-4 text-center">
                        <a class="w-[100%] py-1 rounded-lg border-2 border-amber-500 bg-amber-500 hover:border-gray-500"
                            href="{{ route('local') }}">Hududiy</a>
                    </div>
                </div>
                <div
                    class="mx-2 bg-white border-2 border-gray-300 shadow-black border-blur-sm rounded text-white text-lg font-medium hover:border-gray-400">
                    <div class="my-8 mx-12 md:my-12 md:mx-14">
                        <img src="{{ asset('assets/img/foreign-image.jpg') }}" class="w-[150px] md:w-[200px]"
                            alt="">
                    </div>
                    <div class="flex w-[85%] mx-auto my-4 text-center">
                        <a class="w-[100%] py-1 rounded-lg border-2 border-green-500 bg-green-500 hover:border-gray-500"
                            href="{{ route('foreign') }}">Xorijiy</a>
                    </div>
                </div>
                <div
                    class="mx-2 bg-white border-2 border-gray-300 shadow-black border-blur-sm rounded text-white text-lg font-medium hover:border-gray-400">
                    <div class="my-8 mx-12 md:my-12 md:mx-14">
                        <img src="{{ asset('assets/img/export1.jpg') }}" class="w-[150px] md:w-[200px]"
                            alt="">
                    </div>
                    <div class="flex w-[85%] mx-auto my-4 text-center">
                        <a class="w-[100%] py-1 rounded-lg border-2 border-blue-500 bg-blue-500 hover:border-gray-500"
                            href="{{ route('export.statistic') }}">Export</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
