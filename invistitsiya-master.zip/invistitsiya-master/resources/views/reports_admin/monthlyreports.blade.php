@extends('layouts.app')
@php
    $months = [
        '1' => 'Yanvar',
        '2' => 'Fevral',
        '3' => 'Mart',
        '4' => 'Aprel',
        '5' => 'May',
        '6' => 'Iyun',
        '7' => 'Iyul',
        '8' => 'Avgust',
        '9' => 'Sentabr',
        '10' => 'Oktabr',
        '11' => 'Noyabr',
        '12' => 'Dekabr',
    ];
@endphp
@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>{{ $companyreport->company->name }} ga qo'yilgan oylik talablar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">{{ $companyreport->company->name }} ga qo'yilgan oylik talablar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">{{ $companyreport->company->name }} ga qo'yilgan oylik talablar</h5>
                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col">Oy</th>
                                            <th scope="col">Yil</th>
                                            <th scope="col">Pragnoz</th>
                                            <th scope="col">Amalda</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($companyreport->monthlyReports as $item)
                                            <tr>
                                                <th scope="row">{{ $item->month }}</th>
                                                <td>{{ $months[$item->month] }}</td>
                                                <td>{{ $companyreport->year }}</td>
                                                <td>{{ $item->pragnoz }}</td>
                                                <td>{{ $item->in_practice }}</td>
                                                <td>
                                                    <a data-bs-toggle="modal" class="btn btn-primary"
                                                        data-bs-target="#editMonthReport{{ $item->id }}"
                                                        href=""><i class='bx bx-pencil'></i></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @foreach ($companyreport->monthlyReports as $item)
                                <div class="modal fade" id="editMonthReport{{ $item->id }}" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                    Tahririlash
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form
                                                    action="{{ route('report.update.monthly', ['monthlyreport' => $item->id]) }}"
                                                    method="POST" class="row">
                                                    @method('PUT')
                                                    @csrf
                                                    <div class="mb-3 col-9">
                                                        <label class="form-label">Oylik talab</label>
                                                        <input type="text" class="form-control" name="pragnoz"
                                                            placeholder="Oylik talab" value="{{ $item->pragnoz }}"
                                                            required>
                                                    </div>
                                                    <div class="mb-3 col-9">
                                                        <label class="form-label">Amalda</label>
                                                        <input type="text" class="form-control" name="in_practice"
                                                            placeholder="Amalda" value="{{ $item->in_practice }}"
                                                            required>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Bekor qilish</button>
                                                        <button type="submit" class="btn btn-primary">Ha</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
