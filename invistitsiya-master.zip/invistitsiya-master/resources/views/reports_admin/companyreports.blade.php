@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Korxonolarga qo'yilgan yillik talablar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">Korxonolarga qo'yilgan yillik talablar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Korxonolarga qo'yilgan yillik talablar</h5>
                            <button
                                class="btn btn--add btn btn-primary  position-absolute top-0 end-0 mt-3  translate-middle-x"
                                type="button" data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                    class="bi bi-plus"></i></button>
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Korxonaga yillik talab
                                                kiritish
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="{{ route('report.store') }}" method="POST" class="row"
                                                enctype="multipart/form-data">
                                                @csrf
                                                <div class="mb-3 col-3">
                                                    <label class="form-label">Tuman</label>
                                                    <select class="form-select" id="district">
                                                        <option selected disabled value="">Tanlash...</option>
                                                        @foreach ($districts as $district)
                                                            <option value="{{ $district->id }}">{{ $district->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-3">
                                                    <label class="form-label">Sektor</label>
                                                    <select class="form-select" id="sector">
                                                        <option selected disabled value="">Tanlash...</option>
                                                        @foreach ($sectors as $sector)
                                                            <option value="{{ $sector->id }}">{{ $sector->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-6">
                                                    <label class="form-label">Korxona</label>
                                                    <select class="form-select" name="company" id="company">
                                                        <option selected disabled value="">Tanlash...</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-3">
                                                    <label class="form-label">Yil</label>
                                                    <select class="form-select" name="year" id="year">
                                                        <option selected disabled value="">Tanlash...</option>
                                                        @foreach ($years as $year)
                                                            <option value="{{ $year }}">{{ $year }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="mb-3 col-9">
                                                    <label class="form-label">Yillik talab</label>
                                                    <input type="text" class="form-control" name="total_price"
                                                        placeholder="Yillik talab" required>
                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-primary">Qo'shish</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <script>
                                        var url = "{{ url('/') }}";
                                    </script>
                                    <script src="{{ asset('js/companies.js') }}"></script>
                                </div>
                            </div>
                            <div class="table-responsive m-b-40">
                                <table class="table table-bordered table-striped table-hover text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">№</th>
                                            <th scope="col">Tashkilot nomi</th>
                                            <th scope="col">Sektor</th>
                                            <th scope="col">Tuman</th>
                                            <th scope="col">Yil</th>
                                            <th scope="col">Pragnoz</th>
                                            <th scope="col">Amalda</th>
                                            <th scope="col">Foizda</th>
                                            <th scope="col">Farqi</th>
                                            <th scope="col">Amallar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                            $countItem = 1;
                                        @endphp
                                        @foreach ($companyReports as $item)
                                            @php
                                                $months = $item->monthlyReports;
                                                $totalPrice = app(App\Services\ReportCalculator::class,)->totalPrice($months);
                                            @endphp
                                            <tr>
                                                <th scope="row">{{ $countItem++ }}</th>
                                                <td><a
                                                        href="{{ route('report.edit', ['companyreport' => $item->id]) }}">{{ $item->company->name }}</a>
                                                </td>
                                                <td>{{ $item->company->sector->name }}</td>
                                                <td>{{ $item->company->district->name }}</td>
                                                <td>{{ $item->year }}</td>
                                                <td>{{ $item->total_price }}</td>
                                                <td>{{ $totalPrice }}</td>
                                                <td>{{ ($item->total_price > 0) ? round($totalPrice * 100 / $item->total_price) : 0 }}%</td>
                                                <td>{{ $totalPrice - $item->total_price }}</td>
                                                <td>
                                                    <a data-bs-toggle="modal" class="btn btn-primary"
                                                        data-bs-target="#editCompanyReport{{ $item->id }}"
                                                        href=""><i class='bx bx-pencil'></i></a>
                                                    <a data-bs-toggle="modal" class="btn btn-danger"
                                                        data-bs-target="#deleteCompanyReport{{ $item->id }}"
                                                        href="#"><i class='bx bx-trash'></i></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @foreach ($companyReports as $item)
                                <div class="modal fade" id="editCompanyReport{{ $item->id }}" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                    Tahririlash
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form
                                                    action="{{ route('report.update', ['companyreport' => $item->id]) }}"
                                                    method="POST" class="row">
                                                    @method('PUT')
                                                    @csrf
                                                    <div class="mb-3 col-9">
                                                        <label class="form-label">Yillik talab</label>
                                                        <input type="text" class="form-control" name="total_price"
                                                            placeholder="Yillik talab" value="{{ $item->total_price }}"
                                                            required>
                                                    </div>
                                                    <div class="mb-3 col-3">
                                                        <label class="form-label">Yil</label>
                                                        <select class="form-select" name="year" id="year">
                                                            <option selected disabled value="">Tanlash...</option>
                                                            @foreach ($years as $year)
                                                                <option value="{{ $year }}"
                                                                    {{ $item->year == $year ? 'selected' : '' }}>
                                                                    {{ $year }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Bekor qilish</button>
                                                        <button type="submit" class="btn btn-primary">Ha</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="deleteCompanyReport{{ $item->id }}" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                    O'chirish
                                                </h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Haqiqatdan ham buni o'chirmoqchimisiz</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Yo'q</button>
                                                <form
                                                    action="{{ route('report.destroy', ['companyreport' => $item->id]) }}"
                                                    method="POST">
                                                    @method('DELETE')
                                                    @csrf
                                                    <button type="submit" class="btn btn-primary">Ha</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
