@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Korxonalar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item active">Korxonalar</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <section class="section">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 my-2">
                                    <div class="d-flex justify-content-between">
                                        <h5 class="card-title fs-2">Korxonalar</h5>
                                        <div class="d-flex justify-content-end align-items-center">
                                            @can('create', App\Company::class)
                                                <button class="btn btn--add btn btn-primary mx-2" type="button"
                                                    data-bs-toggle="modal" data-bs-target="#exampleModal"><i
                                                        class="bi bi-plus"></i></button>
                                            @endcan
                                        </div>
                                    </div>
                                </div>
                                @can('create', App\Company::class)
                                    <div class="col-12">
                                        <div class="modal fade" id="exampleModal" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Korxona qo'shish
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="{{ route('company.store') }}" method="POST"
                                                            class="row" enctype="multipart/form-data">
                                                            @csrf
                                                            <div class="mb-3 col-sm-4 col-12">
                                                                <label class="form-label">Tuman</label>
                                                                <select class="form-select" name="district" id="district" required>
                                                                    <option selected disabled value="">Tanlash...</option>
                                                                    @foreach ($districts as $district)
                                                                        <option value="{{ $district->id }}">
                                                                            {{ $district->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-4 col-12">
                                                                <label class="form-label">Sektor</label>
                                                                <select class="form-select" name="sector" id="sector" required>
                                                                    <option selected disabled value="">Tanlash...
                                                                    </option>
                                                                    @foreach ($sectors as $sector)
                                                                        <option value="{{ $sector->id }}">{{ $sector->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-4 col-12">
                                                                <label class="form-label">Turi</label>
                                                                <select class="form-select" name="type"
                                                                    id="type" required>
                                                                    <option selected disabled value="">Tanlash...</option>
                                                                    <option value="Sanoat mahsulotlari">Sanoat mahsulotlari</option>
                                                                    <option value="Meva-sabzavot mahsulotlari">Meva-sabzavot mahsulotlari</option>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3 col-sm-12 col-12">
                                                                <label class="form-label">Korxona nomi</label>
                                                                <input type="text" class="form-control" name="name"
                                                                    placeholder="Korxona nomi" required>
                                                            </div>
                                                            <button class="btn btn-primary">Qo'shish</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endcan
                                <div class="col-12 my-2">
                                    <form action="{{ route('company.index') }}" method="GET">
                                        <div class="row">
                                            <div class="col-2">
                                                <select name="district" id="districtFilter" class="form-control p-2">
                                                    <option value="">Tuman</option>
                                                    @foreach ($districts as $district)
                                                        <option value="{{ $district->id }}" {{ request('district') == $district->id ? 'selected' : '' }}>{{ $district->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <select name="sector" id="sectorFilter" class="form-control p-2">
                                                    <option value="">Sector</option>
                                                    @foreach ($sectors as $sector)
                                                        <option value="{{ $sector->id }}" {{ request('sector') == $sector->id ? 'selected' : '' }}>{{ $sector->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <select name="type" id="type" class="form-control p-2">
                                                    <option value="">Turi</option>
                                                    <option value="Sanoat mahsulotlari" {{ request('type') == 'Sanoat mahsulotlari' ? 'selected' : '' }}>Sanoat mahsulotlari</option>
                                                    <option value="Meva-sabzavot mahsulotlari" {{ request('type') == 'Meva-sabzavot mahsulotlari' ? 'selected' : '' }}>Meva-sabzavot mahsulotlari</option>
                                                </select>
                                            </div>
                                            <div class="col-2">
                                                <input type="text" name="name"
                                                    placeholder="Korxona nomi" value="{{ request('name') }}" class="form-control p-2">
                                            </div>
                                            <div class="col-1">
                                                <button type="submit" class="btn btn-primary">Topish</button>
                                            </div>
                                            <div class="col-1">
                                                <a href="{{ route('company.index') }}"
                                                    class="btn btn-success">Hammasi</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-12 my-2">
                                    <div class="table-responsive mb-40">
                                        <table class="table table-bordered table-striped table-hover text-center"">
                                            <thead>
                                                <tr>
                                                    <th scope="col">№</th>
                                                    <th scope="col" style="min-width: 250px">Korxona nomi</th>
                                                    <th scope="col" style="min-width: 150px">Tuman</th>
                                                    <th scope="col" style="min-width: 150px">Sektor</th>
                                                    <th scope="col" style="min-width: 150px">Turi</th>
                                                    @canany(['update', 'delete'], $companies[0])
                                                        <th scope="col">Amallar</th>
                                                    @endcanany
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @php
                                                    $countItem = 1;
                                                @endphp
                                                @foreach ($companies as $company)
                                                    <tr>
                                                        <th scope="row">{{ $countItem++ }}</th>
                                                        <td>{{ $company->name }}</td>
                                                        <td>{{ $company->district->name }}</td>
                                                        <td>{{ $company->sector->name }}</td>
                                                        <td>{{ $company->type }}</td>
                                                        @canany(['update', 'delete'], $company)
                                                            <td>
                                                                <a class="btn btn-primary m-1"
                                                                    href="{{ route('company.edit', ['company' => $company->id]) }}"><i
                                                                        class="bx bx-pencil"></i></a>
                                                                <a data-bs-toggle="modal" class="btn btn-danger m-1"
                                                                    data-bs-target="#delete{{ $company->id }}"
                                                                    href="#"><i class='bx bx-trash'></i></a>
                                                            @endcanany
                                                    </tr>
                                                    @canany(['update', 'delete'], $company)
                                                        <div class="modal fade" id="delete{{ $company->id }}"
                                                            tabindex="-1" aria-labelledby="exampleModalLabel"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                            O'chirish
                                                                        </h1>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p>Haqiqatdan ham ushbu korxonani o'chirmoqchimisiz ?</p>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Yo'q</button>
                                                                        <form
                                                                            action="{{ route('company.destroy', ['company' => $company->id]) }}"
                                                                            method="POST">
                                                                            @method('DELETE')
                                                                            @csrf
                                                                            <button type="submit"
                                                                                class="btn btn-primary">Ha</button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endcanany
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="my-2">
                                        {{ $companies->appends(request()->query())->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
