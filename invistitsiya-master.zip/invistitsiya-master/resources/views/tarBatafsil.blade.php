@extends('layouts.app')

@section('content')

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Targ'ibotlar</h1>
        <nav>
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/announcements">Asosiy</a></li>
            <li class="breadcrumb-item active">Targ'ibotlar</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->


    <section class="section">
        <div class="row">
          <div class="card">
            <div class="row g-0">
              <div class="col-md-4">
                @if($tarBatafsil->type == '1')
                    <img src="{{ asset('assets/img/elon.webp') }}" style="height:350px" class="card-img-top" alt="Targibotlar">
                @endif
                @if($tarBatafsil->type == '2')
                    <img src="/targibot/{{ $tarBatafsil->file }}" style="height:350px" class="card-img-top" alt="Targibotlar">
                @endif
                @if ($tarBatafsil->type == '3')
                    <video controls style="height:350px">
                        <source src="/targibot/{{ $tarBatafsil->file }}" type="video/mp4">
                    </video>
                @endif
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title">{{$tarBatafsil->title}}</h5>
                  <p class="card-text">{{$tarBatafsil->izoh}}</p>
                </div>
              </div>
            </div>
          </div><!-- End Card with an image on left -->
        </div>
    </section>

</main><!-- End #main -->

@endsection
