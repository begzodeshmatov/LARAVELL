@extends('layouts.app')

@section('css')
    <style>
        .qizil {
            animation: chiq 5s linear infinite;
        }

        .sariq {
            animation: sariq 5s linear infinite;
            animation-delay: 5s;
        }

        .yashil {
            animation: yashil 5s linear infinite;
            animation-delay: 5s;
        }

        @keyframes yashil {
            100% {
                background: green;
            }
        }

        @keyframes chiq {
            100% {
                background: red;
            }
        }

        @keyframes sariq {
            100% {
                background: yellow;
            }
        }
    </style>
@endsection

@section('content')
    <main id="main" class="main">
        <img src="{{ asset('assets/img/logo-image-of-login.png') }}" alt="" id="orqafon_rasm">
        <div class="pagetitle">
            <h1>Loyihalar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('local') }}">Asosiy</a></li>
                    <li class="breadcrumb-item">Xorijiy loyihalar</li>
                    <li class="breadcrumb-item active">{{ $district->name }}
                        {{ $district->name == 'Jizzax' ? 'shahrida' : 'tumanida' }}</li>
                </ol>
            </nav>
        </div>
        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <h2 class="text-center mb-4 text-dark font-weight-bold bg-light text-uppercase fs-3">
                            {{ $district->name }}
                            {{ $district->name == 'Jizzax' ? 'shaxrida' : 'tumanida' }}
                            O'ZLAShTIRILADIGAN TO'G'RIDAN-TO'G'RI <span class="text-primary">XORIJIY INVESTITsIYaLAR VA
                                XORIJIY KREDITLAR</span> </h2>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card sales-card">
                                <a href="{{ route('project.district', ['district' => $district->id, 'type' => 'count']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Loyihalar soni</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="ri-slideshow-line"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;" class="text-danger">{{ $projectsCount }}
                                                    <span class="text-dark" style="font-size:20px">ta</span>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card revenue-card">
                                <a href="{{ route('project.district', ['district' => $district->id, 'type' => 'price']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Umumiy qiymati</h5>

                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bx bx-coin-stack"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger" id="irregularPrice"
                                                        data-price="{{ $totalPrice }}">{{ $totalPrice }}</span> mln.
                                                    so'm
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'foreign']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Xorijiy investitsiya</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-currency-dollar"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 class="text-dark" style="font-size:20px;">
                                                    <span style="font-size: 1.5rem;" class="text-danger" id="irregularPrice"
                                                        data-price="{{ $totalForeign }}">{{ $totalForeign }}</span> mln.
                                                    dollar
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'number_of_vacancies']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Yaratilgan ish o'rni</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger">{{ $numberOfVacancies }}
                                                    <span class="text-dark" style="font-size:20px;"> nafar</span>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'hopeless']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Istiqbolsiz loyihalar</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger">
                                                    {{ $hopelessProjectsCount }}
                                                    <span class="text-dark" style="font-size:20px;"> ta</span>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'overdue']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Muddati buzib bajarilgan</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger">
                                                    {{ $overdueProjectsCount }}
                                                    <span class="text-dark" style="font-size:20px;"> ta</span>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'nearDeadline']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Muddati uzaytirilgan loyiha</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger">
                                                    {{ $extendedProjectsCount }} <span class="text-dark"
                                                        style="font-size:20px;"> ta</span></h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card qizil customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'expired']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Muddati o'tgan loyiha</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger dd">
                                                    {{ $expiredProjectsCount }} <span class="text-dark"
                                                        style="font-size:20px;"> ta</span></h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card sariq customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'nearDeadline']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Muddati yaqinlashgan loyiha</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger">
                                                    {{ $nearDeadlineProjectsCount }} <span class="text-dark"
                                                        style="font-size:20px;"> ta</span></h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-12">
                            <div class="card info-card yashil customers-card">
                                <a
                                    href="{{ route('project.district', ['district' => $district->id, 'type' => 'launched']) }}">
                                    <div class="card-body">
                                        <h5 class="card-title">Ishga tushirilgan loyiha</h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-people"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6 style="font-size: 1.5rem;"class="text-danger">
                                                    {{ $launchedProjectsCount }}
                                                    <span class="text-dark" style="font-size:20px;"> ta</span>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xxl-8 col-md-6">
                    <div class="row">
                        @foreach ($fields as $field)
                            <div class="col-xxl-6 col-12">
                                <div class="col-12 mt-0">
                                    <div class="card info-card  bg-primary"
                                        style="clip-path: polygon(0 0, 100% 0, 89% 100%, 12% 100%);">
                                        <div class="card-body-sm">
                                            <h5 class="card-title text-light text-center mt-2"> <span
                                                    class="text-warning fs-5">{{ $field->name }}</span></h5>
                                        </div>
                                    </div>
                                </div>

                                <div class="card p-3">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-12 mb-0">
                                                    <div class="card info-card mb-0 bg-success pb-0">
                                                        <h3 class="card-title text-center mb-0 pt-1 pb-1 text-light fs-5">
                                                            Jami
                                                        </h3>
                                                    </div>
                                                </div>
                                                <div class="col-3 mt-0 d-flex  justify-content-center">
                                                    <div
                                                        class="card-icon rounded-circle d-flex align-items-center text-center justify-content-center">
                                                        <i class="ri-slideshow-line" style="color:green;"></i>
                                                    </div>
                                                </div>
                                                <div class="col-3 mt-0 d-flex justify-content-center">
                                                    <div
                                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                        <i class="bi bi-currency-dollar" style="color:green;"></i>
                                                    </div>
                                                </div>
                                                <div class="col-3 mt-0 d-flex justify-content-center">
                                                    <div
                                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                        <i class='bx bx-coin-stack' style="color:green;"></i>
                                                    </div>
                                                </div>
                                                <div class="col-3 mt-0 d-flex justify-content-center">
                                                    <div
                                                        class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                        <i class='bi bi-people' style="color:green;"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        @php
                                            $projects = $field
                                                ->foreignProjects()
                                                ->where('district_id', $district->id)
                                                ->get();
                                            $projectsCount = app(App\Services\ProjectValueCalculator::class)->calculate(
                                                $projects,
                                                'count',
                                            );
                                            $totalPrice = app(App\Services\ProjectValueCalculator::class)->calculate(
                                                $projects,
                                                'price',
                                            );
                                            $totalVacancies = app(
                                                App\Services\ProjectValueCalculator::class,
                                            )->calculate($projects, 'number_of_vacancies');
                                            $totalCredit = app(App\Services\ProjectValueCalculator::class)->calculate(
                                                $projects,
                                                'credit',
                                            );
                                            $totalForeign = app(App\Services\ProjectValueCalculator::class)->calculate(
                                                $projects,
                                                'foreign',
                                            );
                                        @endphp
                                        <div class="col-3  px-1">
                                            <div class="card h-75 info-card d-flex flex-column">
                                                <div class="flex-grow-1">
                                                    <h5 style="font-size:11px;"
                                                        class="card-title text-center align-items-center">
                                                        Loyihalar </h5>
                                                </div>
                                                <div class="card-footer border-0 m-0 p-0 mb-2 text-center">
                                                    <h6 style="font-size: 18px;"
                                                        class="text-center text-danger align-items-center">
                                                        {{ $projectsCount }} </h6><span class="text-dark"
                                                        style="font-size:12px;">ta</span>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-3  px-1 ">
                                            <div class="card h-75 info-card text-center">
                                                <div class="flex-grow-1">
                                                    <h5 style="font-size:11px;"
                                                        class="card-title text-center align-items-center">
                                                        Umumiy qiymati</h5>
                                                </div>
                                                <div class=" card-footer m-0 p-0 border-0 mb-2 text-center">
                                                    <h6 style="font-size: 18px;"
                                                        class="text-center text-danger align-items-center"
                                                        id="irregularPrice" data-price="{{ $totalPrice }}">
                                                        {{ $totalPrice }} </h6><span class="text-dark"
                                                        style="font-size:12px;">dollar</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-3  px-1">
                                            <div class="card h-75 info-card d-flex">
                                                <div class="flex-grow-1">
                                                    <h5 style="font-size:11px;"
                                                        class="card-title text-center align-items-center">
                                                        Bank krediti</h5>
                                                </div>
                                                <div class=" card-footer m-0 p-0 border-0 mb-2 text-center">
                                                    <h6 style="font-size: 18px;"
                                                        class="text-center text-danger align-items-center"
                                                        id="irregularPrice" data-price="{{ $totalCredit }}">
                                                        {{ $totalCredit }} </h6><span class="text-dark"
                                                        style="font-size:12px;">dollar</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-3  px-1">
                                            <div class="card h-75 info-card d-flex">
                                                <div class="flex-grow-1">
                                                    <h5 style="font-size:11px;"
                                                        class="card-title text-center align-items-center">
                                                        Ish o'rinlari</h5>
                                                </div>
                                                <div class="card-footer border-0 m-0 p-0 mb-2 text-center">
                                                    <h6 style="font-size: 18px;"
                                                        class="text-center text-danger align-items-center">
                                                        {{ $totalVacancies }} </h6><span class="text-dark"
                                                        style="font-size:12px;">nafar</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="col-xxl-4 col-md-6">
                    <div class="col-12">
                        <div class="card info-card  bg-primary">
                            <div class="card-body-sm">
                                <h5 class="card-title text-light text-center mt-2">{{ $district->name }}
                                    {{ $district->name == 'Jizzax' ? 'shaxri' : 'tumani' }}</h5>
                            </div>
                        </div>
                        <div class="col-12">
                            <img src="{{ $district->image }}" class="img-fluid w-100" alt="Responsive image">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
