<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Biznes-himoya</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <link href="{{ asset('assets/img/logo-image-of-login.png') }}" rel="icon">
    <link href="{{ asset('assets/img/apple-touch-icon.png" rel="apple') }}-touch-icon">

    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <link href="{{ asset('assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendor/quill/quill.snow.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendor/quill/quill.bubble.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendor/remixicon/remixicon.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/vendor/simple-datatables/style.css') }}" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (new link) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js"></script>

    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
    <script src="{{ asset('js/price.js') }}"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        #soat {
            font-size: 20px;
            font-weight: bold;
            color: #157fc4;
            text-align: center;
            padding: 10px;
            background-color: transparent;
            transition: 1s;
            font-family: "Fira Sans";
        }

        #orqafon_rasm {
            width: 40%;
            height: 90%;
            z-index: -5;
            position: absolute;
            filter: blur(3px);
            top: 20%;
            left: 35%;
        }
        .collapse {
                visibility: visible!important;
        }
    </style>
    @yield('link')
    @yield('css')

</head>

<body>

    <header id="header" class="header fixed-top d-flex align-items-center">

        <div class="d-flex align-items-center justify-content-between">
            <a href="{{ route('local') }}" class="logo d-flex align-items-center">
                <img src="{{ asset('assets/img/logo-image-of-login.png') }}" alt="">
                <span class="d-none d-lg-block fs-5 text-nowrap">Biznes-himoya</span>
            </a>
            <i class="bi bi-list toggle-sidebar-btn"></i>
        </div>
        <div class="container">
            <div class="text">
                <?php
                use App\Targibot;
                
                $oxirgiTargibot = Targibot::where('type', '1')->orderBy('created_at', 'desc')->first();
                ?>
                <span class="d-none d-lg-block fs-5 text-nowrap" style="color:#157fc4;font-weight:bold">
                    <marquee>{{ $oxirgiTargibot->title ?? "E'lonlar mavjud emas" }}</marquee>
                </span>
            </div>
        </div>
        <div class="container">
            <div class="text-end" id="soat">

            </div>
        </div>


        <script>
            function Ishla() {
                var vaqt = new Date();

                // Sanani olish
                var kun = vaqt.getDate();
                // kun = (kun < 10 ? "0" : "") + kun;

                // Oyni nomi bilan olish
                var oyIndex = vaqt.getMonth();
                var oylar = ["Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun", "Iyul", "Avgust", "Sentabr", "Oktabr",
                    "Noyabr", "Dekabr"
                ];
                var oyNomi = oylar[oyIndex];

                // Yilni olish
                var yil = vaqt.getFullYear();

                // Haftaning kunini olish
                var haftaKunIndex = vaqt.getDay();
                var haftaKunlar = ["Yakshanba", "Dushanba", "Seshanba", "Chorshanba", "Payshanba", "Juma", "Shanba"];
                var haftaKunNomi = haftaKunlar[haftaKunIndex];

                // Soat, minut va sekundlarni olish
                var soat = vaqt.getHours();
                var minut = vaqt.getMinutes();
                var secund = vaqt.getSeconds();

                soat = (soat < 10 ? "0" : "") + soat;
                minut = (minut < 10 ? "0" : "") + minut;
                secund = (secund < 10 ? "0" : "") + secund;

                // Sana, oy nomi, yil, hafta kuni va soatni chiqarish
                var chiqar = document.getElementById('soat');
                chiqar.innerText = kun + "-" + oyNomi.toUpperCase() + " " + yil + ", " + haftaKunNomi.toUpperCase() + " " +
                    soat + ":" + minut + ":" +
                    secund;
            }
            Ishla();
            setInterval(Ishla, 1000);



        </script>


        <nav class="header-nav ms-auto mr-6">
            <ul class="d-flex align-items-center">
                @php
                    $headerMessages = auth()->user()->receivedMessages()->take(3)->get();
                @endphp
                <li class="nav-item dropdown">
                    <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-chat-left-text"></i>
                        <span class="badge bg-success badge-number">{{ $headerMessages->count() }}</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
                        <li class="dropdown-header">
                            So'ngi {{ $headerMessages->count() }} ta xabar
                            <a class="ml-6" href="{{ route('message.reseived') }}"><span
                                    class="badge rounded-pill bg-primary p-2 ms-2">Hammasi</span></a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        @foreach ($headerMessages as $item)
                            <li class="message-item">
                                <a href="#">
                                    <img src="{{ asset($item->sender->image->name ?? 'assets/img/profile-image.png') }}"
                                        alt="" class="rounded-circle">
                                    <div>
                                        <h4>{{ $item->sender->name }}</h4>
                                        <p style="max-height: 100px" class="text-wrap text-ellipsis overflow-hidden">
                                            {{ $item->message }}</p>
                                        <p>{{ $item->updated_at->format('Y.m.d') }}</p>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                        @endforeach
                        <li class="dropdown-footer">
                            <a href="{{ route('message.reseived') }}">Barcha xabarlarni ko'rish</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown pe-3">
                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#"
                        data-bs-toggle="dropdown">
                        <img src="{{ asset(auth()->user()->image->name ?? 'assets/img/profile-image.png') }}"
                            class="max-w-[45px] min-w-[45px] max-h-[45px] min-h-[45px] rounded-full border-1 border-blue-900 object-cover"
                            alt="Profile">
                        <span class="d-none d-md-block dropdown-toggle ps-2">{{ auth()->user()->name }}</span>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6>{{ auth()->user()->name }}</h6>
                            <p>{{ auth()->user()->position ?? 'Admin' }}</p>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        @can('use-bucket')
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="{{ route('bucket.index') }}">
                                    <i class="bi bi-trash2"></i>
                                    <span>Savat</span>
                                </a>
                            </li>
                        @endcan
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        @if (auth()->user()->role === 'enterprise')
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="{{ route('cabinet.show') }}">
                                    <i class="bi bi-person-circle"></i>
                                    <span>Sozlamalar</span>
                                </a>
                            </li>
                        @else
                            <li>
                                <a class="dropdown-item d-flex align-items-center" href="{{ route('profile.show') }}">
                                    <i class="bi bi-person-circle"></i>
                                    <span>Sozlamalar</span>
                                </a>
                            </li>
                        @endif
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Chiqish</span>
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                style="display: none;">
                                @csrf
                            </form>

                        </li>

                    </ul>
                </li>

            </ul>
        </nav>

    </header>

    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#projects-nav" data-bs-toggle="collapse"
                    href="#">
                    <i class="bi bi-grid"></i>
                    <span>Loyihalar</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="projects-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    @can('show-statistics')
                        <li style="visibility: visible">
                            <a class="nav-link collapsed" href="{{ route('local') }}">
                                <span>Hududiy</span>
                            </a>
                        </li>
                        <li style="visibility: visible">
                            <a class="nav-link collapsed" href="{{ route('foreign') }}">
                                <span>Xorijiy</span>
                            </a>
                        </li>
                    @endcan
                    @can('viewAny', App\Project::class)
                        <li style="visibility: visible">
                            <a class="nav-link collapsed" href="{{ route('project.index') }}">
                                <span>Hududiy loyihalar</span>
                            </a>
                        </li>
                    @endcan
                    @can('viewAny', App\ForeignProject::class)
                        <li style="visibility: visible">
                            <a class="nav-link collapsed" href="{{ route('project.index.foreign') }}">
                                <span>Xorijiy loyihalar</span>
                            </a>
                        </li>
                    @endcan
                </ul>
            </li>
            @can('show-statistics')
                <li class="nav-item">
                    <a class="nav-link collapsed" href="{{ route('export.statistic') }}">
                        <i class="bi bi-grid-3x3-gap"></i><span>Export</span>
                    </a>
                </li>
            @endcan
            @can('viewAny', App\Neighborhood::class)
                <li class="nav-item">
                    <a class="nav-link collapsed" data-bs-target="#components-nav"
                        href="{{ route('neighborhood.index') }}">
                        <i class="bi bi-columns-gap"></i><span>Mahallalar</span>
                    </a>
                </li>
            @endcan
            @can('viewAny', App\Neighborhood::class)
                <li class="nav-item">

                    <a class="nav-link collapsed" data-bs-target="#components-nav" href="{{ route('report.index') }}">
                        <i class="bi bi-view-list"></i><span>Yillik pragnoz</span>
                    </a>
                </li>
            @endcan
            @can('viewAny', App\Company::class)
                <li class="nav-item">
                    <a class="nav-link collapsed" data-bs-target="#components-nav" href="{{ route('company.index') }}">
                        <i class="bi bi-list-columns-reverse"></i><span>Korxonalar</span>
                    </a>
                </li>
            @endcan
            @can('viewAny', App\Targibot::class)
                <li class="nav-item">
                    <a class="nav-link collapsed" data-bs-target="#components-nav"
                        href="{{ route('announcements.index') }}">
                        <i class="bi bi-people"></i><span>Targ'ibotlar</span>
                    </a>
                </li>
            @endcan
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#components-nav" href="{{ route('murojaat.index') }}">
                    <i class="bi bi-people"></i><span>Murojaatlar</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#components-nav" target="_blank"
                    href="{{ route('video') }}">
                    <i class="bi bi-camera-video"></i><span>Video suhbat</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#components-nav" href="{{ route('message.write') }}">
                    <i class="bi bi-chat-dots"></i><span>Xabarlar</span>
                </a>
            </li>
            @can('viewAny', App\User::class)
                <li class="nav-item">
                    <a class="nav-link collapsed" data-bs-target="#components-nav" href="{{ route('user.index') }}">
                        <i class="bi bi-people"></i><span>Foydalanuvchilar</span>
                    </a>
                </li>
            @endcan


            <li class="nav-item">
                <a class="nav-link collapsed"href="{{ route('logout') }}"
                    onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                    <i class="bi bi-box-arrow-in-right"></i>
                    <span>Chiqish</span>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
            </li>
        </ul>

    </aside>
    @yield('content')
    <div class="select-none">
        <style>
            .beaitiful-scroll::-webkit-scrollbar {
                width: 8px;
            }

            .beaitiful-scroll::-webkit-scrollbar-track {
                background: #f1f1f1;
            }

            .beaitiful-scroll::-webkit-scrollbar-thumb {
                background-color: #3b82f6;
                border-radius: 10px;
                border: 2px solid transparent;
            }

            .beaitiful-scroll::-webkit-scrollbar-thumb:hover {
                background-color: #2563eb;
            }

            .beaitiful-scroll {
                scrollbar-width: thin;
                scrollbar-color: #06b6d4 #f1f1f1;
            }

            #chatWindow {
                display: none;
            }
        </style>
        <div id="chatToggle"
            class="fixed bottom-[70px] right-[15px] z-[1000] bg-[#007bff] text-white rounded-full size-[50px] flex items-center justify-center cursor-pointer">
            <i class="bi bi-chat text-3xl"></i>
        </div>
        <div class="fixed border bottom-[140px] right-[60px] z-80 min-w-[330px] max-w-[330px] min-h-[450px] bg-white rounded-md text-cyan-500"
            id="chatWindow">
            <div class="row">
                <div class="col-12 text-center">
                    <h1 id="chatWindowTitle" class="my-2 text-xl font-bold text-wrap text-ellipsis overflow-hidden">
                        Barcha korxonalar</h1>
                </div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-6 flex justify-center items-center"><i id="allmembersButton"
                                class="text-2xl w-full text-center border-b-4 bg-slate-100 text-cyan-600 border-cyan-600 hover:bg-slate-100 hover:text-cyan-600 hover:border-cyan-600 cursor-pointer bi bi-people-fill"></i>
                        </div>
                        <div class="col-6 flex justify-center items-center"><i id="allchatsButton"
                                class="text-2xl w-full text-center border-b-4 hover:bg-slate-100 hover:text-cyan-600 hover:border-cyan-600 cursor-pointer bi bi-chat-text"></i>
                        </div>
                    </div>
                    <hr>
                </div>
                <div class="col-12">
                    <div class="row">
                        <div class="col-12 beaitiful-scroll" id="members">
                            {{-- <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                <div class="col-3">
                                    <img src="{{ asset('assets/img/profile-image.png') }}"
                                        class="size-12 ml-2 rounded-full" alt="">
                                </div>
                                <div class="col-9">
                                    <div class="col-12 flex justify-between items-center">
                                        <h1 class="text-md text-wrap text-ellipsis overflow-hidden">Markaziy bank
                                        </h1>
                                        <p class="text-gray-400 text-xs">24.10.2024</p>
                                    </div>
                                    <div class="col-12">
                                        <p class="text-gray-500 text-md">Bo'lim boshlig'i</p>
                                    </div>
                                </div>
                            </div>
                            <div class="w-full h-[1px] bg-cyan-500"></div>
                            <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                <div class="col-3">
                                    <img src="{{ asset('assets/img/profile-image.png') }}"
                                        class="size-12 ml-2 rounded-full" alt="">
                                </div>
                                <div class="col-9">
                                    <div class="col-12 flex justify-between items-center">
                                        <h1 class="text-md text-wrap text-ellipsis overflow-hidden">Savdo-sanoat
                                            palatasi
                                        </h1>
                                        <p class="text-gray-400 text-xs">24.10.2024</p>
                                    </div>
                                    <div class="col-12">
                                        <p class="text-gray-500 text-md">Bo'lim boshlig'i</p>
                                    </div>
                                </div>
                            </div>
                            <div class="w-full h-[1px] bg-cyan-500"></div>
                            <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                <div class="col-3">
                                    <img src="{{ asset('assets/img/profile-image.png') }}"
                                        class="size-12 ml-2 rounded-full" alt="">
                                </div>
                                <div class="col-9">
                                    <div class="col-12 flex justify-between items-center">
                                        <h1 class="text-md text-wrap text-ellipsis overflow-hidden">Soliq boshqarmasi
                                        </h1>
                                        <p class="text-gray-400 text-xs">24.10.2024</p>
                                    </div>
                                    <div class="col-12">
                                        <p class="text-gray-500 text-md">Mutsaxassis</p>
                                    </div>
                                </div>
                            </div>
                            <div class="w-full h-[1px] bg-cyan-500"></div> --}}
                        </div>
                        <div class="col-12" id="conversations">
                            <div class="row">
                                <div class="col-12 min-h-[320px] max-h-[320px] max-w-[342px] overflow-y-auto beaitiful-scroll"
                                    id="conversationScroll">
                                    {{-- <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                        <div class="col-12">
                                            <div class="col-12 flex justify-between items-center">
                                                <h1 class="text-xl font-bold text-wrap text-ellipsis overflow-hidden">
                                                    Markaziy bank
                                                </h1>
                                            </div>
                                            <div class="col-12">
                                                <p class="text-gray-500 text-md">Yer masalasi bo'yicha</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full h-[1px] bg-cyan-500"></div>
                                    <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                        <div class="col-12">
                                            <div class="col-12 flex justify-between items-center">
                                                <h1 class="text-xl font-bold text-wrap text-ellipsis overflow-hidden">
                                                    Markaziy bank
                                                </h1>
                                            </div>
                                            <div class="col-12">
                                                <p class="text-gray-500 text-md">Yer masalasi bo'yicha</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full h-[1px] bg-cyan-500"></div> --}}
                                </div>
                                <div class="col-12">
                                    <div class="w-full h-[1px] bg-cyan-500"></div>
                                    <div>
                                        <form action="#" method="POST" enctype="multipart/form-data"
                                            id="conversationForm" class="flex items-center">
                                            <input type="text" id="conversationInput"
                                                class="outline-none w-3/4 border-2 py-1 px-2 my-2 mx-1 border-cyan-500 placeholder:text-cyan-500 rounded"
                                                placeholder="Yangi xabarlashuv mavzusi">
                                            <button
                                                class="my-2 mx-2 py-1 px-2 bg-cyan-100 w-1/6 rounded-xl text-xl text-cyan-600"><i
                                                    class="bi bi-send"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 beaitiful-scroll" id="allchats">
                            {{-- <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                <div class="col-12">
                                    <div class="col-12 flex justify-between items-center">
                                        <h1 class="text-xl font-bold text-wrap text-ellipsis overflow-hidden">
                                            Markaziy bank
                                        </h1>
                                    </div>
                                    <div class="col-12">
                                        <p class="text-gray-500 text-md">Yer masalasi bo'yicha</p>
                                    </div>
                                </div>
                            </div>
                            <div class="w-full h-[1px] bg-cyan-500"></div>
                            <div class="col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer">
                                <div class="col-12">
                                    <div class="col-12 flex justify-between items-center">
                                        <h1 class="text-xl font-bold text-wrap text-ellipsis overflow-hidden">
                                            Markaziy bank
                                        </h1>
                                    </div>
                                    <div class="col-12">
                                        <p class="text-gray-500 text-md">Yer masalasi bo'yicha</p>
                                    </div>
                                </div>
                            </div>
                            <div class="w-full h-[1px] bg-cyan-500"></div> --}}
                        </div>
                        <div class="col-12" id="messages">
                            <div class="row">
                                <div class="col-12 min-h-[320px] max-h-[320px] max-w-[342px] overflow-y-auto">
                                    <div class="col-12 flex flex-col mt-2 beaitiful-scroll" id="messageScroll">
                                        {{-- <div class="flex justify-start mb-2">
                                            <div
                                                class="ml-2 py-1 px-2 max-w-[320px] border-2 border-cyan-500 bg-white rounded-br-2xl rounded-tr-2xl rounded-tl-2xl text-sm text-cyan-500">
                                                <p class="text-balance break-words">
                                                    PING
                                                </p>
                                            </div>
                                        </div>
                                        <div class="flex justify-start mb-2">
                                            <div
                                                class="ml-2 py-1 px-2 max-w-[320px] border-2 border-cyan-500 bg-white rounded-br-2xl rounded-tr-2xl rounded-tl-2xl text-sm text-cyan-500">
                                                <p class="text-balance break-words">
                                                    PONG
                                                </p>
                                            </div>
                                        </div> --}}
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="w-full h-[1px] bg-cyan-500"></div>
                                    <div>
                                        <form action="#" method="POST" enctype="multipart/form-data"
                                            id="messageForm" class="flex items-center">
                                            <input type="text" id="messageInput"
                                                class="outline-none w-3/4 border-2 py-1 px-2 my-2 mx-1 border-cyan-500 placeholder:text-cyan-500 rounded"
                                                placeholder="Text ...">
                                            <button type="submit"
                                                class="my-2 mx-2 py-1 px-2 bg-cyan-100 w-1/6 rounded-xl text-xl text-cyan-600"><i
                                                    class="bi bi-send"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            var members = document.getElementById('members');
            var messages = document.getElementById('messages');
            var allchats = document.getElementById('allchats');
            var conversations = document.getElementById('conversations');

            var allmembersButton = document.getElementById('allmembersButton');
            var allchatsButton = document.getElementById('allchatsButton');
            var chatWindowTitle = document.getElementById('chatWindowTitle');

            function membersView() {
                members.style.display = 'block';
                messages.style.display = 'none';
                allchats.style.display = 'none';
                conversations.style.display = 'none';
            }

            function messagesView() {
                members.style.display = 'none';
                messages.style.display = 'block';
                allchats.style.display = 'none';
                conversations.style.display = 'none';
            }

            function allchatsView() {
                members.style.display = 'none';
                messages.style.display = 'none';
                allchats.style.display = 'block';
                conversations.style.display = 'none';
            }

            function conversationsView() {
                members.style.display = 'none';
                messages.style.display = 'none';
                allchats.style.display = 'none';
                conversations.style.display = 'block';
            }

            allmembersButton.addEventListener('click', () => {
                chatWindowTitle.innerText = "Barcha korxonalar";
                if (allmembersButton.classList.contains('border-cyan-600')) {

                } else {
                    allmembersButton.classList.add('border-cyan-600')
                    allmembersButton.classList.add('bg-slate-100')
                    allmembersButton.classList.add('text-cyan-600')
                }
                allchatsButton.classList.remove('border-cyan-600')
                allchatsButton.classList.remove('bg-slate-100')
                allchatsButton.classList.remove('text-cyan-600')
                membersView();
                loadUsers();
            });
            allchatsButton.addEventListener('click', () => {
                chatWindowTitle.innerText = "Barcha chatlar";
                if (allchatsButton.classList.contains('border-cyan-600')) {

                } else {
                    allchatsButton.classList.add('border-cyan-600')
                    allchatsButton.classList.add('bg-slate-100')
                    allchatsButton.classList.add('text-cyan-600')
                }
                allmembersButton.classList.remove('border-cyan-600')
                allmembersButton.classList.remove('bg-slate-100')
                allmembersButton.classList.remove('text-cyan-600')
                allchatsView();
                loadConversations();
            });

            document.getElementById('chatToggle').addEventListener('click', function() {
                var chatWindow = document.getElementById('chatWindow');
                chatWindow.classList.toggle('fade');
                chatWindow.classList.toggle('active');
                chatWindow.classList.toggle('show');
                if (chatWindow.style.display === 'none' || chatWindow.style.display === '') {
                    chatWindow.style.display = 'block';
                } else {
                    chatWindow.style.display = 'none';
                }
                allmembersButton.click();
            });

            const userId = {{ auth()->user()->id }}

            async function loadUsers() {
                const membersDiv = document.getElementById('members');
                membersDiv.innerHTML = '';
                const token = localStorage.getItem('user_token');
                const response = await fetch('/api/users', {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + token,
                        'Content-Type': 'application/json',
                    },
                });
                const users = await response.json();
                users.data.forEach(user => {
                    const userDiv = document.createElement('div');
                    userDiv.className = 'col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer';

                    userDiv.innerHTML = `
                        <div class="col-3">
                            <img src="${user.image ? user.image.name : '/assets/img/profile-image.png'}"
                                class="size-12 ml-2 rounded-full" alt="">
                        </div>
                        <div class="col-9">
                            <div class="col-12 flex justify-between items-center">
                                <h1 class="text-md text-wrap text-ellipsis overflow-hidden">${user.name}</h1>
                                <p class="text-gray-400 text-xs">${user.created_at}</p>
                            </div>
                            <div class="col-12">
                                <p class="text-gray-500 text-md">${user.role}</p>
                            </div>
                        </div>
                    `;

                    userDiv.addEventListener('click', () => handleUserClick(user));

                    const divider = document.createElement('div');
                    divider.className = 'w-full h-[1px] bg-cyan-500';

                    membersDiv.appendChild(userDiv);
                    membersDiv.appendChild(divider);
                });
            }

            async function loadConversations() {
                const allchatsDiv = document.getElementById('allchats');
                allchatsDiv.innerHTML = '';
                const token = localStorage.getItem('user_token');
                const response = await fetch('/api/allconversations', {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + token,
                        'Content-Type': 'application/json',
                    },
                });
                const conversations = await response.json();
                conversations.data.forEach(conversation => {
                    const conversationDiv = document.createElement('div');
                    conversationDiv.className = 'col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer';

                    conversationDiv.innerHTML = `
                        <div class="col-3">
                            <img src="${conversation.user.image ? conversation.user.image.name : '/assets/img/profile-image.png'}"
                                class="size-12 ml-2 rounded-full" alt="">
                        </div>
                        <div class="col-9">
                            <div class="col-12 flex justify-between items-center">
                                <h1 class="text-md text-wrap text-ellipsis overflow-hidden">${conversation.user.name}</h1>
                                <p class="text-gray-400 text-xs">${conversation.created_at ?? '24.10.20024'}</p>
                            </div>
                            <div class="col-12">
                                <p class="text-gray-500 text-md">${conversation.title}</p>
                            </div>
                        </div>
                    `;

                    conversationDiv.addEventListener('click', () => handleConversationClick(conversation));

                    const divider = document.createElement('div');
                    divider.className = 'w-full h-[1px] bg-cyan-500';

                    allchatsDiv.appendChild(conversationDiv);
                    allchatsDiv.appendChild(divider);
                });
            }

            async function loadConversationsByUserId(userId) {
                const allchatsDiv = document.getElementById('conversationScroll');
                allchatsDiv.innerHTML = '';
                const token = localStorage.getItem('user_token');
                const response = await fetch('/api/allconversations/user/' + userId, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + token,
                        'Content-Type': 'application/json',
                    },
                });
                const conversations = await response.json();
                conversations.data.forEach(conversation => {
                    const conversationDiv = document.createElement('div');
                    conversationDiv.className = 'col-12 flex p-2 items-center hover:bg-slate-100 cursor-pointer';

                    conversationDiv.innerHTML = `
                        <div class="col-3">
                            <img src="${conversation.user.image ? conversation.user.image.name : '/assets/img/profile-image.png'}"
                                class="size-12 ml-2 rounded-full" alt="">
                        </div>
                        <div class="col-9">
                            <div class="col-12 flex justify-between items-center">
                                <h1 class="text-md text-wrap text-ellipsis overflow-hidden">${conversation.user.name}</h1>
                                <p class="text-gray-400 text-xs">${conversation.created_at ?? '24.10.20024'}</p>
                            </div>
                            <div class="col-12">
                                <p class="text-gray-500 text-md">${conversation.title}</p>
                            </div>
                        </div>
                    `;

                    conversationDiv.addEventListener('click', () => handleConversationClick(conversation));

                    const divider = document.createElement('div');
                    divider.className = 'w-full h-[1px] bg-cyan-500';

                    allchatsDiv.appendChild(conversationDiv);
                    allchatsDiv.appendChild(divider);
                });
            }

            function handleUserClick(user) {
                var form = document.getElementById('conversationForm');
                form.setAttribute("user-id", user.id);
                conversationsView();
                chatWindowTitle.innerText = user.name + ' bilan chatlar';
                loadConversationsByUserId(user.id);
            }

            function handleConversationClick(conversation) {
                var form = document.getElementById('messageForm');
                form.setAttribute("conversation-id", conversation.id);
                form.setAttribute("user-id", conversation.user.id);
                messagesView();

                chatWindowTitle.innerText = conversation.user.name + ' - ' + conversation.title;
                loadMessages(conversation.id, conversation.user.id);
            }

            async function loadMessages(conversationId, userId) {
                const messagesDiv = document.getElementById('messageScroll');
                messagesDiv.innerHTML = '';
                const token = localStorage.getItem('user_token');
                const response = await fetch(`/api/messages/${conversationId}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': 'Bearer ' + token,
                        'Content-Type': 'application/json',
                    },
                });
                const messages = await response.json();
                messages.data.forEach(message => {
                    const alignment = message.sender_id == userId ? 'justify-start' : 'justify-end';
                    const border = message.sender_id == userId ? 'rounded-br-2xl rounded-tr-2xl rounded-tl-2xl' :
                        'rounded-bl-2xl rounded-tr-2xl rounded-tl-2xl';
                    messagesDiv.innerHTML += `
                        <div class="flex ${alignment} mb-2">
                            <div class="ml-2 py-1 px-2 max-w-[300px] border-2 border-cyan-500 bg-white ${border} text-sm text-cyan-500">
                                <p class="text-balance break-words">${message.content}</p>
                            </div>
                        </div>
                    `;
                });
            }

            document.getElementById('messageForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                var selectedConversationId = document.getElementById('messageForm').getAttribute('conversation-id');
                var userId = document.getElementById('messageForm').getAttribute('user-id');
                const messageInput = document.getElementById('messageInput');
                const messageText = messageInput.value.trim();
                if (!messageText) return;
                const token = localStorage.getItem('user_token');
                await fetch(`/api/message/${selectedConversationId}`, {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer ' + token,
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({
                        content: messageText
                    })
                });
                messageInput.value = '';
                loadMessages(selectedConversationId, userId);
            });
            document.getElementById('conversationForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                var userId = document.getElementById('conversationForm').getAttribute('user-id');
                const messageInput = document.getElementById('conversationInput');
                const messageText = messageInput.value.trim();
                if (!messageText) return;
                const token = localStorage.getItem('user_token');
                const response = await fetch(`/api/conversation/${userId}`, {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer ' + token,
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                    },
                    body: JSON.stringify({
                        content: messageText
                    })
                });
                const data = await response.json();
                messageInput.value = '';
                var form = document.getElementById('messageForm');
                form.setAttribute("conversation-id", data.data.id);
                form.setAttribute("user-id", data.data.user.id);
                messagesView();

                chatWindowTitle.innerText = data.data.user.name + ' - ' + data.data.title;

                loadMessages(data.data.id, userId);
            });
        </script>
    </div>
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; <strong><span>BIZNES-HIMOYA</span></strong>. Test rejimida ishlamoqda
        </div>
        <div class="credits">
            Designed by <a target="_blank" href="https://t.me/Axror_Abduganiyev/">IT Progress</a>
        </div>
    </footer>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <script src="{{ asset('assets/vendor/apexcharts/apexcharts.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/chart.js/chart.umd.js') }}"></script>
    <script src="{{ asset('assets/vendor/echarts/echarts.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/quill/quill.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/simple-datatables/simple-datatables.js') }}"></script>
    <script src="{{ asset('assets/vendor/tinymce/tinymce.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/php-email-form/validate.js') }}"></script>
    <script src="{{ asset('assets/js/main.js') }}"></script>
    <script>
        var token = "{{ session('user_token') }}";
        if (token) {
            localStorage.setItem('user_token', token);
        }
    </script>
    @yield('js')
</body>

</html>
