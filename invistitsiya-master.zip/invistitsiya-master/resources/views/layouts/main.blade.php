@extends('layouts.app')

@section('content')
    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Xabarlar</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active">@yield('title')</li>
                </ol>
            </nav>
        </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <section class="section">
            <div class="row">
                <div class="col-1">
                    <div class="">
                        <h4 class="h4"><a href="{{ route('message.write') }}">Yozish</a></h4>
                        <h4 class="h4"><a href="{{ route('message.reseived') }}">Kiruvchi</a></h4>
                        <h4 class="h4"><a href="{{ route('message.sent') }}">Yuborilgan</a></h4>
                    </div>
                </div>
                <div class="card col-11">
                    <div class="card-body">
                        @yield('card-body')
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
