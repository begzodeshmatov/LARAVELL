<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Neighborhood extends Model
{
    protected $fillable = [
        "name",
        "district_id",
        "sector_id",
    ];

    public function projects()
    {
        return $this->hasMany(Project::class);
    }
    public function foreignProjects()
    {
        return $this->hasMany(ForeignProject::class);
    }
    public function district()
    {
        return $this->belongsTo(District::class);
    }
    public function sector()
    {
        return $this->belongsTo(Sector::class);
    }
}
