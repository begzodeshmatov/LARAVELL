<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        "role",
        "phone_number",
        "address",
        "position",
        "inn"
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    public function image()
    {
        return $this->morphOne(Image::class, 'imageable');
    }
    public function conversations()
    {
        return $this->belongsToMany(Conversation::class);
    }

    public function messages()
    {
        return $this->hasMany(Message::class);
    }
    public function sentMessages()
    {
        return $this->hasMany(MailMessage::class, 'sender_id');
    }
    public function receivedMessages()
    {
        return $this->hasMany(MailMessage::class, 'receiver_id');
    }
}
