<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MonthlyReport extends Model
{
    protected $fillable = [
        "company_report_id", "month", "pragnoz", "in_practice"
    ];
    public function companyReport()
    {
        return $this->belongsTo(CompanyReport::class);
    }
}
