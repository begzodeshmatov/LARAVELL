<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sector extends Model
{
    protected $fillable = [
        "name"
    ];
    public function neighborhoods()
    {
        return $this->hasMany(Neighborhood::class);
    }
    public function companies()
    {
        return $this->hasMany(Company::class);
    }
}
