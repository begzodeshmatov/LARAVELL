<?php

namespace App\Providers;

use App\Company;
use App\ForeignProject;
use App\MailMessage;
use App\Neighborhood;
use App\Policies\CompanyPolicy;
use App\Policies\ForeignProjectPolicy;
use App\Policies\MailMessagePolicy;
use App\Policies\NeighborhoodPolicy;
use App\Policies\ProjectPolicy;
use App\Policies\TargibotPolicy;
use App\Policies\UserPolicy;
use App\Project;
use App\Targibot;
use App\User;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        User::class => UserPolicy::class,
        Project::class => ProjectPolicy::class,
        Company::class => CompanyPolicy::class,
        Targibot::class => TargibotPolicy::class,
        MailMessage::class => MailMessagePolicy::class,
        Neighborhood::class => NeighborhoodPolicy::class,
        ForeignProject::class => ForeignProjectPolicy::class,
    ];

    public function boot()
    {
        $this->registerPolicies();

        Gate::define('use-bucket', function ($user) {
            return $user->role == "super";
        });
        Gate::define('show-statistics', function ($user) {
            return $user->role == "super" || $user->role === 'observer' || $user->role === 'admin';
        });
    }
}
