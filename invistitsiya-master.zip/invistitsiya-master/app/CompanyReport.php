<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyReport extends Model
{
    protected $fillable = [
        "company_id", "year", "total_price",
    ];
    public function company()
    {
        return $this->belongsTo(Company::class);
    }
    public function monthlyReports()
    {
        return $this->hasMany(MonthlyReport::class);
    }
}
