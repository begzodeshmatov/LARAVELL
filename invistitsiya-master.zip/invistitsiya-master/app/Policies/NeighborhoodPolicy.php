<?php

namespace App\Policies;

use App\Neighborhood;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class NeighborhoodPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return $user->role == "admin" || $user->role == "super";
    }
    public function view(User $user, Neighborhood $neighborhood)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function create(User $user)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function update(User $user, Neighborhood $neighborhood)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function delete(User $user, Neighborhood $neighborhood)
    {
        return $user->role == "admin" || $user->role == "super";
    }
}
