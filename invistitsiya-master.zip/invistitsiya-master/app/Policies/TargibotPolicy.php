<?php

namespace App\Policies;

use App\Targibot;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class TargibotPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return true;
    }

    public function view(User $user, Targibot $targibot)
    {
        return true;
    }

    public function create(User $user)
    {
        return $user->role == "super";
    }

    public function update(User $user, Targibot $targibot)
    {
        return $user->role == "super";
    }

    public function delete(User $user, Targibot $targibot)
    {
        return $user->role == "super";
    }
}
