<?php

namespace App\Policies;

use App\MailMessage;
use App\User;
use Carbon\Carbon;
use Illuminate\Auth\Access\HandlesAuthorization;

class MailMessagePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user)
    {
        return true;
    }

    public function view(User $user, MailMessage $mailMessage)
    {
        return true;
    }

    public function create(User $user)
    {
        return true;
    }

    public function update(User $user, MailMessage $mailMessage)
    {
        return $mailMessage->sender->id == $user->id && $mailMessage->created_at->gt(Carbon::now()->subDays(10));
    }

    public function delete(User $user, MailMessage $mailMessage)
    {
        return $user->role === "super" || $mailMessage->sender->id == $user->id;
    }
}
