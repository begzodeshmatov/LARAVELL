<?php

namespace App\Policies;

use App\Company;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class CompanyPolicy
{
    use HandlesAuthorization;
    public function viewAny(User $user)
    {
        return $user->role == "admin" || $user->role == "super" || $user->role == "observer";
    }
    public function view(User $user, Company $company)
    {
        return $user->role == "admin" || $user->role == "super" || $user->role == "observer";
    }

    public function create(User $user)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function update(User $user, Company $company)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function delete(User $user, Company $company)
    {
        return $user->role == "admin" || $user->role == "super";
    }
}
