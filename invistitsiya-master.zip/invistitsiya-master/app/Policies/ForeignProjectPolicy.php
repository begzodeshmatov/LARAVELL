<?php

namespace App\Policies;

use App\ForeignProject;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ForeignProjectPolicy
{
    use HandlesAuthorization;
    public function viewAny(User $user)
    {
        return $user->role == "admin" || $user->role == "super" || $user->role == "observer";
    }
    public function view(User $user, ForeignProject $foreignProject)
    {
        return $user->role == "admin" || $user->role == "super" || $user->role == "observer";
    }

    public function create(User $user)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function update(User $user, ForeignProject $foreignProject)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function delete(User $user, ForeignProject $foreignProject)
    {
        return $user->role == "admin" || $user->role == "super";
    }

    public function restore(User $user, ForeignProject $foreignProject)
    {
        return $user->role == "super";
    }

    public function forceDelete(User $user, ForeignProject $foreignProject)
    {
        return $user->role == "super";
    }
}
