<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unity extends Model
{
    protected $fillable = [
        "name"
    ];
    public function projects()
    {
        return $this->hasMany(Project::class);
    }
    public function foreignProjects()
    {
        return $this->hasMany(ForeignProject::class);
    }
}
