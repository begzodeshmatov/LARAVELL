<?php

namespace App\Services;

use Carbon\Carbon;

class ProjectValueCalculator
{
    public function calculate($projects, $type)
    {
        $totalPrice = 0;
        $totalCredit = 0;
        $totalForeign = 0;
        $numberOfVacancies = 0;
        $hopelessProjectsCount = 0;
        $overdueProjectsCount = 0;
        $expiredProjectsCount = 0;
        $nearDeadlineProjectsCount = 0;
        $launchedProjectsCount = 0;
        $extendedProjectsCount = 0;

        foreach ($projects as $project) {
            $totalPrice += $project->value;
            $totalCredit += $project->credit;
            $totalForeign += $project->foreign;
            $numberOfVacancies += $project->number_of_vacancies;
            $hopelessProjectsCount += $project->status->key == "hopeless" ? 1 : 0;

            if ($project->status->key == "done" && $project->date < $project->done_at) {
                $overdueProjectsCount++;
            }

            if ($project->status->key == "not_done" && $project->date < Carbon::now()) {
                $expiredProjectsCount++;
            }

            if ($project->date >= Carbon::now() && $project->date <= Carbon::now()->addDays(10)) {
                $nearDeadlineProjectsCount++;
            }

            if ($project->status->key == "done") {
                $launchedProjectsCount++;
            }

            if ($project->status->key == "extended") {
                $extendedProjectsCount++;
            }
        }

        switch ($type) {
            case 'count':
                return $projects->count();
            case 'price':
                return $totalPrice;
            case 'credit':
                return $totalCredit;
            case 'foreign':
                return $totalForeign;
            case 'number_of_vacancies':
                return $numberOfVacancies;
            case 'hopeless':
                return $hopelessProjectsCount;
            case 'overdue':
                return $overdueProjectsCount;
            case 'expired':
                return $expiredProjectsCount;
            case 'nearDeadline':
                return $nearDeadlineProjectsCount;
            case 'launched':
                return $launchedProjectsCount;
            case 'extended':
                return $extendedProjectsCount;
            default:
                return null;
        }
    }
}
