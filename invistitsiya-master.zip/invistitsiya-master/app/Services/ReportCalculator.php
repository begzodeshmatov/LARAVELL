<?php

namespace App\Services;

class ReportCalculator
{
    public static function totalPrice($months)
    {
        $totalPrice = 0;

        foreach ($months as $month) {
            $totalPrice += $month->in_practice;
        }
        return $totalPrice;
    }
    public static function tottalPragnoz($months)
    {
        $totalPrice = 0;

        foreach ($months as $month) {
            $totalPrice += $month->pragnoz;
        }
        return $totalPrice;
    }
    public static function calculate($companies, $type)
    {
        $typefirst = 0;
        $totalPrice = 0;
        $percentage = 0;
        $typesecond = 0;
        $totalPragnoz = 0;
        $typefirstprice = 0;
        $typesecondprice = 0;
        $typefirstpragnoz = 0;
        $typesecondpragnoz = 0;

        foreach ($companies as $company) {
            foreach ($company->companyReports as $companyReport) {
                foreach ($companyReport->monthlyReports as $monthlyReport) {
                    $totalPrice += $monthlyReport->in_practice;
                    $totalPragnoz += $monthlyReport->pragnoz;

                    if ($company->type == 'Sanoat mahsulotlari') {
                        $typefirst++;
                        $typefirstprice += $monthlyReport->in_practice;
                        $typefirstpragnoz += $monthlyReport->pragnoz;
                    } elseif ($company->type == 'Meva-sabzavot mahsulotlari') {
                        $typesecond++;
                        $typesecondprice += $monthlyReport->in_practice;
                        $typesecondpragnoz += $monthlyReport->pragnoz;
                    }
                }
            }
        }

        if ($totalPragnoz > 0) {
            $percentage = round($totalPrice * 100 / $totalPragnoz);
        } else {
            $percentage = 0;
        }

        switch ($type) {
            case 'count':
                return $companies->count();
            case 'price':
                return $totalPrice;
            case 'pragnoz':
                return $totalPragnoz;
            case 'percentage':
                return $percentage;
            case 'typefirst':
                return $typefirst;
            case 'typesecond':
                return $typesecond;
            case 'typefirstprice':
                return $typefirstprice;
            case 'typesecondprice':
                return $typesecondprice;
            case 'typefirstpragnoz':
                return $typefirstpragnoz;
            case 'typesecondpragnoz':
                return $typesecondpragnoz;
            default:
                return null;
        }
    }
    public static function calculateBycompanyReports($companyReports, $type)
    {
        $totalPrice = 0;
        $percentage = 0;
        $totalPragnoz = 0;

        foreach ($companyReports as $companyReport) {
            foreach ($companyReport->monthlyReports as $monthlyReport) {
                $totalPrice += $monthlyReport->in_practice;
                $totalPragnoz += $monthlyReport->pragnoz;
            }
        }

        if ($totalPragnoz > 0) {
            $percentage = round($totalPrice * 100 / $totalPragnoz);
        } else {
            $percentage = 0;
        }

        switch ($type) {
            case 'price':
                return $totalPrice;
            case 'pragnoz':
                return $totalPragnoz;
            case 'percentage':
                return $percentage;
            case 'typefirst':
            default:
                return null;
        }
    }
}
