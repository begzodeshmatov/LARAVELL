<?php

namespace App\Services;

use Carbon\Carbon;

class ProjectType
{
    public function get($projects, $type)
    {
        $filteredProjects = [];

        foreach ($projects as $project) {
            switch ($type) {
                case 'overdue':
                    if ($project->status->key == "done" && $project->date < $project->done_at) {
                        $filteredProjects[] = $project;
                    }
                    break;
                case 'expired':
                    if ($project->status->key == "not_done" && $project->date < Carbon::now()) {
                        $filteredProjects[] = $project;
                    }
                    break;
                case 'nearDeadline':
                    if ($project->date >= Carbon::now() && $project->date <= Carbon::now()->addDays(10)) {
                        $filteredProjects[] = $project;
                    }
                    break;
                case 'launched':
                    if ($project->status->key == "done") {
                        $filteredProjects[] = $project;
                    }
                    break;
                case 'all':
                    if ($project->status->key == "extended") {
                        $filteredProjects[] = $project;
                    }
                    break;
                default:
                    return $projects;
            }
        }

        return $filteredProjects;
    }
}
