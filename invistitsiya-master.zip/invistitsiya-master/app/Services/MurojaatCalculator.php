<?php

namespace App\Services;

use Carbon\Carbon;

class MurojaatCalculator
{
    public function calculate($murojaats, $type)
    {
        $executionTotal = 0;
        $doneTotal = 0;
        $overdueTotal = 0;
        $expiredTotal = 0;
        $newTotal = 0;
        $extendedTotal = 0;
        $todayTotal = 0;
        $tomorrowTotal = 0;
        $aftertomarrowTotal = 0;
        $threeTotal = 0;
        $fourTotal = 0;
        $fiveTotal = 0;

        foreach ($murojaats as $item) {
            if ($item->holat == 2) {
                $executionTotal++;
            }
            if ($item->holat == 5) {
                $doneTotal++;
            }
            if ($item->holat == 5 && $item->time < $item->done_at) {
                $overdueTotal++;
            }
            if ($item->holat !== 5 && $item->time && $item->time < Carbon::yesterday()) {
                $expiredTotal++;
            }
            if ($item->holat == 1) {
                $newTotal++;
            }
            if ($item->holat == 4) {
                $extendedTotal++;
            }
            if ($item->holat !== 5 && $item->time) {
                $time = Carbon::parse($item->time);

                if ($time->isToday()) {
                    $todayTotal++;
                } elseif ($time->isTomorrow()) {
                    $tomorrowTotal++;
                } elseif ($time->diffInDays(Carbon::today()) === 2) {
                    $aftertomarrowTotal++;
                } elseif ($time->diffInDays(Carbon::today()) === 3) {
                    $threeTotal++;
                } elseif ($time->diffInDays(Carbon::today()) === 4) {
                    $fourTotal++;
                } elseif ($time->diffInDays(Carbon::today()) === 5) {
                    $fiveTotal++;
                }
            }
        }

        switch ($type) {
            case 'count':
                return $murojaats->count();
            case 'execution':
                return $executionTotal;
            case 'done':
                return $doneTotal;
            case 'overdue':
                return $overdueTotal;
            case 'expired':
                return $expiredTotal;
            case 'new':
                return $newTotal;
            case 'extended':
                return $extendedTotal;
            case 'today':
                return $todayTotal;
            case 'tomorrow':
                return $tomorrowTotal;
            case 'aftertomarrow':
                return $aftertomarrowTotal;
            case 'three':
                return $threeTotal;
            case 'four':
                return $fourTotal;
            case 'five':
                return $fiveTotal;
            default:
                return null;
        }
    }
}
