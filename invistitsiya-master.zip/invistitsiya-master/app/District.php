<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class District extends Model
{
    protected $fillable = [
        "name", "image"
    ];

    public function region()
    {
        return $this->belongsTo(Region::class);
    }
    public function neighborhoods()
    {
        return $this->hasMany(Neighborhood::class);
    }
    public function projects()
    {
        return $this->hasMany(Project::class);
    }
    public function foreignProjects()
    {
        return $this->hasMany(ForeignProject::class);
    }
    public function companies()
    {
        return $this->hasMany(Company::class);
    }
}
