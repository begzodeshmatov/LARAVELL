<?php

namespace App\Http\Controllers;

use App\Company;
use App\District;
use App\Region;
use App\Sector;
use Illuminate\Support\Facades\Gate;

class ReportStatisticController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function statistic()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $districts = District::where('region_id', 1)->get();
        $region = Region::where("id", 1)->first();
        $companies = Company::all();
        return view('reports_view/statistic', [
            'districts' => $districts,
            'region' => $region,
            'companies' => $companies,
        ]);
    }
    public function district(District $district)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $companies = $district->companies;
        return view('reports_view/statistic/district', [
            'district' => $district,
            'companies' => $companies,
        ]);
    }
    public function districts(Region $region, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $districts = $region->districts;
        return view('reports_view/statistic/districts', [
            'districts' => $districts,
            'type' => $type,
        ]);
    }
    public function sectors(District $district, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $sectors = Sector::all();
        return view('reports_view/statistic/sectors', [
            'district' => $district,
            'sectors' => $sectors,
            'type' => $type,
        ]);
    }
    public function companies(District $district, Sector $sector, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $companies = $district->companies()->where('sector_id', $sector->id)->get();
        return view('reports_view/statistic/companies', [
            'companies' => $companies,
            'district' => $district,
            'sector' => $sector,
            'type' => $type,
        ]);
    }
    public function company(Company $company)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        return view('reports_view/statistic/company', [
            'company' => $company,
        ]);
    }
    public function reports(Company $company)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $montlyReports = $company->companyReports->flatMap->monthlyReports;
        return view('reports_view/statistic/reports', [
            'company' => $company,
            'montlyReports' => $montlyReports,
        ]);
    }
}
