<?php

namespace App\Http\Controllers;

use App\ForeignProject;
use App\Project;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class BucketListController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        if (!Gate::allows("use-bucket")) {
            return redirect()->back();
        }
        $projects = Project::onlyTrashed()->paginate(15);
        $foreignProjects = ForeignProject::onlyTrashed()->paginate(15);
        return view("bucketlist", [
            "projects" => $projects,
            "foreignProjects" => $foreignProjects,
        ]);
    }

    public function restore($id)
    {
        if (!Gate::allows("use-bucket")) {
            return redirect()->route('local');
        }
        $project = Project::onlyTrashed()->where("id", $id)->first();
        $project->restore();
        return redirect()->route("project.index")->with("success", "Loyiha qayta tiklandi.");
    }

    public function destroy($id)
    {
        if (!Gate::allows("use-bucket")) {
            return redirect()->route('local');
        }
        $project = Project::onlyTrashed()->where("id", $id)->first();
        foreach ($project->images as $image) {
            Storage::delete($image->path);
            $image->delete();
        }
        Storage::delete($project->file->path);
        $project->file->delete();
        $project->forceDelete();
        return redirect()->back()->with("success", "Loyiha butunlay o'chirib tashlandi.");
    }

    public function foreignRestore($id)
    {
        if (!Gate::allows("use-bucket")) {
            return redirect()->route('foreign');
        }
        $project = ForeignProject::onlyTrashed()->where("id", $id)->first();
        $project->restore();
        return redirect()->route("project.index.foreign")->with("success", "Loyiha qayta tiklandi.");
    }

    public function foreignDestroy($id)
    {
        if (!Gate::allows("use-bucket")) {
            return redirect()->route('foreign');
        }
        $project = ForeignProject::onlyTrashed()->where("id", $id)->first();
        foreach ($project->images as $image) {
            Storage::delete($image->path);
            $image->delete();
        }
        Storage::delete($project->file->path);
        $project->file->delete();
        foreach ($project->problems as $problem) {
            $problem->delete();
        }
        $project->forceDelete();

        return redirect()->back()->with("success", "Loyiha butunlay o'chirib tashlandi.");
    }
}
