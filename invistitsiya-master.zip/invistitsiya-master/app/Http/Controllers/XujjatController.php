<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class XujjatController extends Controller
{
    public function xujjat()
    {
        return view('xujjat');
    }
}
