<?php

namespace App\Http\Controllers;

use App\Http\Requests\CompanyReportUpdateRequest;
use App\Http\Requests\CompanyReportRequest;
use Illuminate\Http\Request;
use App\CompanyReport;
use App\MonthlyReport;
use App\District;
use App\Sector;
use Illuminate\Support\Facades\Gate;

class CompanyReportController extends Controller
{
    protected $years;
    public function __construct()
    {
        $startYear = 2024;
        $this->years = [$startYear];
        $this->middleware('auth');
    }
    public function index()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $companyReports = CompanyReport::all();

        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();

        return view('reports_admin/companyreports', [
            "companyReports" => $companyReports,
            "districts" => $districts,
            "sectors" => $sectors,
            "years" => $this->years,
        ]);
    }

    public function store(CompanyReportRequest $request)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $existingReport = CompanyReport::where('company_id', $request->company)->where('year', $request->year)->first();

        if ($existingReport) {
            return redirect()->back()->with('error', 'Bu korxona uchun bu yilga allaqachon talab belgilangan.');
        }
        $companyreport = CompanyReport::create([
            "company_id" => $request->company,
            "year" => $request->year,
            "total_price" => $request->total_price,
        ]);
        $monthlySum = round($request->total_price / 12, 1);  // 12 oyga bo'lib olish va 2 o'nlik kasrga o'ralash
        $totalCalculated = $monthlySum * 12;  // Hisoblangan umumiy summa
        $residual = $request->total_price - $totalCalculated;  // Qoldiqni hisoblash

        for ($month = 1; $month <= 12; $month++) {
            // Agar bu oxirgi oy bo'lsa, qoldiqni qo'shing
            $pragnoz = $month == 12 ? $monthlySum + $residual : $monthlySum;

            $companyreport->monthlyReports()->create([
                'company_report_id' => $companyreport->id,
                'month' => $month,
                'pragnoz' => round($pragnoz, 1),  // Natijani 2 o'nlik kasr bilan o'ralash
            ]);
        }
        return redirect()->route('report.edit', ['companyreport' => $companyreport->id])->with('success', 'Talab muvaffaqiyatli yaratildi.');;
    }

    public function edit(CompanyReport $companyreport)
    {
        $monthlyReports = $companyreport->monthlyReports();
        return view('reports_admin/monthlyreports', [
            "companyreport" => $companyreport,
            "monthlyReports" => $monthlyReports,
        ]);
    }

    public function update(CompanyReportUpdateRequest $request, CompanyReport $companyreport)
    {
        if ($companyreport->year != $request->year) {
            $existingReport = CompanyReport::where('company_id', $request->company)->where('year', $request->year)->first();

            if ($existingReport) {
                return redirect()->back()->with('error', 'Bu korxona uchun bu yilga allaqachon talab mavjud.');
            }
        }
        $companyreport->update([
            "year" => $request->year,
            "total_price" => $request->total_price,
        ]);
        return redirect()->back()->with('success', 'Talab muvaffaqiyatli tahrirlandi.');
    }
    public function updateMonthly(Request $request, MonthlyReport $monthlyreport)
    {
        $monthlyreport->update([
            "pragnoz" => $request->pragnoz,
            "in_practice" => $request->in_practice,
        ]);
        return redirect()->back();
    }

    public function destroy(CompanyReport $companyreport)
    {
        foreach ($companyreport->monthlyReports() as $montly) {
            $montly->delete();
        }
        $companyreport->delete();
        return redirect()->back()->with('success', 'Talab o\'chirib yuborildi.');
    }
}
