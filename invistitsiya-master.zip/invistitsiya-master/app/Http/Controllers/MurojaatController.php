<?php

namespace App\Http\Controllers;

use App\Http\Requests\MurojaatRequest;
use Illuminate\Http\Request;
use App\Murojaat;
use App\User;
use Carbon\Carbon;

class MurojaatController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        $users = User::where('id', '!=', auth()->user()->id)->get();

        $query = Murojaat::query();

        if (auth()->user()->role !== 'super') {
            $query->where('tadbirkor_id', auth()->user()->id);
        }

        $forCalculating = $query->get();

        if ($request->has('type') && $request->type !== null) {
            switch ($request->type) {
                case 'execution':
                    $query->where('holat', 2);
                    break;
                case 'done':
                    $query->where('holat', 5);
                    break;
                case 'overdue':
                    $query->where('holat', 5)->whereColumn('time', '<', 'done_at');
                    break;
                case 'expired':
                    $query->where('holat', '!=', 5)->where('time', '<', Carbon::today());
                    break;
                case 'new':
                    $query->where('holat', 1);
                    break;
                case 'extended':
                    $query->where('holat', 4);
                    break;
                case 'today':
                    $query->where('time', Carbon::today());
                    break;
                case 'tomorrow':
                    $query->where('time', Carbon::tomorrow());
                    break;
                case 'aftertomarrow':
                    $query->whereDate('time', Carbon::today()->addDays(2));
                    break;
                case 'three':
                    $query->whereDate('time', Carbon::today()->addDays(3));
                    break;
                case 'four':
                    $query->whereDate('time', Carbon::today()->addDays(4));
                    break;
                case 'five':
                    $query->whereDate('time', Carbon::today()->addDays(5));
                    break;
            }
        }

        $murojaat = $query->paginate(20);

        return view(
            'murojaat',
            [
                'murojaatlar' => $murojaat,
                'forCalculating' => $forCalculating,
                'users' => $users,
            ]
        );
    }
    public function store(MurojaatRequest $request)
    {

        $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
        $request->file('file')->move(public_path('files'), $name);

        $murojaat = Murojaat::create([
            "subject" => $request->subject,
            "tadbirkor_id" => $request->tadbirkor_id,
            "murojaat_type" => $request->murojaat_type,
            "qisqacha" => $request->qisqacha,
            "soha" => $request->soha,
            "file" => $name,
        ]);

        return redirect()->back()->with("success", "Murojaat yaratildi");
    }
    public function destroy(Murojaat $murojaat)
    {
        $murojaat->delete();
        return redirect()->back()->with("success", "Murojaat o'chirildi");
    }
    public function yechish(Request $request, $id)
    {
        dd('keldi');
        $data = [
            "holat" => '5',
        ];
        Murojaat::where('id', $id)->update($data);
        return redirect()->back()->with("success", "Murojaat hal qilindi");
    }
    public function biriktirish(Request $request, $id)
    {
        $data = [
            "subject" => $request->subject,
            "nazoratchi" => $request->nazoratchi,
            "time" => $request->time,
            "holat" => '2',
        ];
        Murojaat::where('id', $id)->update($data);
        return redirect()->back()->with("success", "Murojaat yuborildi");
    }
    public function batafsil(User $murojaat)
    {
        //   dd($murojaat->id);
        $getKorxona = User::where('id', $murojaat->id)->first();
        return view('cabinet/cabinet', [
            'myself' => $getKorxona,
        ]);
    }
    public function done(Request $request, Murojaat $murojaat)
    {
        $request->validate([
            "done_at" => ['required'],
        ]);
        if ($murojaat->holat !== 5 && $murojaat->holat !== 1) {
            $murojaat->update([
                "holat" => 5,
                "done_at" => $request->done_at,
            ]);
            return redirect()->back()->with('success', 'Murojaat bajarildi');
        } else {
            return redirect()->back()->with('error', 'Murojaat allaqchon bajarilgan, yoki ko\'rib chiqishga topshirilmagan');
        }
    }
    public function extend(Request $request, Murojaat $murojaat)
    {
        $request->validate([
            "time" => ['required'],
        ]);
        if ($murojaat->holat !== 5 && $murojaat->holat !== 1) {
            $murojaat->update([
                ""
            ]);
            $murojaat->update([
                "holat" => 4,
                "time" => $request->time,
            ]);
            return redirect()->back()->with('success', 'Murojaat muddati uzaytirildi');
        } else {
            return redirect()->back()->with('error', 'Murojaat allaqchon bajarilgan, yoki ko\'rib chiqishga topshirilmagan');
        }
    }
}
