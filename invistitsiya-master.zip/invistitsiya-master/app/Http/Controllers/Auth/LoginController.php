<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Laravel\Sanctum\PersonalAccessToken;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    protected function authenticated(Request $request, $user)
    {
        $token = $user->createToken('message_token');
        Session::put('user_token', $token->plainTextToken);
        Session::put('user_token_id', $token->accessToken->id);
        if ($user->role === 'admin' || $user->role === 'observer' || $user->role === 'super') {
            return redirect()->route('home');
        } elseif ($user->role === 'enterprise') {
            return redirect()->route('home');
        }


        return redirect($this->redirectTo);
    }
    public function logout(Request $request)
    {
        $user = $request->user();
        $tokenId = $request->session()->get('user_token_id');

        if ($tokenId) {
            $token = PersonalAccessToken::find($tokenId);
            if ($token) {
                $token->delete();
            }
        }

        Auth::logout();

        $request->session()->forget('user_token');
        $request->session()->forget('user_token_id');

        return redirect('/login');
    }
}
