<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\SecondRegisterRequest;
use App\Http\Requests\ThridRegisterRequest;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }
    public function secondregisterview()
    {
        if (Auth::user()->position) {
            return redirect()->back();
        }
        return view('auth/second');
    }
    public function secondregister(SecondRegisterRequest $request)
    {
        Auth::user()->update([
            "position" => $request->position,
            "phone_number" => $request->phone_number,
            "address" => $request->address,
            "inn" => $request->inn
        ]);
        return redirect()->route('register.thrid');
    }
    public function thridregisterview()
    {
        if (Auth::user()->image) {
            return redirect()->back();
        }
        return view('auth/thrid');
    }
    public function thridregister(ThridRegisterRequest $request)
    {
        $name = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/pictures", $name);
        $resolvedPath ='storage/' . str_replace('public/', '', $path);
        Auth::user()->image()->create([
            "name" => $resolvedPath,
            "path" => $path
        ]);
        return redirect()->route('cabinet.show');
    }
}
