<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\ProfileUpdateRequest;
use App\Http\Requests\PasswordUpdateRequest;
use Illuminate\Support\Facades\Storage;

class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function show()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        return view("profile", [
            "user" => auth()->user(),
        ]);
    }

    public function update(ProfileUpdateRequest $request)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $unique = User::where("email", $request->email)->first();
        if ($unique) {
            if ($unique->email == auth()->user()->email) {
                auth()->user()->update([
                    "name" => $request->name,
                    "email" => $request->email,
                ]);
                return redirect()->back()->with("success", "Akkaunt ma'lumotlaringiz muvaffaqiyatli o'zgartirildi");
            }
        } else {
            auth()->user()->update([
                "name" => $request->name,
                "email" => $request->email,
            ]);
            return redirect()->back()->with("success", "Akkaunt ma'lumotlaringiz muvaffaqiyatli o'zgartirildi");
        }
        return redirect()->back()->with("error", $request->email . " bu email mavjud");
    }
    public function password(PasswordUpdateRequest $request)
    {
        if (Hash::check($request->old_password, auth()->user()->password)) {
            auth()->user()->update([
                "password" => Hash::make($request->password),
            ]);
            return redirect()->back()->with("success", "Parolingiz mivaffaqiyatli o'zgartirildi");
        }
        return redirect()->back()->with("error", "Ekis parolingiz noto'g'ri");
    }
    public function image(Request $request)
    {
        $request->validate([
            "image" => ["required", "image", "mimes:jpeg,png,jpg,gif"],
        ]);
        $name = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/pictures", $name);
        $resolvedPath = 'storage/' . str_replace('public/', '', $path);
        if (auth()->user()->image) {
            auth()->user()->image()->update([
                "name" => $resolvedPath,
                "path" => $path
            ]);
            Storage::delete(auth()->user()->image->path);
        } else {
            auth()->user()->image()->create([
                "name" => $resolvedPath,
                "path" => $path
            ]);

        }
        return redirect()->back()->with("success", "Rasm o'zgartirildi");
    }

    public function destroy()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        auth()->user()->delete();
        return redirect()->route('login');
    }
}
