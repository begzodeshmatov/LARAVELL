<?php

namespace App\Http\Controllers;

use App\District;
use App\Neighborhood;
use App\Sector;
use Illuminate\Http\Request;

class NeighborhoodController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(Neighborhood::class, "neighborhood");
    }
    public function index()
    {
        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();
        $neighborhoods = Neighborhood::all();
        return view('neighborhoods', [
            "neighborhoods" => $neighborhoods,
            "districts" => $districts,
            "sectors" => $sectors,
        ]);
    }

    public function store(Request $request)
    {
        Neighborhood::create([
            "name" => $request->name,
            "district_id" => $request->district,
            "sector_id" => $request->sector,
        ]);
        return back()->with('success', 'Mahalla yaratildi');
    }

    public function update(Request $request, Neighborhood $neighborhood)
    {
        $neighborhood->update([
            "name" => $request->name,
            "sector_id" => $request->sector,
        ]);
        return back()->with('success', 'Mahalla tahrirlandi');
    }

    public function destroy(Neighborhood $neighborhood)
    {
        $neighborhood->delete();
        return back()->with('success', 'Mahalla o\'chirildi');
    }
}
