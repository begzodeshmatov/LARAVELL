<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProjectRequest;
use Illuminate\Http\Request;
use App\District;
use App\Exports\LocalProjectsExport;
use App\Network;
use App\Project;
use App\Sector;
use App\Status;
use App\Image;
use App\Field;
use App\File;
use App\Unity;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class ProjectController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(Project::class, 'project');
    }
    public function index(Request $request)
    {
        $query = Project::query();

        if ($request->has('district') && $request->district !== null) {
            $query->where('district_id', $request->district);
        }

        if ($request->has('sector') && $request->sector !== null) {
            $query->whereHas('neighborhood', function ($query) use ($request) {
                $query->where('sector_id', $request->sector);
            });
        }

        if ($request->has('neighborhood') && $request->neighborhood !== null) {
            $query->where('neighborhood_id', $request->neighborhood);
        }

        if ($request->has('status') && $request->status !== null) {
            $query->where('status_id', $request->status);
        }

        if ($request->has('project_name') && $request->project_name !== null) {
            $query->where('name', 'like', '%' . $request->project_name . '%');
        }

        $projects = $query->paginate(20);

        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();
        $fields = Field::where("type", "local")->get();
        $networks = Network::all();
        $unities = Unity::all();
        $statuses = Status::all();

        return view('projects', [
            'projects' => $projects,
            'districts' => $districts,
            'sectors' => $sectors,
            'fields' => $fields,
            'networks' => $networks,
            'unities' => $unities,
            'statuses' => $statuses,
        ]);
    }
    public function export(Request $request)
    {
        return Excel::download(new LocalProjectsExport($request), 'all_local_projects_' . time() . '.xlsx');
    }
    public function store(ProjectRequest $request)
    {
        $project = Project::create([
            "name" => $request->name,
            "goal" => $request->goal,
            "confirmation" => [
                "type" => $request->type,
                "confirm_number" => $request->confirm_number
            ],
            "neighborhood_id" => $request->neighborhood,
            "district_id" => $request->district,
            "field_id" => $request->field,
            "network_id" => $request->network,
            "area" => $request->area,
            "value" => $request->value,
            "power" => $request->power,
            "unity_id" => $request->unity,
            "bank" => $request->bank,
            "own_price" => $request->own_price,
            "actually_done" => $request->actually_done,
            "credit" => $request->credit,
            "foreign" => $request->foreign,
            "number_of_vacancies" => $request->number_of_vacancies,
            "available_vacancies" => $request->available_vacancies,
            "date" => $request->date,
        ]);
        if ($request->file("file")) {
            $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
            $path = $request->file("file")->storeAs("public/files", $name);
            $project->file()->create([
                "name" => $name,
                "path" => $path,
            ]);
        }
        return redirect()->back()->with("success", "Loyiha yaratildi");
    }
    public function edit(Project $project)
    {
        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();
        $fields = Field::where("type", "local")->get();
        $networks = Network::all();
        $unities = Unity::all();
        $statuses = Status::all();
        $neighborhoods = $project->district->neighborhoods()->where('sector_id', $project->neighborhood->sector->id)->get();
        return view('project', [
            "project" => $project,
            'districts' => $districts,
            'sectors' => $sectors,
            'fields' => $fields,
            'networks' => $networks,
            'neighborhoods' => $neighborhoods,
            'unities' => $unities,
            'statuses' => $statuses,
        ]);
    }
    public function update(Project $project, ProjectRequest $request)
    {
        $project->update([
            "name" => $request->name,
            "goal" => $request->goal,
            "confirmation" => [
                "type" => $request->type,
                "confirm_number" => $request->confirm_number
            ],
            "neighborhood_id" => $request->neighborhood,
            "district_id" => $request->district,
            "field_id" => $request->field,
            "network_id" => $request->network,
            "area" => $request->area,
            "value" => $request->value,
            "power" => $request->power,
            "unity_id" => $request->unity,
            "bank" => $request->bank,
            "own_price" => $request->own_price,
            "actually_done" => $request->actually_done,
            "credit" => $request->credit,
            "foreign" => $request->foreign,
            "number_of_vacancies" => $request->number_of_vacancies,
            "available_vacancies" => $request->available_vacancies,
            "date" => $request->date,
        ]);
        return redirect()->back()->with("success", "Loyiha muvaffaqiyatli tahrirlandi");
    }
    public function destroy(Project $project)
    {
        $project->delete();
        return redirect()->back()->with("success", "Loyiha savatga ko'chirildi");
    }
    public function change(Request $request, Project $project)
    {
        $status = Status::where("key", $request->status)->first();
        if ($request->status == "not_done") {
            $project->update([
                "status_id" => $status->id,
                "comment" => null,
                "done_at" => null,
            ]);
        }
        if ($request->status == "hopeless") {
            $request->validate([
                "comment" => ["required", "string"],
            ], [
                'comment.required' => 'Izoh maydonini kiritish majburiy.',
                'comment.string' => 'Izoh maydoni matn bo\'lishi kerak.',
            ]);
            $project->update([
                "status_id" => $status->id,
                "comment" => $request->comment,
                "done_at" => null,
            ]);
        }
        if ($request->status == "done") {
            $request->validate([
                "done_at" => ["required", "date"],
            ], [
                'done_at.required' => 'Sanani kiritish majburiy.',
                'done_at.string' => 'Sana bo\'lishi kerak.',
            ]);
            $project->update([
                "status_id" => $status->id,
                "comment" => null,
                "done_at" => $request->done_at,
            ]);
        }
        if ($request->status == "extended") {
            $request->validate([
                "date" => ["required", "date"],
                "comment" => ["required", "string"],
            ], [
                'date.required' => 'Sanani kiritish majburiy.',
                'date.string' => 'Sana bo\'lishi kerak.',
            ]);
            $project->update([
                "status_id" => $status->id,
                "comment" => $request->comment,
                "done_at" => null,
                "date" => $request->date,
            ]);
        }
        return redirect()->back()->with("success", "Loyiha holati muvaffaqiyatli o'zgartirildi");
    }
    public function image(Request $request, Project $project)
    {
        if ($project->images()->count() == 4) {
            return redirect()->back()->with("error", "Siz faqat 4 ta rasm yuklashingiz mumkun");
        }
        $image = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/photos", $image);
        $project->images()->create([
            "name" => $image,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Rasm muvaffaqiyatli saqlandi");
    }
    public function deed(Request $request, Project $project)
    {
        if ($project->file) {
            return redirect()->back()->with("error", "Dalolatnoma mavjud");
        }
        $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
        $path = $request->file("file")->storeAs("public/files", $name);
        $project->file()->create([
            "name" => $name,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Dalolatnoma muvaffaqiyatli qo'shildi");
    }
    public function imageUpdate(Request $request, Project $project, Image $image)
    {
        Storage::delete($image->path);
        $image->delete();
        $imageName = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/photos", $imageName);
        $project->images()->create([
            "name" => $imageName,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Rasm o'zgartirildi");
    }
    public function deedUpdate(Request $request, Project $project, File $file)
    {
        Storage::delete($file->path);
        $file->delete();
        $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
        $path = $request->file("file")->storeAs("public/files", $name);
        $project->file()->create([
            "name" => $name,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Dalolatnoma o'zgartirildi");
    }
    public function imageDestroy(Project $project, Image $image)
    {
        Storage::delete($image->path);
        $image->delete();
        return redirect()->back()->with("success", "Rasm o'chirildi");
    }
    public function deedDestroy(Project $project, File $file)
    {
        Storage::delete($file->path);
        $file->delete();
        return redirect()->back()->with("success", "Dalolatnoma o'chirildi");
    }
}
