<?php

namespace App\Http\Controllers;

use App\File;
use App\Unity;
use App\Field;
use App\Image;
use App\Status;
use App\Sector;
use App\Network;
use App\Problem;
use App\District;
use App\Exports\ForeignProjectsExport;
use App\ForeignProject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\ForeignProjectRequest;
use Maatwebsite\Excel\Facades\Excel;

class ForeignProjectController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(ForeignProject::class, 'project');
    }
    public function index(Request $request)
    {
        $query = ForeignProject::query();

        if ($request->has('district') && $request->district !== null) {
            $query->where('district_id', $request->district);
        }

        if ($request->has('status') && $request->status !== null) {
            $query->where('status_id', $request->status);
        }

        if ($request->has('project_name') && $request->project_name !== null) {
            $query->where('name', 'like', '%' . $request->project_name . '%');
        }

        $projects = $query->paginate(20);

        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();
        $fields = Field::where("type", "foreign")->get();
        $networks = Network::all();
        $unities = Unity::all();
        $statuses = Status::all();

        return view('projects_foreign', [
            'projects' => $projects,
            'districts' => $districts,
            'sectors' => $sectors,
            'fields' => $fields,
            'networks' => $networks,
            'unities' => $unities,
            'statuses' => $statuses,
        ]);
    }
    public function export(Request $request)
    {
        return Excel::download(new ForeignProjectsExport($request), 'all_foreign_projects_' . time() . '.xlsx');
    }
    public function store(ForeignProjectRequest $request)
    {
        $project = ForeignProject::create([
            "name" => $request->name,
            "goal" => $request->goal,
            "conclusion" => $request->conclusion,
            "address" => $request->address,
            "confirmation" => [
                "type" => $request->type,
                "confirm_number" => $request->confirm_number
            ],
            "leader" => $request->leader,
            "district_id" => $request->district,
            "field_id" => $request->field,
            "area" => $request->area,
            "value" => $request->value,
            "power" => $request->power,
            "unity_id" => $request->unity,
            "bank" => $request->bank,
            "own_price" => $request->own_price,
            "actually_done" => $request->actually_done,
            "credit" => $request->credit,
            "foreign" => $request->foreign,
            "number_of_vacancies" => $request->number_of_vacancies,
            "available_vacancies" => $request->available_vacancies,
            "date" => $request->date,
        ]);
        if ($request->file("file")) {
            $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
            $path = $request->file("file")->storeAs("public/files", $name);
            $project->file()->create([
                "name" => $name,
                "path" => $path,
            ]);
        }
        return redirect()->back()->with("success", "Loyiha yaratildi");
    }
    public function edit(ForeignProject $project)
    {
        $districts = District::where("region_id", 1)->get();
        $fields = Field::where("type", "foreign")->get();
        $unities = Unity::all();
        $statuses = Status::all();
        return view('project_foreign', [
            "project" => $project,
            'districts' => $districts,
            'fields' => $fields,
            'unities' => $unities,
            'statuses' => $statuses,
        ]);
    }
    public function update(ForeignProject $project, ForeignProjectRequest $request)
    {
        $project->update([
            "name" => $request->name,
            "goal" => $request->goal,
            "conclusion" => $request->conclusion,
            "address" => $request->address,
            "confirmation" => [
                "type" => $request->type,
                "confirm_number" => $request->confirm_number
            ],
            "leader" => $request->leader,
            "district_id" => $request->district,
            "field_id" => $request->field,
            "area" => $request->area,
            "value" => $request->value,
            "power" => $request->power,
            "unity_id" => $request->unity,
            "bank" => $request->bank,
            "own_price" => $request->own_price,
            "actually_done" => $request->actually_done,
            "credit" => $request->credit,
            "foreign" => $request->foreign,
            "number_of_vacancies" => $request->number_of_vacancies,
            "available_vacancies" => $request->available_vacancies,
            "date" => $request->date,
        ]);
        return redirect()->route('project.index.foreign')->with("success", "Loyiha muvaffaqiyatli tahrirlandi");
    }
    public function destroy(ForeignProject $project)
    {
        $project->delete();
        return redirect()->back()->with("success", "Loyiha savatga ko'chirildi");
    }
    public function change(Request $request, ForeignProject $project)
    {
        $status = Status::where("key", $request->status)->first();
        if ($request->status == "not_done") {
            $project->update([
                "status_id" => $status->id,
                "comment" => null,
                "done_at" => null,
            ]);
        }
        if ($request->status == "hopeless") {
            $request->validate([
                "comment" => ["required", "string"],
            ], [
                'comment.required' => 'Izoh maydonini kiritish majburiy.',
                'comment.string' => 'Izoh maydoni matn bo\'lishi kerak.',
            ]);
            $project->update([
                "status_id" => $status->id,
                "comment" => $request->comment,
                "done_at" => null,
            ]);
        }
        if ($request->status == "done") {
            $request->validate([
                "done_at" => ["required", "date"],
            ], [
                'done_at.required' => 'Sanani kiritish majburiy.',
                'done_at.string' => 'Sana bo\'lishi kerak.',
            ]);
            $project->update([
                "status_id" => $status->id,
                "comment" => null,
                "done_at" => $request->done_at,
            ]);
        }
        if ($request->status == "extended") {
            $request->validate([
                "date" => ["required", "date"],
                "comment" => ["required", "string"],
            ], [
                'date.required' => 'Sanani kiritish majburiy.',
                'date.string' => 'Sana bo\'lishi kerak.',
            ]);
            $project->update([
                "status_id" => $status->id,
                "comment" => $request->comment,
                "done_at" => null,
                "date" => $request->date,
            ]);
        }
        return redirect()->back()->with("success", "Loyiha holati muvaffaqiyatli o'zgartirildi");
    }
    public function image(Request $request, ForeignProject $project)
    {
        if ($project->images()->count() == 4) {
            return redirect()->back()->with("error", "Siz faqat 4 ta rasm yuklashingiz mumkun");
        }
        $image = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/photos", $image);
        $project->images()->create([
            "name" => $image,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Rasm muvaffaqiyatli saqlandi");
    }
    public function problem(Request $request, ForeignProject $project)
    {
        $project->problems()->create([
            "text" => $request->text,
        ]);
        return redirect()->back()->with("success", "Muammo qo'shildi");
    }
    public function deed(Request $request, ForeignProject $project)
    {
        if ($project->file) {
            return redirect()->back()->with("error", "Dalolatnoma mavjud");
        }
        $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
        $path = $request->file("file")->storeAs("public/files", $name);
        $project->file()->create([
            "name" => $name,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Dalolatnoma muvaffaqiyatli qo'shildi");
    }
    public function imageUpdate(Request $request, ForeignProject $project, Image $image)
    {
        Storage::delete($image->path);
        $image->delete();
        $imageName = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/photos", $imageName);
        $project->images()->create([
            "name" => $imageName,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Rasm o'zgartirildi");
    }
    public function problemUpdate(Request $request, ForeignProject $project, Problem $problem)
    {
        $problem->update([
            "text" => $request->text,
        ]);
        return redirect()->back()->with("success", "Muammo matni o'zgartirildi");
    }
    public function deedUpdate(Request $request, ForeignProject $project, File $file)
    {
        Storage::delete($file->path);
        $file->delete();
        $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
        $path = $request->file("file")->storeAs("public/files", $name);
        $project->file()->create([
            "name" => $name,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Dalolatnoma o'zgartirildi");
    }
    public function imageDestroy(ForeignProject $project, Image $image)
    {
        Storage::delete($image->path);
        $image->delete();
        return redirect()->back()->with("success", "Rasm o'chirildi");
    }
    public function deedDestroy(ForeignProject $project, File $file)
    {
        Storage::delete($file->path);
        $file->delete();
        return redirect()->back()->with("success", "Dalolatnoma o'chirildi");
    }
    public function problemDestroy(ForeignProject $project, Problem $problem)
    {
        $problem->delete();
        return redirect()->back()->with("success", "Muammo o'chirildi");
    }
}
