<?php

namespace App\Http\Controllers;

use App\Company;
use App\District;
use App\Sector;
use App\Services\ReportCalculator;
use Illuminate\Support\Facades\Gate;

class ReportController extends Controller
{
    protected $years;
    public function __construct()
    {
        $startYear = 2024;
        $this->years = [$startYear];
        $this->middleware('auth');
    }
    public function years()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        return view('reports_view/years', [
            'years' => $this->years,
        ]);
    }
    public function districts($year)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $districts = District::where("region_id", 1)->get()->map(function ($district) use ($year) {
            // Har bir tuman uchun hisoblash
            $months = $district->companies->flatMap->companyReports->where('year', $year)->flatMap->monthlyReports->all();

            $totalPrice = ReportCalculator::totalPrice($months);
            $tottalPragnoz = ReportCalculator::tottalPragnoz($months);
            $difference = $totalPrice - $tottalPragnoz;

            // Natijani yangi maydonga qo'shamiz
            $district->totalPrice = $totalPrice;
            $district->tottalPragnoz = $tottalPragnoz;
            $district->difference = $difference;

            return $district;
        });

        // Tumanni `difference` bo'yicha kamayish tartibida saralash
        $districts = $districts->sortByDesc('difference');

        return view('reports_view/districts', [
            'year' => $year,
            'districts' => $districts,
        ]);
    }

    public function sectors($year, District $district)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $sectors = Sector::all();
        return view('reports_view/sectors', [
            'year' => $year,
            'sectors' => $sectors,
            'district' => $district,
        ]);
    }
    public function companies($year, District $district, Sector $sector)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $companies = Company::where('district_id', $district->id)
            ->where('sector_id', $sector->id)
            ->whereHas('companyReports', function ($query) use ($year) {
                $query->where('year', $year);
            })->get();
        return view('reports_view/companies', [
            'year' => $year,
            'sector' => $sector,
            'district' => $district,
            'companies' => $companies,
        ]);
    }
    public function company($year, District $district, Sector $sector, Company $company)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        return view('reports_view/company', [
            'year' => $year,
            'sector' => $sector,
            'company' => $company,
            'district' => $district,
        ]);
    }
    public function months($year, District $district, Sector $sector, Company $company)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $montlyReports = $company->companyReports()->where('year', $year)->first()->monthlyReports;
        return view('reports_view/months', [
            'year' => $year,
            'sector' => $sector,
            'company' => $company,
            'district' => $district,
            'montlyReports' => $montlyReports,
        ]);
    }
}
