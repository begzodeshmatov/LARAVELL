<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use App\Http\Requests\CompanyRequest;
use Illuminate\Http\Request;
use App\District;
use App\Company;
use App\Sector;
use App\Image;

class CompanyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(Company::class, 'company');
    }
    public function index(Request $request)
    {
        $query = Company::query();

        if ($request->has('district') && $request->district !== null) {
            $query->where('district_id', $request->district);
        }

        if ($request->has('sector') && $request->sector !== null) {
            $query->where('sector_id', $request->sector);
        }

        if ($request->has('type') && $request->type !== null) {
            $query->where('type', $request->type);
        }

        if ($request->has('name') && $request->name !== null) {
            $query->where('name', 'like', '%' . $request->name . '%');
        }

        $companies = $query->paginate(20);

        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();

        return view('companies', [
            'companies' => $companies,
            'districts' => $districts,
            'sectors' => $sectors,
        ]);
    }
    public function store(CompanyRequest $request)
    {
        Company::create([
            "name" => $request->name,
            "district_id" => $request->district,
            "sector_id" => $request->sector,
            "type" => $request->type,
        ]);
        return redirect()->back()->with("success", "Korxona yaratildi");
    }
    public function edit(Company $company)
    {
        $districts = District::where("region_id", 1)->get();
        $sectors = Sector::all();
        return view('company', [
            'districts' => $districts,
            'sectors' => $sectors,
            "company" => $company,
        ]);
    }
    public function update(Company $company, CompanyRequest $request)
    {
        $company->update([
            "name" => $request->name,
            "district_id" => $request->district,
            "sector_id" => $request->sector,
            "type" => $request->type,
        ]);
        return redirect()->back()->with("success", "Korxona muvaffaqiyatli tahrirlandi");
    }
    public function destroy(Company $company)
    {
        foreach ($company->images as $image) {
            Storage::delete($image->path);
            $image->delete();
        }
        $company->delete();
        return redirect()->back()->with("success", "Korxona o'chirildi");
    }
    public function image(Request $request, Company $company)
    {
        if ($company->images()->count() == 4) {
            return redirect()->back()->with("error", "Siz faqat 4 ta rasm yuklashingiz mumkun");
        }
        $image = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/companies_images", $image);
        $company->images()->create([
            "name" => $image,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Rasm muvaffaqiyatli saqlandi");
    }
    public function imageUpdate(Request $request, Company $company, Image $image)
    {
        Storage::delete($image->path);
        $image->delete();
        $imageName = time() . '.' . $request->file("image")->getClientOriginalExtension();
        $path = $request->file("image")->storeAs("public/companies_images", $imageName);
        $company->images()->create([
            "name" => $imageName,
            "path" => $path,
        ]);
        return redirect()->back()->with("success", "Rasm o'zgartirildi");
    }
    public function imageDestroy(Company $company, Image $image)
    {
        Storage::delete($image->path);
        $image->delete();
        return redirect()->back()->with("success", "Rasm o'chirildi");
    }
}
