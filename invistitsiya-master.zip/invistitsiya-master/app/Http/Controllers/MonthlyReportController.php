<?php

namespace App\Http\Controllers;

use App\MonthlyReport;
use Illuminate\Http\Request;

class MonthlyReportController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(MonthlyReport $monthlyReport)
    {
        //
    }

    public function edit(MonthlyReport $monthlyReport)
    {
        //
    }

    public function update(Request $request, MonthlyReport $monthlyReport)
    {
        //
    }

    public function destroy(MonthlyReport $monthlyReport)
    {
        //
    }
}
