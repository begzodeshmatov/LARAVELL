<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserDataUpdateRequest;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class CabinetController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function show()
    {
        $myself = Auth::user();
        return view('cabinet/cabinet', [
            'myself' => $myself,
        ]);
    }
    public function update(UserDataUpdateRequest $request)
    {
        $user = Auth::user();
        $unique = User::where("email", $request->email)->first();

        if ($unique) {
            if ($unique->email == $user->email) {
                if ($request->file("image")) {
                    $name = time() . '.' . $request->file("image")->getClientOriginalExtension();
                    $path = $request->file("image")->storeAs("public/pictures", $name);
                    $resolvedPath = 'storage/' . str_replace('public/', '', $path);
                    if (Auth::user()->image) {
                        Storage::delete(Auth::user()->image->path);
                        Auth::user()->image()->update([
                            "name" => $resolvedPath,
                            "path" => $path
                        ]);
                    }
                    Auth::user()->image()->create([
                        "name" => $resolvedPath,
                        "path" => $path
                    ]);
                }

                $user->update([
                    "name" => $request->name,
                    "email" => $request->email,
                    "position" => $request->position,
                    "phone_number" => $request->phone_number,
                    "address" => $request->address,
                    "inn" => $request->inn
                ]);
                return redirect()->back();
            } else {
                return redirect()->back()->with("error", $request->email . " bu email mavjud");
            }
        } else {
            if ($request->file("image")) {
                $name = time() . '.' . $request->file("image")->getClientOriginalExtension();
                $path = $request->file("image")->storeAs("public/pictures", $name);
                $resolvedPath = 'storage/' . str_replace('public/', '', $path);
                if (Auth::user()->image) {
                    Storage::delete(Auth::user()->image->path);
                    Auth::user()->image()->update([
                        "name" => $resolvedPath,
                        "path" => $path
                    ]);
                }
                Auth::user()->image()->create([
                    "name" => $resolvedPath,
                    "path" => $path
                ]);
            }

            $user->update([
                "name" => $request->name,
                "email" => $request->email,
                "position" => $request->position,
                "phone_number" => $request->phone_number,
                "address" => $request->address,
                "inn" => $request->inn
            ]);
            return redirect()->back();
        }
    }
}
