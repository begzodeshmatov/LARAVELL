<?php

namespace App\Http\Controllers;

use App\Field;
use App\ForeignProject;
use App\Network;
use App\Project;
use App\Region;
use Auth;
use Illuminate\Http\RedirectResponse;
use App\Services\ProjectValueCalculator;
use Illuminate\Support\Facades\Gate;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        return view('home');
    }
    public function notavailable()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        return view('notavailable');
    }
    public function local()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $projects = Project::whereHas('district', function ($query) {
            $query->where('region_id', 1);
        })->get();
        // main
        $projectsCount = $projects->count();
        $totalPrice = app(ProjectValueCalculator::class)->calculate($projects, 'price');
        $totalCredit = app(ProjectValueCalculator::class)->calculate($projects, 'credit');
        $totalForeign = app(ProjectValueCalculator::class)->calculate($projects, 'foreign');
        $numberOfVacancies = app(ProjectValueCalculator::class)->calculate($projects, 'number_of_vacancies');
        $hopelessProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'hopeless');
        $overdueProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'overdue');
        $expiredProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'expired');
        $nearDeadlineProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'nearDeadline');
        $launchedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'launched');
        $extendedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'extended');
        // end main
        $region = Region::where("id", 1)->first();
        $districts = $region->districts;
        $fields = Field::where("type", "local")->get();
        $networks = Network::all();

        return view('local', [
            "region" => $region,
            "districts" => $districts,
            "fields" => $fields,
            "networks" => $networks,
            "projectsCount" => $projectsCount,
            "totalPrice" => $totalPrice,
            "totalCredit" => $totalCredit,
            "totalForeign" => $totalForeign,
            "numberOfVacancies" => $numberOfVacancies,
            "hopelessProjectsCount" => $hopelessProjectsCount,
            "overdueProjectsCount" => $overdueProjectsCount,
            "expiredProjectsCount" => $expiredProjectsCount,
            "nearDeadlineProjectsCount" => $nearDeadlineProjectsCount,
            "launchedProjectsCount" => $launchedProjectsCount,
            "extendedProjectsCount" => $extendedProjectsCount,
        ]);
    }
    public function foreign()
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $projects = ForeignProject::whereHas('district', function ($query) {
            $query->where('region_id', 1);
        })->get();
        // main
        $projectsCount = $projects->count();
        $totalPrice = app(ProjectValueCalculator::class)->calculate($projects, 'price');
        $totalCredit = app(ProjectValueCalculator::class)->calculate($projects, 'credit');
        $totalForeign = app(ProjectValueCalculator::class)->calculate($projects, 'foreign');
        $numberOfVacancies = app(ProjectValueCalculator::class)->calculate($projects, 'number_of_vacancies');
        $hopelessProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'hopeless');
        $overdueProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'overdue');
        $expiredProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'expired');
        $nearDeadlineProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'nearDeadline');
        $launchedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'launched');
        $extendedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'extended');
        // end main
        $region = Region::where("id", 1)->first();
        $districts = $region->districts;
        $fields = Field::where("type", "foreign")->get();
        $networks = Network::all();

        return view('foreign', [
            "region" => $region,
            "districts" => $districts,
            "fields" => $fields,
            "networks" => $networks,
            "projectsCount" => $projectsCount,
            "totalPrice" => $totalPrice,
            "totalCredit" => $totalCredit,
            "totalForeign" => $totalForeign,
            "numberOfVacancies" => $numberOfVacancies,
            "hopelessProjectsCount" => $hopelessProjectsCount,
            "overdueProjectsCount" => $overdueProjectsCount,
            "expiredProjectsCount" => $expiredProjectsCount,
            "nearDeadlineProjectsCount" => $nearDeadlineProjectsCount,
            "launchedProjectsCount" => $launchedProjectsCount,
            "extendedProjectsCount" => $extendedProjectsCount,
        ]);
    }
    public function video()
    {
        $email=Auth::user()->email;
        $email=explode('@',$email)[0];
        $url="https://zoom.e-investitsiyajizzax.uz/?room=chat&username=".$email;
        //$url=html_entity_decode($url);
        // dd($url);
        $a=new RedirectResponse($url);

        return $a;
    }
}
