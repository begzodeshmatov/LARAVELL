<?php

namespace App\Http\Controllers;

use App\Http\Requests\MailMessageRequest;
use App\MailMessage;
use App\User;
use Illuminate\Http\Request;

class MailMessageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(MailMessage::class, 'mailMessage');
    }
    public function write()
    {
        $users = User::where('id', '!=', auth()->user()->id)->get();
        return view('messages/writing', [
            'users' => $users
        ]);
    }
    public function reseived()
    {
        $messages = auth()->user()->receivedMessages;
        return view('messages/incoming', [
            'messages' => $messages
        ]);
    }
    public function sent()
    {
        $messages = auth()->user()->sentMessages;
        return view('messages/outgoing', [
            'messages' => $messages
        ]);
    }
    public function store(MailMessageRequest $request)
    {
        MailMessage::create([
            "sender_id" => auth()->user()->id,
            "receiver_id" => $request->user,
            "message" => $request->message,
        ]);
        return redirect()->back()->with('success', 'Xabaringiz jo\'natildi.');
    }
    public function update(Request $request, MailMessage $mailMessage)
    {
        $request->validate([
            "message" => ["required", "string"],
        ]);
        $mailMessage->update([
            "message" => $request->message,
        ]);
        return redirect()->back()->with('success', 'Xabar tahrirlandi.');
    }
    public function destroy(MailMessage $mailMessage)
    {
        $mailMessage->delete();
        return redirect()->back()->with('success', 'Xabar o\'chirildi');
    }
}
