<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Targibot;
use Illuminate\Support\Facades\Storage;

class TargibotController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $targibot = Targibot::all();

        // Har bir targibot fayli bo'yicha turini aniqlash
        foreach ($targibot as $item) {
            // Faylning kengaytmasini aniqlash
            $filePath = $item->file; // Faylning yo'li
            $extension = pathinfo($filePath, PATHINFO_EXTENSION);

            // Fayl turini itemga qo'shish
            $item->file_type = strtolower($extension); // 'jpg', 'mp4', va hokazo
        }

        // Yangi ma'lumotni Blade shabloniga yuborish
        return view("targibot", [
            "targibots" => $targibot,
        ]);
    }
    public function store(Request $request)
    {
        $fileName = '0';
        if ($request->hasFile('file') && $request->file('file')->isValid()) {
            $file = $request->file('file');
            $fileName = time() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('targibot'), $fileName);
        }
        Targibot::create([
            "title" => $request->title,
            "izoh" => $request->izoh,
            "type" => $request->type,
            "file" => $fileName,
        ]);
        return redirect()->back()->with("success", "Targ'ibot qo'shildi");
    }
    public function destroy(Request $request, $id)
    {
        Targibot::where('id', $id)->delete();
        return redirect()->back()->with("success", "Post o'chirildi");
    }
    public function update(Request $request, $id)
    {
        if ($request->hasFile('file') && $request->file('file')->isValid())
        {
            $name = time() . '.' . $request->file("file")->getClientOriginalExtension();
            $request->file('file')->move(public_path('targibot'), $name);
            $data = [
                "title" => $request->title,
                "izoh" => $request->izoh,
                "file" => $name,
            ];
            Targibot::where('id', $id)->update($data);
        }
        else {
            $data = [
                "title" => $request->title,
                "izoh" => $request->izoh,
            ];
            Targibot::where('id', $id)->update($data);
        }

        return redirect()->back()->with("success", "Post o'zgartirildi");
    }
    public function batafsil($id)
    {
        $batafsil = Targibot::where('id', $id)->first();
        return view("tarBatafsil", [
            "tarBatafsil" => $batafsil,
        ]);
    }
}
