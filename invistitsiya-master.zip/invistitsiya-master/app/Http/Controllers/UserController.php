<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Http\Requests\UserRestoreRequest;
use App\Http\Requests\UserUpdateRequest;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->authorizeResource(User::class, "user");
    }
    public function index()
    {
        $users = User::where("role", "!=", "super")->paginate(15);
        return view("users", [
            "users" => $users,
        ]);
    }

    public function store(UserRequest $request)
    {
        $role = "observer";
        if ($request->role == "observer") $role = "observer";
        if ($request->role == "admin") $role = "admin";
        User::create([
            "name" => $request->name,
            "email" => $request->email,
            "role" => $role,
            "password" => Hash::make($request->password),
        ]);
        return redirect()->back()->with("success", "Foydalanuvchi qo'shildi");
    }

    public function update(UserUpdateRequest $request, User $user)
    {
        $role = $user->role;
        if ($request->role == "observer") $role = "observer";
        if ($request->role == "admin") $role = "admin";
        if ($user->role == "enterprise") $role = "enterprise";

        $unique = User::where("email", $request->email)->first();
        if ($unique) {
            if ($unique->email == $user->email) {
                $user->update([
                    "name" => $request->name,
                    "email" => $request->email,
                    "role" => $role,
                ]);
                return redirect()->back()->with("success", "Foydalanuvchi tahrirlandi");
            } else {
                return redirect()->back()->with("error", $request->email . " bu email mavjud");
            }
        } else {
            $user->update([
                "name" => $request->name,
                "email" => $request->email,
                "role" => $role,
            ]);
            return redirect()->back()->with("success", "Foydalanuvchi tahrirlandi");
        }
    }

    public function destroy(User $user)
    {
        if ($user->image) {
            Storage::delete($user->image->path);
            $user->image()->delete();
        }
        $user->delete();
        return redirect()->back()->with("success", "Foydalanuvchi o'chirib tashlandi");
    }

    public function restore(UserRestoreRequest $request, User $user)
    {
        $user->update([
            "password" => Hash::make($request->password),
        ]);
        return redirect()->back()->with("success", "Foydalanuvchi paroli tiklandi");
    }
}
