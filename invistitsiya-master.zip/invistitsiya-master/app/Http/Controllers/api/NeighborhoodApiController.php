<?php

namespace App\Http\Controllers\api;

use App\District;
use App\Http\Controllers\Controller;
use App\Http\Resources\NeighborhoodsResource;
use App\Http\Resources\NeighborhoodsWithResource;
use App\Sector;

class NeighborhoodApiController extends Controller
{
    public function index(District $district, Sector $sector)
    {
        $neighborhoods = $district->neighborhoods()->where('sector_id', $sector->id)->get();
        $data = NeighborhoodsResource::collection($neighborhoods);
        return $this->success($data, "All neighborhoods");
    }
    public function sector(Sector $sector)
    {
        $neighborhoods = $sector->neighborhoods()->get();
        $data = NeighborhoodsResource::collection($neighborhoods);
        return $this->success($data, "All neighborhoods");
    }
    public function district(District $district)
    {
        $neighborhoods = $district->neighborhoods()->get();
        $data = NeighborhoodsResource::collection($neighborhoods);
        return $this->success($data, "All neighborhoods");
    }
    public function select(District $district)
    {
        $neighborhoods = $district->neighborhoods()->with("sector")->with("district")->get();
        $data = NeighborhoodsWithResource::collection($neighborhoods);
        return $this->success($data, "All neighborhoods");
    }
}
