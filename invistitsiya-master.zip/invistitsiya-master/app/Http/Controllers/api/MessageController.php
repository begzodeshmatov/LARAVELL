<?php

namespace App\Http\Controllers\api;

use App\Conversation;
use App\Http\Controllers\Controller;
use App\Http\Requests\MessageRequest;
use App\Http\Resources\ConversationResource;
use App\Http\Resources\MessageResource;
use App\Http\Resources\UserResource;
use App\Message;
use App\User;

class MessageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }
    public function users()
    {
        $users = User::where('id', '!=', auth()->user()->id)->get();

        $data = UserResource::collection($users);

        return $this->success($data, "All users");
    }
    public function conversations()
    {
        $conversations = auth()->user()->conversations()->orderBy('updated_at', 'desc')->get();

        $data = ConversationResource::collection($conversations);

        return $this->success($data, "All conversations");
    }
    public function conversationsByUserId(User $user)
    {
        $conversations = auth()->user()->conversations()->whereHas('users', function ($query) use ($user) {
            $query->where('user_id', $user->id);
        })->orderBy('updated_at', 'desc')->get();

        $data = ConversationResource::collection($conversations);

        return $this->success($data, "All conversations");
    }
    public function messages(Conversation $conversation)
    {
        $messages = $conversation->messages;

        $data = MessageResource::collection($messages);

        return $this->success($data, "All conversations");
    }
    public function addMessage(MessageRequest $request, Conversation $conversation)
    {
        $message = Message::create([
            "conversation_id" => $conversation->id,
            "user_id" => auth()->user()->id,
            "content" => $request->content,
        ]);
        $data = new MessageResource($message);
        return $this->created($data, "Message sended");
    }
    public function addConversation(MessageRequest $request, User $user)
    {
        $conversation = Conversation::create([
            "title" => $request->content,
        ]);
        $conversation->users()->attach([$user->id, auth()->user()->id]);
        $data = new ConversationResource($conversation);
        return $this->created($data, "Conversation created");
    }
}
