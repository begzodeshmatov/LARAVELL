<?php

namespace App\Http\Controllers\api;

use App\Sector;
use App\District;
use App\Http\Controllers\Controller;
use App\Http\Resources\CompanyResource;

class CompaniesApiController extends Controller
{
    public function index(District $district, Sector $sector)
    {
        $companies = $district->companies()->where('sector_id', $sector->id)->get();
        $data = CompanyResource::collection($companies);
        return $this->success($data, "All companies");
    }
    public function sector(Sector $sector)
    {
        $companies = $sector->companies()->get();
        $data = CompanyResource::collection($companies);
        return $this->success($data, "All companies");
    }
    public function district(District $district)
    {
        $companies = $district->companies()->get();
        $data = CompanyResource::collection($companies);
        return $this->success($data, "All companies");
    }
}
