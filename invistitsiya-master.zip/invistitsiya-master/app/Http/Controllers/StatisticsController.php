<?php

namespace App\Http\Controllers;

use App\District;
use App\Field;
use App\ForeignProject;
use App\Neighborhood;
use App\Network;
use App\Project;
use App\Region;
use App\Sector;
use App\Services\ProjectType;
use App\Services\ProjectValueCalculator;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Gate;

class StatisticsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function district(District $district)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $projects = $district->projects;
        // main
        $projectsCount = $projects->count();
        $totalPrice = app(ProjectValueCalculator::class)->calculate($projects, 'price');
        $totalCredit = app(ProjectValueCalculator::class)->calculate($projects, 'credit');
        $totalForeign = app(ProjectValueCalculator::class)->calculate($projects, 'foreign');
        $numberOfVacancies = app(ProjectValueCalculator::class)->calculate($projects, 'number_of_vacancies');
        $hopelessProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'hopeless');
        $overdueProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'overdue');
        $expiredProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'expired');
        $nearDeadlineProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'nearDeadline');
        $launchedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'launched');
        $extendedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'extended');
        // end main
        $fields = Field::where("type", "local")->get();
        $networks = Network::all();

        return view('district', [
            "district" => $district,
            "fields" => $fields,
            "networks" => $networks,
            "projectsCount" => $projectsCount,
            "totalPrice" => $totalPrice,
            "totalCredit" => $totalCredit,
            "totalForeign" => $totalForeign,
            "numberOfVacancies" => $numberOfVacancies,
            "hopelessProjectsCount" => $hopelessProjectsCount,
            "overdueProjectsCount" => $overdueProjectsCount,
            "expiredProjectsCount" => $expiredProjectsCount,
            "nearDeadlineProjectsCount" => $nearDeadlineProjectsCount,
            "launchedProjectsCount" => $launchedProjectsCount,
            "extendedProjectsCount" => $extendedProjectsCount,
        ]);
    }
    public function districtForeign(District $district)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $projects = $district->foreignProjects;
        // main
        $projectsCount = $projects->count();
        $totalPrice = app(ProjectValueCalculator::class)->calculate($projects, 'price');
        $totalCredit = app(ProjectValueCalculator::class)->calculate($projects, 'credit');
        $totalForeign = app(ProjectValueCalculator::class)->calculate($projects, 'foreign');
        $numberOfVacancies = app(ProjectValueCalculator::class)->calculate($projects, 'number_of_vacancies');
        $hopelessProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'hopeless');
        $overdueProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'overdue');
        $expiredProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'expired');
        $nearDeadlineProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'nearDeadline');
        $launchedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'launched');
        $extendedProjectsCount = app(ProjectValueCalculator::class)->calculate($projects, 'extended');
        // end main
        $fields = Field::where("type", "foreign")->get();
        $networks = Network::all();

        return view('district_foreign', [
            "district" => $district,
            "fields" => $fields,
            "networks" => $networks,
            "projectsCount" => $projectsCount,
            "totalPrice" => $totalPrice,
            "totalCredit" => $totalCredit,
            "totalForeign" => $totalForeign,
            "numberOfVacancies" => $numberOfVacancies,
            "hopelessProjectsCount" => $hopelessProjectsCount,
            "overdueProjectsCount" => $overdueProjectsCount,
            "expiredProjectsCount" => $expiredProjectsCount,
            "nearDeadlineProjectsCount" => $nearDeadlineProjectsCount,
            "launchedProjectsCount" => $launchedProjectsCount,
            "extendedProjectsCount" => $extendedProjectsCount,
        ]);
    }
    public function districts(Region $region, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $districts = $region->districts;

        return view("project_view/districts", [
            "districts" => $districts,
            "type" => $type,
        ]);
    }
    public function sectors(District $district, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $sectors = Sector::all();
        return view("project_view/sectors", [
            "sectors" => $sectors,
            "district" => $district,
            "type" => $type,
        ]);
    }
    public function neighborhoods(District $district, Sector $sector, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $neighborhoods = $district->neighborhoods()->where("sector_id", $sector->id)->get();
        return view("project_view/neighborhoods", [
            "neighborhoods" => $neighborhoods,
            "type" => $type,
        ]);
    }
    public function projects(Neighborhood $neighborhood, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $name = $neighborhood->district->name;

        $allProjects = $neighborhood->projects()->get();

        $filteredProjects = (new ProjectType())->get($allProjects, $type);

        $filteredProjects = collect($filteredProjects);

        $currentPage = Paginator::resolveCurrentPage();
        $perPage = 15;
        $currentPageItems = $filteredProjects->slice(($currentPage - 1) * $perPage, $perPage)->all();

        $projects = new LengthAwarePaginator(
            $currentPageItems,
            $filteredProjects->count(),
            $perPage,
            $currentPage,
            ['path' => Paginator::resolveCurrentPath()]
        );

        $local = true;

        return view("project_view/projects", [
            "projects" => $projects,
            "local" => $local,
            "name" => $name,
        ]);
    }
    public function project(Project $project)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $name = $project->neighborhood->district->name;

        return view("project_view/project", [
            "project" => $project,
            "name" => $name,
        ]);
    }
    // forign
    public function allProjects(District $district, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $name = $district->name;

        $allProjects = $district->foreignProjects()->get();

        $filteredProjects = (new ProjectType())->get($allProjects, $type);

        $filteredProjects = collect($filteredProjects);

        $currentPage = Paginator::resolveCurrentPage();
        $perPage = 15;
        $currentPageItems = $filteredProjects->slice(($currentPage - 1) * $perPage, $perPage)->all();

        $projects = new LengthAwarePaginator(
            $currentPageItems,
            $filteredProjects->count(),
            $perPage,
            $currentPage,
            ['path' => Paginator::resolveCurrentPath()]
        );

        return view("project_view/projects_foreign", [
            "projects" => $projects,
            "name" => $name,
        ]);
    }

    public function projectForeign(ForeignProject $project)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $name = $project->district->name;

        return view("project_view/project_foreign", [
            "project" => $project,
            "name" => $name,
        ]);
    }
    public function districtsForeign(Region $region, $type)
    {
        if (!Gate::allows("show-statistics")) {
            return redirect()->route('cabinet.show');
        }
        $districts = $region->districts;

        return view("project_view/districts_foreign", [
            "districts" => $districts,
            "type" => $type,
        ]);
    }
}
