<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProjectRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "name" => ["required", "string", "max:255"],
            "goal" => ["required", "string"],
            "type" => ["required", "string", "in:STIR,JSHSHIR"],
            "confirm_number" => ["required",],
            "sector" => ["required", "integer"],
            "neighborhood" => ["required", "integer"],
            "field" => ["required", "integer"],
            "network" => ["required", "integer"],
            "area" => ["required", "numeric"],
            "value" => ["required", "numeric"],
            "bank" => ["required", "string"],
            "own_price" => ["required", "numeric"],
            "actually_done" => ["required", "numeric"],
            "credit" => ["required", "numeric"],
            "foreign" => ["required", "numeric"],
            "power" => ["required", "numeric"],
            "unity" => ["required", "integer"],
            "number_of_vacancies" => ["required", "integer"],
            "available_vacancies" => ["required", "integer"],
            "date" => ["required", "date"],
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'Loyiha nomini kiritish majburiy.',
            'name.string' => 'Loyiha nomi matn bo\'lishi kerak.',
            'name.max' => 'Loyiha nomi 255 belgidan oshmasligi kerak.',

            'goal.required' => 'Loyiha maqsadini kiritish majburiy.',
            'goal.string' => 'Loyiha maqsadi matn bo\'lishi kerak.',

            'region.required' => 'Hudud tanlanishi majburiy.',
            'region.integer' => 'Hudud ID raqam bo\'lishi kerak.',

            'sector.required' => 'Sektor tanlanishi majburiy.',
            'sector.integer' => 'Sektor ID raqam bo\'lishi kerak.',

            'neighborhood.required' => 'Mahalla tanlanishi majburiy.',
            'neighborhood.integer' => 'Mahalla ID raqam bo\'lishi kerak.',

            'field.required' => 'Soha tanlanishi majburiy.',
            'field.integer' => 'Soha ID raqam bo\'lishi kerak.',

            'network.required' => 'Tarmoq tanlanishi majburiy.',
            'network.integer' => 'Tarmoq ID raqam bo\'lishi kerak.',

            'area.required' => 'Hudud maydoni kiritilishi majburiy.',
            'area.numeric' => 'Hudud maydoni son bo\'lishi kerak.',

            'type.required' => 'Turini kiritish majburiy.',
            'type.string' => 'Turi matn bo\'lishi kerak.',

            'confirm_number.required' => 'JSHSHR yoki STIR kiritilmagan.',

            'value.required' => 'Loyiha qiymati kiritilishi majburiy.',
            'value.numeric' => 'Loyiha qiymati son bo\'lishi kerak.',

            'credit.required' => 'Bank krediti kiritilishi majburiy.',
            'credit.numeric' => 'Bank krediti son bo\'lishi kerak.',

            'foreign.required' => 'Xorijiy investitsiya kiritilishi majburiy.',
            'foreign.numeric' => 'Xorijiy investitsiya son bo\'lishi kerak.',

            'power.required' => 'Loyiha quvvati kiritilishi majburiy.',
            'power.numeric' => 'Loyiha quvvati son bo\'lishi kerak.',

            'unity.required' => 'Birlik tanlanishi majburiy.',
            'unity.integer' => 'Birlik ID raqam bo\'lishi kerak.',

            'number_of_vacancies.required' => 'Ish o\'rni soni kiritilishi majburiy.',
            'number_of_vacancies.integer' => 'Ish o\'rni soni raqam bo\'lishi kerak.',

            'available_vacancies.required' => 'Tashkil etilgan ish o\'rni soni kiritilishi majburiy.',
            'available_vacancies.integer' => 'Tashkil etilgan ish o\'rni soni raqam bo\'lishi kerak.',

            'date.required' => 'Loyiha muddati kiritilishi majburiy.',
            'date.date' => 'Loyiha muddati haqiqiy sana formatida bo\'lishi kerak.',

            'bank.required' => 'Bank nomini kiritish majburiy.',
            'bank.string' => 'Bank nomi matn bo\'lishi kerak.',

            'own_price.required' => 'Oz\'z mablag\'i hisobidan kiritilgan mablag\'i kiritilishi majburiy.',
            'own_price.numeric' => 'Oz\'z mablag\'i hisobidan kiritilgan mablag\'i son bo\'lishi kerak.',

            'actually_done.required' => 'Amalda bajarilgan mablag\' kiritilishi majburiy.',
            'actually_done.numeric' => 'Amalda bajarilgan mablag\' son bo\'lishi kerak.',
        ];
    }
}
