<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MurojaatRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "subject" => ["string", "max:255"],
            "tadbirkor_id" => ["required", "integer"],
            "murojaat_type" => ["required", "string"],
            "qisqacha" => ["required","string"],
            "nazoratchi" => ["string"],
            "soha" => ["required", "string"],
            "time" => ["date"],
        ];
    }
}
