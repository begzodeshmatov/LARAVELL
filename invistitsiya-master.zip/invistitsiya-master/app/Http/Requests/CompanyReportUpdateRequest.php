<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompanyReportUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "year" => ["required", "numeric"],
            "total_price" => ["required"],
        ];
    }
    public function messages()
    {
        return [
            "year.required" => "Yil maydoni tanlanishi shart.",
            "year.numeric" => "Yil faqat son bo'lishi kerak.",
            "total_price.required" => "Yillik talab kiritilishi shart.",
        ];
    }
}
