<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserDataUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "image" => ["image", "mimes:jpeg,png,jpg,gif"],
            "position" => ["required", "string"],
            "phone_number" => ["required", "string"],
            "address" => ["required", "string"],
            "inn" => ["required", "digits:9", "numeric"],
            "name" => ["required", "string"],
            "email" => ["required", "email"],
        ];
    }
}
