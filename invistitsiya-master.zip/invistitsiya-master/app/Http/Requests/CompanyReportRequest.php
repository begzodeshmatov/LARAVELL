<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompanyReportRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "company" => ["required"],
            "year" => ["required", "numeric"],
            "total_price" => ["required"],
        ];
    }
    public function messages()
    {
        return [
            "company.required" => "Korxona maydoni tanlanishi shart.",
            "year.required" => "Yil maydoni tanlanishi shart.",
            "year.numeric" => "Yil faqat son bo'lishi kerak.",
            "total_price.required" => "Yillik talab kiritilishi shart.",
        ];
    }
}
