<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MailMessageRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            "user" => ["required"],
            "message" => ["required", "string"],
        ];
    }
}
