<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class NeighborhoodsWithResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "name" => $this->name,
            "sector" => new SectorsResource($this->sector),
            "district" => new DistrictResource($this->district),
        ];
    }
}
