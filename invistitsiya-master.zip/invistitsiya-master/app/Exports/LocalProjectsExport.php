<?php

namespace App\Exports;

use App\Project;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

class LocalProjectsExport implements FromCollection, WithHeadings, WithMapping, WithStyles, WithEvents, WithChunkReading
{

    protected $request;

    public function __construct($request)
    {
        $this->request = $request;
    }
    private function formatNumber($number)
    {
        if (floor($number) == $number) {
            return number_format($number, 0, '.', '');
        }
        return rtrim(rtrim($number, '0'), '.');
    }
    public function collection()
    {
        $query = Project::with(['district', "neighborhood", "field", "network", "unity", "status"]);

        // Filterlarni qo'llash
        if ($this->request->has('district') && $this->request->district !== null) {
            $query->where('district_id', $this->request->district);
        }

        if ($this->request->has('sector') && $this->request->sector !== null) {
            $query->whereHas('neighborhood', function ($query) {
                $query->where('sector_id', $this->request->sector);
            });
        }

        if ($this->request->has('neighborhood') && $this->request->neighborhood !== null) {
            $query->where('neighborhood_id', $this->request->neighborhood);
        }

        if ($this->request->has('status') && $this->request->status !== null) {
            $query->where('status_id', $this->request->status);
        }

        if ($this->request->has('project_name') && $this->request->project_name !== null) {
            $query->where('name', 'like', '%' . $this->request->project_name . '%');
        }

        return $query->get();
    }

    public function headings(): array
    {
        return [
            "№",
            "Loyiha tashabbuskori",
            "Loyiha nomi",
            "STIR & JSHSHIR",
            "Tuman",
            "Sektor",
            "Mahalla",
            "Soha",
            "Tarmoq",
            "Xizmat ko'rsativchi bank",
            "Bank krediti",
            "Amalda bajarildi",
            "O'z mablag'i hisobidan",
            "Xorijiy investitsiya",
            "Loyiha qiymati",
            "Maydoni",
            "Loyiha quvvati",
            "Yaratilgan ish o'rni",
            "Amalda",
            "Sana",
            "Holati",
        ];
    }

    public function map($project): array
    {
        return [
            $project->id,
            $project->name,
            $project->goal,
            $project->confirmation['type'] . ': ' . $project->confirmation['confirm_number'],
            $project->district->name,
            $project->neighborhood->sector->name,
            $project->neighborhood->name,
            $project->field->name,
            $project->network->name,
            $project->bank,
            $this->formatNumber($project->credit),
            $this->formatNumber($project->actually_done),
            $this->formatNumber($project->own_price),
            $this->formatNumber($project->foreign),
            $this->formatNumber($project->value),
            $this->formatNumber($project->area) . ' ga',
            $this->formatNumber($project->power) . ' ' . $project->unity->name,
            $project->number_of_vacancies,
            $project->available_vacancies,
            $project->date,
            $project->status->name,
        ];
    }
    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => [
                    'bold' => true,
                    'size' => 14,
                    'color' => ['argb' => '000000'],
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'argb' => 'C1C5CD',
                    ]
                ]
            ],
        ];
    }
    public function registerEvents(): array
    {
        return [
            \Maatwebsite\Excel\Events\AfterSheet::class => function(\Maatwebsite\Excel\Events\AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();

                $columnWidths = [
                    'A' => 8,
                    'B' => 55,
                    'C' => 35,
                    'D' => 30,
                    'E' => 25,
                    'F' => 15,
                    'G' => 35,
                    'H' => 30,
                    'I' => 40,
                    'J' => 45,
                    'K' => 20,
                    'L' => 20,
                    'M' => 25,
                    'N' => 25,
                    'O' => 20,
                    'P' => 20,
                    'Q' => 30,
                    'R' => 25,
                    'S' => 15,
                    'T' => 15,
                    'U' => 20,
                ];

                foreach ($columnWidths as $column => $width) {
                    $sheet->getColumnDimension($column)->setWidth($width);
                }

                $highestRow = $sheet->getHighestRow();
                $sheet->getStyle('A1:U' . $highestRow)->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['argb' => 'FF000000'],
                        ],
                    ],
                ]);
            }
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
