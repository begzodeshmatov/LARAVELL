<?php

namespace App\Exports;

use App\ForeignProject;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Style\Border;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ForeignProjectsExport implements FromCollection, WithHeadings, WithMapping, WithStyles, WithEvents, WithChunkReading
{
    protected $request;

    public function __construct($request)
    {
        $this->request = $request;
    }
    private function formatNumber($number)
    {
        if (floor($number) == $number) {
            return number_format($number, 0, '.', '');
        }
        return rtrim(rtrim($number, '0'), '.');
    }
    public function collection()
    {
        $query = ForeignProject::with(['district', "field", "unity", "status"]);

        if ($this->request->has('district') && $this->request->district !== null) {
            $query->where('district_id', $this->request->district);
        }

        if ($this->request->has('status') && $this->request->status !== null) {
            $query->where('status_id', $this->request->status);
        }

        if ($this->request->has('project_name') && $this->request->project_name !== null) {
            $query->where('name', 'like', '%' . $this->request->project_name . '%');
        }

        return $query->get();
    }

    public function headings(): array
    {
        return [
            "№",
            "Loyiha tashabbuskori",
            "Loyiha nomi",
            "O'rganish natijasi bo'yicha xulosa",
            "Manzili",
            "STIR & JSHSHIR",
            "Loyiha raxbari",
            "Tuman",
            "Soha",
            "Xizmat ko'rsativchi bank",
            "Bank krediti",
            "Amalda bajarildi",
            "O'z mablag'i hisobidan",
            "Xorijiy investitsiya",
            "Loyiha qiymati",
            "Maydoni",
            "Loyiha quvvati",
            "Yaratilgan ish o'rni",
            "Amalda",
            "Muammolar soni",
            "Sana",
            "Holati",
        ];
    }

    public function map($project): array
    {
        return [
            $project->id,
            $project->name,
            $project->goal,
            $project->conclusion,
            $project->address,
            $project->confirmation['type'] . ': ' . $project->confirmation['confirm_number'],
            $project->leader,
            $project->district->name,
            $project->field->name,
            $project->bank,
            $this->formatNumber($project->credit),
            $this->formatNumber($project->actually_done),
            $this->formatNumber($project->own_price),
            $this->formatNumber($project->foreign),
            $this->formatNumber($project->value),
            $project->area,
            $this->formatNumber($project->power) . ' ' . $project->unity->name,
            $project->number_of_vacancies,
            $project->available_vacancies,
            $project->problems()->count(),
            $project->date,
            $project->status->name,
        ];
    }
    public function styles(Worksheet $sheet)
    {
        return [
            1 => [
                'font' => [
                    'bold' => true,
                    'size' => 14,
                    'color' => ['argb' => '000000'],
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => [
                        'argb' => 'C1C5CD',
                    ]
                ]
            ],
        ];
    }
    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();

                $columnWidths = [
                    'A' => 8,
                    'B' => 55,
                    'C' => 35,
                    'D' => 50,
                    'E' => 40,
                    'F' => 35,
                    'G' => 45,
                    'H' => 20,
                    'I' => 35,
                    'J' => 45,
                    'K' => 20,
                    'L' => 20,
                    'M' => 30,
                    'N' => 25,
                    'O' => 20,
                    'P' => 40,
                    'Q' => 25,
                    'R' => 28,
                    'S' => 18,
                    'T' => 25,
                    'U' => 15,
                    'V' => 18,
                ];

                foreach ($columnWidths as $column => $width) {
                    $sheet->getColumnDimension($column)->setWidth($width);
                }


                $highestRow = $sheet->getHighestRow();
                $sheet->getStyle('A1:v' . $highestRow)->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical'   => Alignment::VERTICAL_CENTER,
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['argb' => 'FF000000'],
                        ],
                    ],
                ]);
            }
        ];
    }

    public function chunkSize(): int
    {
        return 1000;
    }
}
