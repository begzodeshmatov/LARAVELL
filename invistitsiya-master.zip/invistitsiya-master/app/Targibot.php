<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Targibot extends Model
{
    protected $fillable = [
        'title', 'izoh', 'type', "file"
    ];
}
