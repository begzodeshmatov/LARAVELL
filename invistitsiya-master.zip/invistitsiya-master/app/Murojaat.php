<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class Murojaat extends Model
{
    protected $casts = [
        'time' => 'datetime',
        'done_at' => 'datetime',
    ];
    protected $fillable = [
        "subject", "tadbirkor_id", "murojaat_type", "qisqacha", "nazoratchi", "soha", "file", "time", "holat", "done_at"
    ];
    public function company()
    {
        return $this->belongsTo(User::class, 'tadbirkor_id');
    }
}
