<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Project extends Model
{
    use SoftDeletes;
    protected $fillable = [
        "name",
        "goal",
        "confirmation",
        "area",
        "value",
        "power",
        "bank",
        "actually_done",
        "own_price",
        "credit",
        "foreign",
        "number_of_vacancies",
        "available_vacancies",
        "date",
        "status",
        "comment",
        "neighborhood_id",
        "district_id",
        "field_id",
        "network_id",
        "unity_id",
        "done_at",
        "status_id",
    ];
    protected $casts = [
        'confirmation' => 'json',
    ];
    public function neighborhood()
    {
        return $this->belongsTo(Neighborhood::class);
    }
    public function district()
    {
        return $this->belongsTo(District::class);
    }
    public function field()
    {
        return $this->belongsTo(Field::class);
    }
    public function network()
    {
        return $this->belongsTo(Network::class);
    }
    public function status()
    {
        return $this->belongsTo(Status::class);
    }
    public function unity()
    {
        return $this->belongsTo(Unity::class);
    }
    public function images()
    {
        return $this->morphMany(Image::class, 'imageable');
    }
    public function file()
    {
        return $this->morphOne(File::class, 'fileable');
    }
}
