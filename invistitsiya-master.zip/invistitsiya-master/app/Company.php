<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    protected $fillable = [
        "sector_id", "district_id", "name", "type"
    ];
    public function images()
    {
        return $this->morphMany(Image::class, 'imageable');
    }
    public function sector()
    {
        return $this->belongsTo(Sector::class);
    }
    public function district()
    {
        return $this->belongsTo(District::class);
    }
    public function companyReports()
    {
        return $this->hasMany(CompanyReport::class);
    }
}
