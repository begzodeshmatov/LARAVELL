<?php

use App\Region;
use Illuminate\Database\Seeder;

class RegionSeeder extends Seeder
{
    public function run()
    {
        Region::create(
            [
                'name' => 'Jizzax',
                'image' => 'https://rossaprimavera.ru/static/files/c97f860832fb.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Toshkent',
                'image' => 'https://ogoh.uz/wp-content/uploads/2022/08/photo_2022-08-18_08-11-53.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Sirdaryo',
                'image' => 'https://xs.uz/upload/template/tashkilotlar%20binolari/11d96f43b0623548c5bde22617eb16751111.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Samaraqand',
                'image' => 'https://avatars.mds.yandex.net/i?id=b4d9ca41e2988399d36823dede9af8a1_l-9989050-images-thumbs&n=13'
            ]
        );
        Region::create(
            [
                'name' => 'Andijon',
                'image' => 'https://dolorestravel.com/uploads/Guide/31/61c1e85fa910c.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Namangan',
                'image' => 'https://static.tildacdn.com/tild6632-3836-4633-a663-636265303165/photo.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Farg\'ona',
                'image' => 'https://avatars.mds.yandex.net/i?id=1f313d4b9c405bbb8bd7c1c2b61b1a3c_l-12605172-images-thumbs&n=13'
            ]
        );
        Region::create(
            [
                'name' => 'Buxoro',
                'image' => 'https://teznews.uz/wp-content/uploads/2020/11/68739f4dc43a02b74e3d7.png'
            ]
        );
        Region::create(
            [
                'name' => 'Navoiy',
                'image' => 'https://avatars.mds.yandex.net/i?id=fab3d3f0240350a7c2132d0f3f228be1_l-12847150-images-thumbs&n=13'
            ]
        );
        Region::create(
            [
                'name' => 'Qashqadaryo',
                'image' => 'https://novotours.uz/wp-content/uploads/2017/03/14-_2_-3.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Surxandoryo',
                'image' => 'https://telegra.ph/file/8ccb50cfd407c3be383c0.jpg'
            ]
        );
        Region::create(
            [
                'name' => 'Xorazm',
                'image' => 'https://wallpaper.forfun.com/fetch/4d/4d1d7c5133352d451f8fb6e3f578afa9.jpeg'
            ]
        );
    }
}
