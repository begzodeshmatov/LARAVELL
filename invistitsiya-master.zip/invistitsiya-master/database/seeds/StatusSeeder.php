<?php

use App\Status;
use Illuminate\Database\Seeder;

class StatusSeeder extends Seeder
{
    public function run()
    {
        Status::create(
            [
                "name" => "Bajarilmagan",
                "key" => "not_done",
            ]
        );
        Status::create(
            [
                "name" => "Istiqbolsiz",
                "key" => "hopeless",
            ]
        );
        Status::create(
            [
                "name" => "Bajarilgan",
                "key" => "done",
            ]
        );
        Status::create(
            [
                "name" => "Muddati uzaytirilgan",
                "key" => "extended",
            ]
        );
    }
}
