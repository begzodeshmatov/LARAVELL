<?php

use App\District;
use Illuminate\Database\Seeder;

class DistrictSeeder extends Seeder
{
    public function run()
    {
        District::create(
            [
                'name' => 'Jizzax',
                'image' => 'https://uzbekistanfaq.ru/wp-content/uploads/2023/04/c4587cb1f6dd9355ccedc4954506c311.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Forish',
                'image' => 'http://jizzax.uz/uploads/posts/2019-08/1566368861_238222279_283212.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'G\'allaorol',
                'image' => 'https://avatars.mds.yandex.net/i?id=ba42ae8dd601d98f49e9197374bd52f6_l-10889624-images-thumbs&n=13',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Baxmal',
                'image' => 'https://avatars.mds.yandex.net/i?id=21364a71342a2efc865be5a4e07f7234_l-5258284-images-thumbs&n=13',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Arnasoy',
                'image' => 'https://aksent.uz/media/cache/08/a1/08a1eb91ac10f9dd2623f40513267d1b.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Do\'stlik',
                'image' => 'https://daryo.uz/cache/2017/04/dostlik-1-640x480.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Paxtakor',
                'image' => 'https://avatars.mds.yandex.net/i?id=919bfc3e3c43336ecb702e831d287a2f_l-7265716-images-thumbs&n=13',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Sharof Rashidov',
                'image' => 'https://podrobno.uz/upload/rk/photo_2017-11-06_17-26-56.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Yangiobod',
                'image' => 'https://yuz.uz/imageproxy/1920x/https://yuz.uz/file/news/8312852db778e085dddb61d0497d998d.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Mirzacho\'l',
                'image' => 'https://aniq.uz/photos/news/UMMiqMEBm7Dzhtw.jpeg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Zafarobod',
                'image' => 'https://daryo.uz/cache/2019/02/photo_2019-02-04_21-15-52-1280x720.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Zarbdor',
                'image' => 'https://zarbdor.jizzax.uz/templates/munic-utf8/images/Zarbdor.jpg',
                'region_id' => 1
            ]
        );
        District::create(
            [
                'name' => 'Zomin',
                'image' => 'https://i.ytimg.com/vi/JNvbLGivvc8/maxresdefault.jpg',
                'region_id' => 1
            ]
        );
    }
}
