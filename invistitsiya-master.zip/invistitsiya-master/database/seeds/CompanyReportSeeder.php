<?php

use App\CompanyReport;
use Illuminate\Database\Seeder;

class CompanyReportSeeder extends Seeder
{
    public function run()
    {
        CompanyReport::create([
            "company_id" => 1,
            "year" => 2023,
            "total_price" => 454.5656,
        ]);
        CompanyReport::create([
            "company_id" => 1,
            "year" => 2024,
            "total_price" => 454.5656,
        ]);
        CompanyReport::create([
            "company_id" => 2,
            "year" => 2023,
            "total_price" => 454.5656,
        ]);
        CompanyReport::create([
            "company_id" => 2,
            "year" => 2024,
            "total_price" => 454.5656,
        ]);
    }
}
