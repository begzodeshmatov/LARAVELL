<?php

use App\Network;
use Illuminate\Database\Seeder;

class NetworkSeeder extends Seeder
{
    public function run()
    {
        Network::create(["name" => "Qurulish materiallari sanoati"]);
        Network::create(["name" => "Oziq ovqat sanoati"]);
        Network::create(["name" => "Tekstil va to'qimachilik sanoati"]);
        Network::create(["name" => "Avtomobil sanoati"]);
        Network::create(["name" => "Yog'-moy sanoati"]);
        Network::create(["name" => "Farmatsevtika"]);
        Network::create(["name" => "Kimyo sanoati"]);
        Network::create(["name" => "Elektr texnika"]);
        Network::create(["name" => "Boshqa sanoat tarmoqlari"]);
    }
}
