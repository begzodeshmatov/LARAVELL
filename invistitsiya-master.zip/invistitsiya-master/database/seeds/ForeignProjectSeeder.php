<?php

use App\ForeignProject;
use Illuminate\Database\Seeder;

class ForeignProjectSeeder extends Seeder
{
    public function run()
    {
        $project = ForeignProject::create([
            "name" => "Telegram bot",
            "goal" => "Yangil botni yaratish",
            "conclusion" => "Yangi bot yaratish qiyin ekan",
            "address" => "IT Park, IT Progress xonasi",
            "leader" => "Abdug'aniyev Axror",
            "district_id" => 1,
            "field_id" => 4,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 15000,
            "credit" => 20000,
            "foreign" => 30000,
            "number_of_vacancies" => 2,
            "available_vacancies" => 3,
            "date" => "2024-08-25"
        ]);
        $project->problems()->create([
            "text" => "Pul yo'q"
        ]);
        $project->problems()->create([
            "text" => "Pul yo'q"
        ]);
        $project->problems()->create([
            "text" => "Pul yo'q"
        ]);
        $project = ForeignProject::create([
            "name" => "Telegram bot 1",
            "goal" => "Yangil botni yaratish",
            "conclusion" => "Yangi bot yaratish qiyin ekan",
            "address" => "IT Park, IT Progress xonasi",
            "leader" => "Abdug'aniyev Axror",
            "district_id" => 1,
            "field_id" => 6,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 11000,
            "credit" => 22500,
            "foreign" => 33000,
            "number_of_vacancies" => 1,
            "available_vacancies" => 3,
            "status_id" => 2,
            "date" => "2024-11-02",
            "comment" => "O'xshamadi"
        ]);
        $project->problems()->create([
            "text" => "Pul yo'q"
        ]);
        $project = ForeignProject::create([
            "name" => "Telegram bot 2",
            "goal" => "Yangil botni yaratish",
            "conclusion" => "Yangi bot yaratish qiyin ekan",
            "address" => "IT Park, IT Progress xonasi",
            "leader" => "Abdug'aniyev Axror",
            "district_id" => 1,
            "field_id" => 7,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 15500,
            "credit" => 21000,
            "foreign" => 33000,
            "number_of_vacancies" => 5,
            "available_vacancies" => 3,
            "status_id" => 3,
            "done_at" => "2024-08-11",
            "date" => "2024-8-13"
        ]);
        $project->problems()->create([
            "text" => "Pul yo'q"
        ]);
        $project = ForeignProject::create([
            "name" => "Telegram bot 3",
            "goal" => "Yangil botni yaratish",
            "conclusion" => "Yangi bot yaratish qiyin ekan",
            "address" => "IT Park, IT Progress xonasi",
            "leader" => "Abdug'aniyev Axror",
            "district_id" => 1,
            "field_id" => 1,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 15000,
            "credit" => 20000,
            "foreign" => 30000,
            "number_of_vacancies" => 2,
            "available_vacancies" => 3,
            "date" => "2024-08-02"
        ]);
        $project->problems()->create([
            "text" => "Pul yo'q"
        ]);
    }
}
