<?php

use App\Unity;
use Illuminate\Database\Seeder;

class UnitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Unity::create(["name" => "tonna"]);
        Unity::create(["name" => "ming tonna"]);
        Unity::create(["name" => "gektar"]);
        Unity::create(["name" => "bosh"]);
        Unity::create(["name" => "ming bosh"]);
        Unity::create(["name" => "dona"]);
        Unity::create(["name" => "ming dona"]);
        Unity::create(["name" => "mln. dona"]);
        Unity::create(["name" => "mln, so'm"]);
        Unity::create(["name" => "trln, so'm"]);
        Unity::create(["name" => "mln, dollar"]);
    }
}
