<?php

use App\Company;
use Illuminate\Database\Seeder;

class CompanySeeder extends Seeder
{
    public function run()
    {
        Company::create([
            "sector_id" => 1,
            "district_id" => 1,
            "name" => "Jizzax qaysidir mchj 1",
            "type" => 1
        ]);
        Company::create([
            "sector_id" => 1,
            "district_id" => 1,
            "name" => "Jizzax qaysidir mchj 2",
            "type" => 1
        ]);
        Company::create([
            "sector_id" => 1,
            "district_id" => 1,
            "name" => "Jizzax qaysidir mchj 3",
            "type" => 1
        ]);
    }
}
