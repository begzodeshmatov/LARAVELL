<?php

use App\Project;
use Illuminate\Database\Seeder;

class ProjectSeeder extends Seeder
{
    public function run()
    {
        Project::create([
            "name" => "Telegram bot",
            "goal" => "Yangil botni yaratish",
            "district_id" => 1,
            "neighborhood_id" => 1,
            "field_id" => 1,
            "network_id" => 1,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 15000,
            "credit" => 20000,
            "foreign" => 30000,
            "number_of_vacancies" => 2,
            "date" => "2024-08-25"
        ]);
        Project::create([
            "name" => "Telegram bot 1",
            "goal" => "Yangil botni yaratish",
            "district_id" => 1,
            "neighborhood_id" => 1,
            "field_id" => 1,
            "network_id" => 1,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 11000,
            "credit" => 22500,
            "foreign" => 33000,
            "number_of_vacancies" => 1,
            "status_id" => 2,
            "date" => "2024-11-02",
            "comment" => "O'xshamadi"
        ]);
        Project::create([
            "name" => "Telegram bot 2",
            "goal" => "Yangil botni yaratish",
            "district_id" => 1,
            "neighborhood_id" => 1,
            "field_id" => 1,
            "network_id" => 1,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 15500,
            "credit" => 21000,
            "foreign" => 33000,
            "number_of_vacancies" => 5,
            "status_id" => 3,
            "done_at" => "2024-08-11",
            "date" => "2024-8-13"
        ]);
        Project::create([
            "name" => "Telegram bot 3",
            "goal" => "Yangil botni yaratish",
            "district_id" => 1,
            "neighborhood_id" => 1,
            "field_id" => 1,
            "network_id" => 1,
            "area" => 1,
            "value" => 0.001,
            "power" => 5,
            "unity_id" => 3,
            "bank" => "Xalq banki",
            "actually_done" => 18000,
            "own_price" => 2200,
            "price" => 15000,
            "credit" => 20000,
            "foreign" => 30000,
            "number_of_vacancies" => 2,
            "date" => "2024-08-02"
        ]);
    }
}
