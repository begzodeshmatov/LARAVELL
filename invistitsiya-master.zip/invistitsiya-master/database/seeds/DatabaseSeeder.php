<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call([
            UserSeeder::class,
            RegionSeeder::class,
            DistrictSeeder::class,
            NetworkSeeder::class,
            SectorSeeder::class,
            FieldSeeder::class,
            UnitySeeder::class,
            StatusSeeder::class,
            // CompanySeeder::class,
            // CompanyReportSeeder::class,
            // NeighborhoodSeeder::class,
            // ProjectSeeder::class
            // ForeignProjectSeeder::class
        ]);
    }
}
