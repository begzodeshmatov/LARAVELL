<?php

use App\Field;
use Illuminate\Database\Seeder;

class FieldSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Field::create([
            "name" => "Sanoat",
            "type" => "local",
        ]);
        Field::create([
            "name" => "Xizmat ko'rsatish",
            "type" => "local",
        ]);
        Field::create([
            "name" => "Qishloq xo'jaligi",
            "type" => "local",
        ]);
        Field::create([
            "name" => "Qurulish materiallari sanoati",
            "type" => "foreign",
        ]);
        Field::create([
            "name" => "Qishloq xo'jaligi",
            "type" => "foreign",
        ]);
        Field::create([
            "name" => "Avtomabilsozlik sanoati",
            "type" => "foreign",
        ]);
        Field::create([
            "name" => "Tekistil va to'qimachilik sanoati",
            "type" => "foreign",
        ]);
    }
}
