<?php

use App\Sector;
use Illuminate\Database\Seeder;

class SectorSeeder extends Seeder
{
    public function run()
    {
        Sector::create(["name" => "1-sektor"]);
        Sector::create(["name" => "2-sektor"]);
        Sector::create(["name" => "3-sektor"]);
        Sector::create(["name" => "4-sektor"]);
    }
}
