<?php

use Illuminate\Database\Seeder;

class MonthlyReportSeeder extends Seeder
{
    public function run()
    {
        //
    }
}
