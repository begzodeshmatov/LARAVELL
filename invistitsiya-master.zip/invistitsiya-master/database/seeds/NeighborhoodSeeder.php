<?php

use App\Neighborhood;
use Illuminate\Database\Seeder;

class NeighborhoodSeeder extends Seeder
{
    public function run()
    {
        Neighborhood::create(["name" => "Buyodkor", "district_id" => 1, "sector_id" => 2]);
        Neighborhood::create(["name" => "Do'stlik", "district_id" => 1, "sector_id" => 2]);
    }
}
