<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProjectsTable extends Migration
{
    public function up()
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->string("name");
            $table->text("goal");
            $table->json("confirmation");
            $table->foreignId("neighborhood_id")->constrained()->cascadeOnDelete();
            $table->foreignId("district_id")->constrained()->cascadeOnDelete();
            $table->foreignId("field_id")->constrained()->cascadeOnDelete();
            $table->foreignId("network_id")->constrained()->cascadeOnDelete();
            $table->float("area")->default(0);
            $table->decimal("value", 20, 4)->default(0);
            $table->decimal("power", 20, 4)->default(0);
            $table->foreignId("unity_id")->constrained()->cascadeOnDelete();
            $table->string("bank");
            $table->decimal("actually_done", 20, 4)->default(0);
            $table->decimal("own_price", 20, 4)->default(0);
            $table->decimal("credit", 20, 4)->default(0);
            $table->decimal("foreign", 20, 4)->default(0);
            $table->integer("number_of_vacancies")->default(0);
            $table->integer("available_vacancies")->default(0);
            $table->date("date");
            $table->date("done_at")->nullable();
            $table->foreignId("status_id")->default(1)->constrained()->cascadeOnDelete();
            $table->text("comment")->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('projects');
    }
}
