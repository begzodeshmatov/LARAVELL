<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompanyReportsTable extends Migration
{
    public function up()
    {
        Schema::create('company_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_id')->constrained()->cascadeOnDelete();
            $table->year('year');
            $table->float('total_price', 20, 1);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('company_reports');
    }
}
