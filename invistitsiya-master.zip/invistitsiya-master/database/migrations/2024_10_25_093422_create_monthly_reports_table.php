<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonthlyReportsTable extends Migration
{
    public function up()
    {
        Schema::create('monthly_reports', function (Blueprint $table) {
            $table->id();
            $table->foreignId('company_report_id')->constrained()->cascadeOnDelete();
            $table->integer('month');
            $table->float('pragnoz', 20, 1);
            $table->float('in_practice', 20, 1)->default(0);
            $table->timestamps();
        });

    }

    public function down()
    {
        Schema::dropIfExists('monthly_reports');
    }
}
