<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMurojaatsTable extends Migration
{
    public function up()
    {
        Schema::create('murojaats', function (Blueprint $table) {
            $table->id();
            $table->string("subject")->default('0');
            $table->string("tadbirkor_id");
            $table->string("murojaat_type");
            $table->text("qisqacha");
            $table->string("nazoratchi")->default('0');
            $table->string("soha");
            $table->string("file")->default('0');
            $table->dateTime("time")->nullable();
            $table->dateTime("done_at")->nullable();
            $table->integer("holat")->default(1);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('murojaats');
    }
}
