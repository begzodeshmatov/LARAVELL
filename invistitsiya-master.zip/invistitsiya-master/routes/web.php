<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\CabinetController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\TargibotController;
use App\Http\Controllers\MurojaatController;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\BucketListController;
use App\Http\Controllers\StatisticsController;
use App\Http\Controllers\MailMessageController;
use App\Http\Controllers\NeighborhoodController;
use App\Http\Controllers\CompanyReportController;
use App\Http\Controllers\ForeignProjectController;
use App\Http\Controllers\ReportStatisticController;
use App\Http\Controllers\XujjatController;

Route::get('/', function () {
    return redirect()->route('login');
});
Auth::routes();

Route::prefix('register')->group(function () {
    Route::get('/second', [AuthController::class, 'secondregisterview'])->name('register.secont');
    Route::post('/second', [AuthController::class, 'secondregister'])->name('register.secont.store');
    Route::get('/thrid', [AuthController::class, 'thridregisterview'])->name('register.thrid');
    Route::post('/thrid', [AuthController::class, 'thridregister'])->name('register.thrid.store');
});
Route::prefix('messages')->group(function () {
    Route::get('/', [MailMessageController::class, 'write'])->name('message.write');
    Route::get('/reseived', [MailMessageController::class, 'reseived'])->name('message.reseived');
    Route::get('/sent', [MailMessageController::class, 'sent'])->name('message.sent');
    Route::post('/store', [MailMessageController::class, 'store'])->name('message.store');
    Route::put('/{mailMessage}', [MailMessageController::class, 'update'])->name('message.update');
    Route::delete('/{mailMessage}', [MailMessageController::class, 'destroy'])->name('message.destroy');
});
Route::prefix('cabinet')->group(function () {
    Route::get('/', [CabinetController::class, 'show'])->name('cabinet.show');
    Route::put('/data/update', [CabinetController::class, 'update'])->name('cabinet.update');
    Route::put('/password/update', [CabinetController::class, 'password'])->name('cabinet.password');
});

Route::get('/home', [HomeController::class, 'index'])->name('home');
Route::get('/local', [HomeController::class, 'local'])->name('local');
Route::get('/foreign', [HomeController::class, 'foreign'])->name('foreign');
Route::get('/notavailable', [HomeController::class, 'notavailable'])->name('not.available');
Route::get('/district/{district}/foreign', [StatisticsController::class, 'districtForeign'])->name('district.foreign');
Route::get('/district/{district}', [StatisticsController::class, 'district'])->name('district');

Route::prefix('users')->group(function () {
    Route::get('/', [UserController::class, 'index'])->name('user.index');
    Route::post('/', [UserController::class, 'store'])->name('user.store');
    Route::put('/{user}', [UserController::class, 'update'])->name('user.update');
    Route::delete('/{user}', [UserController::class, 'destroy'])->name('user.destroy');
    Route::put('/restore/{user}', [UserController::class, 'restore'])->name('user.restore');
});

Route::prefix('projects')->group(function () {
    Route::get('/', [ProjectController::class, 'index'])->name('project.index');
    Route::get('/export', [ProjectController::class, 'export'])->name('project.export');
    Route::post('/', [ProjectController::class, 'store'])->name('project.store');
    Route::get('/edit/{project}', [ProjectController::class, 'edit'])->name('project.edit');
    Route::post('/image/{project}', [ProjectController::class, 'image'])->name('project.image');
    Route::post('/deed/{project}', [ProjectController::class, 'deed'])->name('project.deed');
    Route::put('/{project}', [ProjectController::class, 'update'])->name('project.update');
    Route::put('/image/{project}/{image}', [ProjectController::class, 'imageUpdate'])->name('image.update');
    Route::put('/deed/{project}/{file}', [ProjectController::class, 'deedUpdate'])->name('deed.update');
    Route::put('/status/{project}', [ProjectController::class, 'change'])->name('project.change');
    Route::delete('/{project}', [ProjectController::class, 'destroy'])->name('project.destroy');
    Route::delete('/image/{project}/{image}', [ProjectController::class, 'imageDestroy'])->name('image.destroy');
    Route::delete('/deed/{project}/{file}', [ProjectController::class, 'deedDestroy'])->name('deed.destroy');
});

Route::prefix('foreignprojects')->group(function () {
    Route::get('/', [ForeignProjectController::class, 'index'])->name('project.index.foreign');
    Route::get('/export', [ForeignProjectController::class, 'export'])->name('project.export.foreign');
    Route::post('/', [ForeignProjectController::class, 'store'])->name('project.store.foreign');
    Route::get('/edit/{project}', [ForeignProjectController::class, 'edit'])->name('project.edit.foreign');
    Route::post('/image/{project}', [ForeignProjectController::class, 'image'])->name('project.image.foreign');
    Route::post('/problem/{project}', [ForeignProjectController::class, 'problem'])->name('project.problem.foreign');
    Route::post('/deed/{project}', [ForeignProjectController::class, 'deed'])->name('project.deed.foreign');
    Route::put('/{project}', [ForeignProjectController::class, 'update'])->name('project.update.foreign');
    Route::put('/image/{project}/{image}', [ForeignProjectController::class, 'imageUpdate'])->name('image.update.foreign');
    Route::put('/problem/{project}/{problem}', [ForeignProjectController::class, 'problemUpdate'])->name('problem.update.foreign');
    Route::put('/deed/{project}/{file}', [ForeignProjectController::class, 'deedUpdate'])->name('deed.update.foreign');
    Route::put('/status/{project}', [ForeignProjectController::class, 'change'])->name('project.change.foreign');
    Route::delete('/{project}', [ForeignProjectController::class, 'destroy'])->name('project.destroy.foreign');
    Route::delete('/image/{project}/{image}', [ForeignProjectController::class, 'imageDestroy'])->name('image.destroy.foreign');
    Route::delete('/problem/{project}/{problem}', [ForeignProjectController::class, 'problemDestroy'])->name('problem.destroy.foreign');
    Route::delete('/deed/{project}/{file}', [ForeignProjectController::class, 'deedDestroy'])->name('deed.destroy.foreign');
});

Route::prefix('statistics')->group(function () {
    Route::get('/districts/{region}/{type}/forign', [StatisticsController::class, 'districtsForeign'])->name('districts.region.foreign');
    Route::get('/districts/{region}/{type}', [StatisticsController::class, 'districts'])->name('districts.region');
    Route::get('/sectors/{district}/{type}', [StatisticsController::class, 'sectors'])->name('sectors.district');
    Route::get('/neighborhoods/{district}/{sector}/{type}', [StatisticsController::class, 'neighborhoods'])->name('neighborhoods.district');
    Route::get('/projects/{project}/show/foreign', [StatisticsController::class, 'projectForeign'])->name('project.show.foreign');
    Route::get('/projects/{district}/{type}/foreign', [StatisticsController::class, 'allProjects'])->name('project.district');
    Route::get('/projects/{project}/show', [StatisticsController::class, 'project'])->name('project.show');
    Route::get('/projects/{neighborhood}/{type}', [StatisticsController::class, 'projects'])->name('project.neighborhood');
});

Route::prefix('neighborhoods')->group(function () {
    Route::get('/', [NeighborhoodController::class, 'index'])->name('neighborhood.index');
    Route::post('/', [NeighborhoodController::class, 'store'])->name('neighborhood.store');
    Route::put('/{neighborhood}', [NeighborhoodController::class, 'update'])->name('neighborhood.update');
    Route::delete('/{neighborhood}', [NeighborhoodController::class, 'destroy'])->name('neighborhood.destroy');
});

Route::prefix('bucket')->group(function () {
    Route::get('/', [BucketListController::class, 'index'])->name('bucket.index');
    Route::get('/restore/{id}/foreign', [BucketListController::class, 'foreignRestore'])->name('bucket.restore.foreign');
    Route::delete('/{id}/foreign', [BucketListController::class, 'foreignDestroy'])->name('bucket.destroy.foreign');
    Route::get('/restore/{id}', [BucketListController::class, 'restore'])->name('bucket.restore');
    Route::delete('/{id}', [BucketListController::class, 'destroy'])->name('bucket.destroy');
});

Route::prefix('profile')->group(function () {
    Route::get('/', [ProfileController::class, 'show'])->name('profile.show');
    Route::put('/', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/password', [ProfileController::class, 'password'])->name('profile.password');
    Route::put('/image', [ProfileController::class, 'image'])->name('profile.image');
    Route::delete('/', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Axror
Route::prefix('murojaat')->group(function () {
    Route::get('/', [MurojaatController::class, 'index'])->name('murojaat.index');
    Route::post('/', [MurojaatController::class, 'store'])->name('murojaat.store');
    Route::post('/{biriktirish}', [MurojaatController::class, 'biriktirish'])->name('murojaat.biriktirish');
    Route::delete('/{murojaat}', [MurojaatController::class, 'destroy'])->name('murojaat.destroy');
    Route::get('/{murojaat}', [MurojaatController::class, 'batafsil'])->name('murojaat.batafsil');
    Route::put('/done/{murojaat}', [MurojaatController::class, 'done'])->name('murojaat.done');
    Route::put('/extend/{murojaat}', [MurojaatController::class, 'extend'])->name('murojaat.extend');

});

Route::prefix('companies')->group(function () {
    Route::get('/', [CompanyController::class, 'index'])->name('company.index');
    Route::post('/', [CompanyController::class, 'store'])->name('company.store');
    Route::get('/edit/{company}', [CompanyController::class, 'edit'])->name('company.edit');
    Route::post('/image/{company}', [CompanyController::class, 'image'])->name('company.image');
    Route::put('/{company}', [CompanyController::class, 'update'])->name('company.update');
    Route::put('/image/{company}/{image}', [CompanyController::class, 'imageUpdate'])->name('image.update.company');
    Route::delete('/{company}', [CompanyController::class, 'destroy'])->name('company.destroy');
    Route::delete('/image/{company}/{image}', [CompanyController::class, 'imageDestroy'])->name('image.destroy.company');
});

Route::prefix('report')->group(function () {
    Route::get('/years', [ReportController::class, 'years'])->name('report.years');
    Route::get('/districts/{year}', [ReportController::class, 'districts'])->name('report.districts');
    Route::get('/sectors/{year}/{district}', [ReportController::class, 'sectors'])->name('report.sectors');
    Route::get('/companies/{year}/{district}/{sector}', [ReportController::class, 'companies'])->name('report.companies');
    Route::get('/company/{year}/{district}/{sector}/{company}', [ReportController::class, 'company'])->name('report.company');
    Route::get('/moths/{year}/{district}/{sector}/{company}', [ReportController::class, 'months'])->name('report.months');
});

Route::prefix('export')->group(function () {
    Route::get('/', [ ReportStatisticController::class, 'statistic' ])->name('export.statistic');
    Route::get('/district/{district}', [ ReportStatisticController::class, 'district' ])->name('export.district');
    Route::get('/districts/{region}/{type}', [ ReportStatisticController::class, 'districts' ])->name('export.districts');
    Route::get('/sectors/{district}/{type}', [ ReportStatisticController::class, 'sectors' ])->name('export.sectors');
    Route::get('/companies/{district}/{sector}/{type}', [ ReportStatisticController::class, 'companies' ])->name('export.companies');
    Route::get('/company/reports/{company}', [ ReportStatisticController::class, 'reports' ])->name('export.company.reports');
    Route::get('/company/{company}', [ ReportStatisticController::class, 'company' ])->name('export.company');
});

Route::prefix('companyreports')->group(function () {
    Route::get('/', [CompanyReportController::class, 'index'])->name('report.index');
    Route::get('/edit/{companyreport}', [CompanyReportController::class, 'edit'])->name('report.edit');
    Route::post('/', [CompanyReportController::class, 'store'])->name('report.store');
    Route::put('/{companyreport}', [CompanyReportController::class, 'update'])->name('report.update');
    Route::put('/monthly/{monthlyreport}', [CompanyReportController::class, 'updateMonthly'])->name('report.update.monthly');
    Route::delete('/{companyreport}', [CompanyReportController::class, 'destroy'])->name('report.destroy');
});


Route::prefix('announcements')->group(function () {
    Route::get('/', [TargibotController::class, 'index'])->name('announcements.index');
    Route::post('/{announcements}', [TargibotController::class, 'update'])->name('announcements.update');
    Route::post('/', [TargibotController::class, 'store'])->name('announcements.store');
    Route::delete('/{announcements}', [TargibotController::class, 'destroy'])->name('announcements.destroy');
    Route::get('/{announcements}', [TargibotController::class, 'batafsil'])->name('announcements.batafsil');
});


Route::get('/video', [HomeController::class, 'video'])->name('video');

Route::post('/murojaatYechish/{id}', function () {
    dd('ke;di');
});
Route::get('/xujjat', [XujjatController::class, 'xujjat'])->name('xujjat');
