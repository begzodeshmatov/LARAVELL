<?php

use App\Http\Controllers\api\NeighborhoodApiController;
use App\Http\Controllers\api\CompaniesApiController;
use App\Http\Controllers\api\MessageController;
use Illuminate\Support\Facades\Route;

Route::prefix('neighborhoods')->group(function () {
    Route::get('/sector/{sector}', [NeighborhoodApiController::class, 'sector']);
    Route::get('/district/{district}', [NeighborhoodApiController::class, 'district']);
    Route::get('/{district}/{sector}', [NeighborhoodApiController::class, 'index']);
    Route::get('/{district}', [NeighborhoodApiController::class, 'select']);
});
Route::prefix('companies')->group(function () {
    Route::get('/sector/{sector}', [CompaniesApiController::class, 'sector']);
    Route::get('/district/{district}', [CompaniesApiController::class, 'district']);
    Route::get('/{district}/{sector}', [CompaniesApiController::class, 'index']);
});
Route::get('/users', [MessageController::class, 'users']);
Route::get('/allconversations', [MessageController::class, 'conversations']);
Route::get('/allconversations/user/{user}', [MessageController::class, 'conversationsByUserId']);
Route::get('/messages/{conversation}', [MessageController::class, 'messages']);
Route::post('/conversation/{user}', [MessageController::class, 'addConversation']);
Route::post('/message/{conversation}', [MessageController::class, 'addMessage']);
